import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/db'
import { orders, settings } from '@/db/schema'
import { eq, or } from 'drizzle-orm'
import crypto from 'crypto'

/**
 * Steadfast Courier Webhook Handler
 * 
 * Receives status updates from Steadfast Courier API
 * Endpoint: POST /api/courier/webhook
 * 
 * Webhook payload types:
 * 1. delivery_status - Delivery status updates
 * 2. tracking_update - Tracking updates
 * 
 * Security: Verifies webhook signature using HMAC-SHA256
 */

interface WebhookPayload {
  notification_type: 'delivery_status' | 'tracking_update'
  consignment_id: number
  invoice: string
  cod_amount?: number
  status?: string
  delivery_charge?: number
  tracking_message?: string
  updated_at?: string
}

/**
 * Verify webhook signature from Steadfast
 * Steadfast sends a signature in the header that we verify using our secret key
 */
async function verifyWebhookSignature(
  body: string,
  signature: string | null,
  secretKey: string
): Promise<boolean> {
  if (!signature || !secretKey) {
    return false
  }
  
  try {
    // Create HMAC-SHA256 hash of the body using the secret key
    const expectedSignature = crypto
      .createHmac('sha256', secretKey)
      .update(body)
      .digest('hex')
    
    // Compare signatures using timing-safe comparison
    return crypto.timingSafeEqual(
      Buffer.from(signature),
      Buffer.from(expectedSignature)
    )
  } catch (error) {
    console.error('[Webhook] Signature verification error:', error)
    return false
  }
}

/**
 * Get webhook secret from settings
 */
async function getWebhookSecret(): Promise<string | null> {
  try {
    const result = await db.select().from(settings).where(eq(settings.id, 1)).limit(1)
    if (result.length > 0 && result[0].courierSecretKey) {
      return result[0].courierSecretKey
    }
    return null
  } catch (error) {
    console.error('[Webhook] Error fetching webhook secret:', error)
    return null
  }
}

// Map Steadfast statuses to our internal statuses
function mapCourierStatus(status: string): string {
  const statusMap: Record<string, string> = {
    'pending': 'pending',
    'in_review': 'in_review',
    'delivered_approval_pending': 'delivered_approval_pending',
    'partial_delivered_approval_pending': 'partial_delivered_approval_pending',
    'cancelled_approval_pending': 'cancelled_approval_pending',
    'unknown_approval_pending': 'unknown_approval_pending',
    'delivered': 'delivered',
    'partial_delivered': 'partial_delivered',
    'cancelled': 'cancelled',
    'hold': 'hold',
    'unknown': 'unknown',
  }
  return statusMap[status?.toLowerCase()] || status
}

export async function POST(request: NextRequest) {
  try {
    // Get raw body for signature verification
    const rawBody = await request.text()
    const body: WebhookPayload = JSON.parse(rawBody)
    
    // Get signature from header (Steadfast uses 'X-Signature' or 'signature')
    const signature = request.headers.get('X-Signature') || 
                      request.headers.get('signature') ||
                      request.headers.get('X-Steadfast-Signature')
    
    // Verify webhook signature for security
    const webhookSecret = await getWebhookSecret()
    
    if (webhookSecret) {
      // If secret is configured, signature is required
      if (!signature) {
        console.log('[Webhook] Rejected: Missing signature header')
        return NextResponse.json(
          { status: 'error', message: 'Missing signature' },
          { status: 401 }
        )
      }
      
      const isValid = await verifyWebhookSignature(rawBody, signature, webhookSecret)
      
      if (!isValid) {
        console.log('[Webhook] Rejected: Invalid signature')
        return NextResponse.json(
          { status: 'error', message: 'Invalid signature' },
          { status: 401 }
        )
      }
      
      console.log('[Webhook] Signature verified successfully')
    } else {
      // If no secret configured, log warning but allow (for backward compatibility during setup)
      console.warn('[Webhook] Warning: No webhook secret configured - skipping signature verification')
    }
    
    console.log('[Webhook] Received from Steadfast:', JSON.stringify(body, null, 2))
    
    // Validate required fields
    if (!body.consignment_id && !body.invoice) {
      return NextResponse.json(
        { status: 'error', message: 'Missing consignment_id or invoice' },
        { status: 400 }
      )
    }
    
    // Find the order by consignment_id or invoice
    let order
    if (body.consignment_id) {
      const result = await db.select().from(orders)
        .where(eq(orders.consignmentId, body.consignment_id))
        .limit(1)
      order = result[0]
    }
    
    if (!order && body.invoice) {
      const result = await db.select().from(orders)
        .where(eq(orders.id, body.invoice))
        .limit(1)
      order = result[0]
    }
    
    if (!order) {
      console.log('[Webhook] Order not found for:', body.consignment_id || body.invoice)
      return NextResponse.json(
        { status: 'error', message: 'Order not found' },
        { status: 404 }
      )
    }
    
    // Handle delivery_status notification
    if (body.notification_type === 'delivery_status') {
      const courierStatus = mapCourierStatus(body.status || '')
      
      // Update order with new status
      const updateData: Record<string, unknown> = {
        courierStatus,
        updatedAt: new Date(),
      }
      
      // If delivered, record delivery time
      if (body.status?.toLowerCase() === 'delivered') {
        updateData.courierDeliveredAt = body.updated_at || new Date().toISOString()
      }
      
      // If cancelled, also update order status
      if (body.status?.toLowerCase() === 'cancelled') {
        updateData.status = 'canceled'
        updateData.canceledBy = 'Courier'
      }
      
      await db.update(orders)
        .set(updateData)
        .where(eq(orders.id, order.id))
      
      console.log(`[Webhook] Updated order ${order.id} status to ${courierStatus}`)
      
      return NextResponse.json({
        status: 'success',
        message: 'Webhook received successfully.',
        orderId: order.id,
        courierStatus,
      })
    }
    
    // Handle tracking_update notification
    if (body.notification_type === 'tracking_update') {
      // Just log the tracking update
      console.log(`[Webhook] Tracking update for order ${order.id}: ${body.tracking_message}`)
      
      // We could store tracking messages in a separate table if needed
      // For now, just acknowledge receipt
      
      return NextResponse.json({
        status: 'success',
        message: 'Tracking update received.',
        orderId: order.id,
        trackingMessage: body.tracking_message,
      })
    }
    
    // Unknown notification type
    return NextResponse.json({
      status: 'success',
      message: 'Webhook received.',
    })
    
  } catch (error) {
    console.error('[Webhook] Error processing webhook:', error)
    return NextResponse.json(
      { status: 'error', message: 'Internal server error' },
      { status: 500 }
    )
  }
}

// Also support GET for webhook verification
export async function GET() {
  return NextResponse.json({
    status: 'success',
    message: 'Steadfast webhook endpoint is active',
  })
}
