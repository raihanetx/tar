import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/db'
import { settings, orders } from '@/db/schema'
import { eq } from 'drizzle-orm'

const STEADFAST_BASE_URL = 'https://portal.packzy.com/api/v1'

// Helper function to get courier credentials from database
async function getCourierCredentials() {
  const result = await db.select().from(settings).where(eq(settings.id, 1)).limit(1)
  if (result.length === 0) {
    return null
  }
  return {
    enabled: result[0].courierEnabled === 1 || result[0].courierEnabled === true,
    apiKey: result[0].courierApiKey || '',
    secretKey: result[0].courierSecretKey || '',
  }
}

// Helper function to make Steadfast API requests
async function steadfastRequest(
  endpoint: string,
  method: 'GET' | 'POST' = 'GET',
  body?: object
) {
  const credentials = await getCourierCredentials()
  
  if (!credentials || !credentials.enabled) {
    return { error: 'Courier integration not enabled', status: 400 }
  }
  
  if (!credentials.apiKey || !credentials.secretKey) {
    return { error: 'Courier credentials not configured', status: 400 }
  }
  
  const headers: Record<string, string> = {
    'Api-Key': credentials.apiKey,
    'Secret-Key': credentials.secretKey,
    'Content-Type': 'application/json',
  }
  
  try {
    const response = await fetch(`${STEADFAST_BASE_URL}${endpoint}`, {
      method,
      headers,
      body: body ? JSON.stringify(body) : undefined,
    })
    
    const data = await response.json()
    
    return {
      success: response.ok,
      status: response.status,
      data,
    }
  } catch (error) {
    console.error('Steadfast API error:', error)
    return { error: 'Failed to connect to courier service', status: 500 }
  }
}

// GET /api/courier - Check balance or status
export async function GET(request: NextRequest) {
  // Check authentication
  const session = await getServerSession(authOptions)
  if (!session || !session.user) {
    return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 })
  }

  const searchParams = request.nextUrl.searchParams
  const action = searchParams.get('action')
  
  try {
    // Check balance
    if (action === 'balance') {
      const result = await steadfastRequest('/get_balance')
      
      if (result.error) {
        return NextResponse.json(
          { success: false, error: result.error },
          { status: result.status }
        )
      }
      
      return NextResponse.json({
        success: true,
        balance: result.data?.current_balance || 0,
      })
    }
    
    // Check status by consignment ID
    if (action === 'status' && searchParams.get('consignmentId')) {
      const consignmentId = searchParams.get('consignmentId')
      const result = await steadfastRequest(`/status_by_cid/${consignmentId}`)
      
      return NextResponse.json({
        success: result.success,
        data: result.data,
      })
    }
    
    // Check status by invoice (order ID)
    if (action === 'status' && searchParams.get('invoice')) {
      const invoice = searchParams.get('invoice')
      const result = await steadfastRequest(`/status_by_invoice/${invoice}`)
      
      return NextResponse.json({
        success: result.success,
        data: result.data,
      })
    }
    
    // Check status by tracking code
    if (action === 'status' && searchParams.get('trackingCode')) {
      const trackingCode = searchParams.get('trackingCode')
      const result = await steadfastRequest(`/status_by_trackingcode/${trackingCode}`)
      
      return NextResponse.json({
        success: result.success,
        data: result.data,
      })
    }
    
    // Get courier settings status
    if (action === 'config') {
      const credentials = await getCourierCredentials()
      return NextResponse.json({
        success: true,
        enabled: credentials?.enabled || false,
        configured: !!(credentials?.apiKey && credentials?.secretKey),
      })
    }
    
    return NextResponse.json(
      { success: false, error: 'Invalid action' },
      { status: 400 }
    )
  } catch (error) {
    console.error('Courier API error:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to process request' },
      { status: 500 }
    )
  }
}

// POST /api/courier - Create order with Steadfast
export async function POST(request: NextRequest) {
  try {
    // Check authentication
    const session = await getServerSession(authOptions)
    if (!session || !session.user) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const { orderId } = body
    
    if (!orderId) {
      return NextResponse.json(
        { success: false, error: 'Order ID is required' },
        { status: 400 }
      )
    }
    
    // Get the order from database
    const orderResult = await db.select().from(orders).where(eq(orders.id, orderId)).limit(1)
    
    if (orderResult.length === 0) {
      return NextResponse.json(
        { success: false, error: 'Order not found' },
        { status: 404 }
      )
    }
    
    const order = orderResult[0]
    
    // Check if already sent to courier
    if (order.consignmentId) {
      return NextResponse.json({
        success: true,
        message: 'Order already sent to courier',
        consignmentId: order.consignmentId,
        trackingCode: order.trackingCode,
      })
    }
    
    // Validate phone number (must be 11 digits)
    let phone = order.phone.replace(/[^0-9]/g, '')
    if (phone.length > 11) {
      phone = phone.slice(-11) // Take last 11 digits
    } else if (phone.length < 11) {
      // Pad with leading zero if needed
      phone = phone.padStart(11, '0')
    }
    
    // Prepare order data for Steadfast
    const steadfastOrder = {
      invoice: order.id,
      recipient_name: order.customerName,
      recipient_phone: phone,
      recipient_address: order.address,
      cod_amount: order.total,
      note: `Payment: ${order.paymentMethod}`,
    }
    
    // Send to Steadfast
    const result = await steadfastRequest('/create_order', 'POST', steadfastOrder)
    
    if (result.error) {
      return NextResponse.json(
        { success: false, error: result.error },
        { status: result.status }
      )
    }
    
    // Update order with consignment details
    if (result.success && result.data?.consignment) {
      const consignment = result.data.consignment
      
      await db.update(orders)
        .set({
          consignmentId: consignment.consignment_id,
          trackingCode: consignment.tracking_code,
          courierStatus: consignment.status || 'in_review',
          updatedAt: new Date(),
        })
        .where(eq(orders.id, orderId))
      
      return NextResponse.json({
        success: true,
        message: 'Order sent to courier successfully',
        consignment: {
          consignmentId: consignment.consignment_id,
          trackingCode: consignment.tracking_code,
          status: consignment.status,
        },
      })
    }
    
    return NextResponse.json(
      { success: false, error: 'Failed to create consignment' },
      { status: 500 }
    )
  } catch (error) {
    console.error('Create courier order error:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to send order to courier' },
      { status: 500 }
    )
  }
}
