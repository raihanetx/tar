'use client'

import { useState, useEffect } from 'react'
import { CartItem, ViewType, Review } from '@/types'
import { useShopStore } from '@/store/useShopStore'

interface ProductDetailProps {
  setView: (v: ViewType) => void
  addToCart: (item: CartItem) => void
}

// Helper function to parse markdown bold syntax **text** to bold
const parseBoldText = (text: string) => {
  if (!text) return text
  const parts = text.split(/(\*\*[^*]+\*\*)/g)
  return parts.map((part, index) => {
    if (part.startsWith('**') && part.endsWith('**')) {
      return <strong key={index} className="font-bold text-[#1F2937]">{part.slice(2, -2)}</strong>
    }
    return part
  })
}

export default function ProductDetail({ setView, addToCart }: ProductDetailProps) {
  const [activeTab, setActiveTab] = useState('desc')
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [userRating, setUserRating] = useState(0)
  const [selectedVariantIndex, setSelectedVariantIndex] = useState(0)
  const [quantity, setQuantity] = useState(1)
  const [selectedImageIndex, setSelectedImageIndex] = useState(0)
  const [reviews, setReviews] = useState<Review[]>([])
  
  const { products, selectedProductId, selectedProductVariants, selectedProductImages, selectedProductFaqs, selectedProductRelated, selectedProductReviews, setSelectedProduct, addReview } = useShopStore()
  
  // Find the selected product
  const selectedProduct = products.find(p => p.id === selectedProductId)
  
  // Get product images - use database images or fallback to main product image
  const productImages = selectedProductImages.length > 0 
    ? selectedProductImages.map(img => img.url) 
    : (selectedProduct ? [selectedProduct.image] : [])
  
  // Use reviews from store or local state (submitted during session)
  const productReviews = selectedProductReviews.length > 0 ? selectedProductReviews : reviews
  
  // Build related products from database or fallback to offer products
  const relatedFromDb = selectedProductRelated
    .filter(r => r.product)
    .map(r => ({
      id: r.relatedProductId,
      name: r.product!.name,
      price: r.product!.price,
      oldPrice: r.product!.oldPrice || r.product!.price,
      img: r.product!.image,
      weight: '500g',
      discount: parseInt(r.product!.discount) || 0,
      rating: 4.5,
      reviews: 100
    }))
  
  // Fallback to offer products if no related products in database
  const offerProducts = products.filter(p => p.offer && p.id !== selectedProductId).slice(0, 4).map(p => ({
    id: p.id,
    name: p.name,
    price: p.price,
    oldPrice: p.oldPrice || p.price,
    img: p.image,
    weight: '500g',
    discount: parseInt(p.discount) || 0,
    rating: 4.5,
    reviews: 100
  }))
  
  const relatedProducts = relatedFromDb.length > 0 ? relatedFromDb : offerProducts

  useEffect(() => {
    window.scrollTo(0, 0)
  }, [selectedProductId])
  
  // Track product view
  useEffect(() => {
    if (selectedProductId) {
      fetch('/api/analytics', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: 'view', productId: selectedProductId }),
      }).catch(e => console.error('Failed to track view:', e))
    }
  }, [selectedProductId])
  
  // Handle clicking on a related product
  const handleRelatedProductClick = async (productId: number) => {
    // Reset state before changing product
    setSelectedVariantIndex(0)
    setQuantity(1)
    setSelectedImageIndex(0)
    await setSelectedProduct(productId)
    window.scrollTo(0, 0)
  }

  // Get the current variant info for display
  const currentVariant = selectedProductVariants[selectedVariantIndex]
  const displayPrice = currentVariant?.price || selectedProduct?.price || 0
  const displayVariantName = currentVariant?.name || '1 KG'
  
  // Get discount info - use variant discount if available and > 0, otherwise use product discount
  // Note: Must check > 0 because ?? operator doesn't treat 0 as nullish
  const variantDiscountValue = currentVariant?.discountValue ?? 0
  const productDiscountValue = selectedProduct?.discountValue ?? 0

  const displayDiscountValue = variantDiscountValue > 0
    ? variantDiscountValue
    : productDiscountValue > 0
      ? productDiscountValue
      : 0

  const displayDiscountType = (displayDiscountValue > 0
    ? (variantDiscountValue > 0 ? currentVariant?.discountType : selectedProduct?.discountType)
    : 'pct') as 'pct' | 'fixed'
  const hasOffer = selectedProduct?.offer || false
  
  // Calculate total price
  const totalPrice = displayPrice * quantity

  const handleSubmitReview = async () => {
    const nameInput = document.getElementById('reviewName') as HTMLInputElement
    const textInput = document.getElementById('reviewText') as HTMLTextAreaElement
    const name = nameInput?.value || ''
    const text = textInput?.value || ''

    if (name && text && userRating > 0) {
      const initials = name.match(/(\b\S)?/g)?.join("").match(/(^\S|\S$)?/g)?.join("").toUpperCase() || name.substring(0, 2).toUpperCase()
      const newReview: Review = { id: Date.now(), initials, name, rating: userRating, text, date: 'Just now' }
      
      // Save to database if we have a selected product
      if (selectedProductId) {
        const success = await addReview(selectedProductId, { name, rating: userRating, text })
        if (success) {
          setIsModalOpen(false)
          setUserRating(0)
          // Clear form
          if (nameInput) nameInput.value = ''
          if (textInput) textInput.value = ''
        } else {
          alert("Failed to submit review. Please try again.")
        }
      } else {
        // Fallback to local state
        setReviews([newReview, ...reviews])
        setIsModalOpen(false)
        setUserRating(0)
      }
    } else {
      alert("Please fill all fields and rate.")
    }
  }

  // Handle add to cart with variant
  const handleAddToCart = () => {
    if (!selectedProduct) return
    
    addToCart({
      id: selectedProduct.id,
      name: selectedProduct.name,
      price: displayPrice,
      oldPrice: selectedProduct.oldPrice || selectedProduct.price,
      img: selectedProduct.image,
      weight: displayVariantName,
      quantity: quantity,
      category: selectedProduct.category,
      categoryId: selectedProduct.categoryId || undefined,
      offer: hasOffer,
      discountType: displayDiscountType,
      discountValue: displayDiscountValue,
    })
  }

  // Handle Buy Now - add to cart and go to checkout
  const handleBuyNow = () => {
    if (!selectedProduct) return
    
    addToCart({
      id: selectedProduct.id,
      name: selectedProduct.name,
      price: displayPrice,
      oldPrice: selectedProduct.oldPrice || selectedProduct.price,
      img: selectedProduct.image,
      weight: displayVariantName,
      quantity: quantity,
      category: selectedProduct.category,
      categoryId: selectedProduct.categoryId || undefined,
      offer: hasOffer,
      discountType: displayDiscountType,
      discountValue: displayDiscountValue,
    })
    setView('checkout')
  }

  // Build the product to display - use selected product or fallback
  const sampleProduct: CartItem = selectedProduct ? {
    id: selectedProduct.id,
    name: selectedProduct.name,
    price: displayPrice,
    oldPrice: selectedProduct.oldPrice || selectedProduct.price,
    img: selectedProduct.image,
    weight: displayVariantName
  } : { id: 99, name: 'Organic Premium Carrots', price: 80, oldPrice: 95, img: 'https://i.postimg.cc/B6sD1hKt/1000020579-removebg-preview.png', weight: '1 KG' }

  return (
    <div className="bg-white w-full p-5 md:p-20 min-h-screen">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-10">
        <div className="flex flex-col w-full">
          <div className="flex-grow relative w-full bg-gray-50 rounded-2xl overflow-hidden border border-gray-100 shadow-sm h-[280px] md:h-[350px]">
            {selectedProduct?.discount && selectedProduct.discount !== '0%' && (
              <div className="absolute top-3 left-3 bg-[#16a34a] text-white text-[10px] font-bold px-2.5 py-1 rounded-md z-10 shadow-md">-{selectedProduct.discount}</div>
            )}
            <img src={productImages[selectedImageIndex] || sampleProduct.img} className="absolute inset-0 w-full h-full object-contain" alt={sampleProduct.name} />
          </div>
          <div className="grid grid-cols-4 gap-2 mt-3 flex-shrink-0">
            {(productImages.length > 0 ? productImages : [sampleProduct.img]).slice(0, 4).map((img, i) => (
              <div 
                key={i} 
                className={`aspect-square bg-gray-50 rounded-lg overflow-hidden cursor-pointer transition-opacity ${i === selectedImageIndex ? 'border-2 border-[#16a34a]' : 'border border-gray-100 hover:opacity-80'}`}
                onClick={() => setSelectedImageIndex(i)}
              >
                <img src={img} className="w-full h-full object-cover" alt={`Product thumbnail ${i + 1}`} />
              </div>
            ))}
          </div>
        </div>
        <div className="flex flex-col">
          <h1 className="text-xl md:text-3xl font-bold text-[#1F2937] leading-tight mb-3">{sampleProduct.name}</h1>
          <div className="flex items-center flex-wrap gap-4 mb-5">
            <div className="flex items-baseline gap-2">
              <span className="text-xl font-bold text-[#16a34a]">TK<span>{displayPrice}</span></span>
              {sampleProduct.oldPrice && sampleProduct.oldPrice > displayPrice && (
                <span className="text-sm text-gray-300 line-through font-medium">TK{sampleProduct.oldPrice}</span>
              )}
            </div>
            <div className="w-px h-4 bg-gray-200"></div>
            <span className="text-sm font-semibold text-[#1F2937]">({displayVariantName})</span>
          </div>
          <p className="text-base text-[#6B7280] leading-relaxed mb-6 line-clamp-3 whitespace-pre-wrap">{parseBoldText(selectedProduct?.shortDesc || 'Farm-fresh organic produce handpicked from local farms. Crisp, sweet, and perfect for your needs. Rich in essential vitamins and nutrients.')}</p>

          {/* Variant Selection - Simple */}
          <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap', marginBottom: '16px' }}>
            {selectedProductVariants.length > 0 ? (
              selectedProductVariants.map((variant, index) => (
                <button 
                  key={variant.id}
                  onClick={() => setSelectedVariantIndex(index)}
                  style={{ 
                    padding: '8px 16px', 
                    borderRadius: '8px', 
                    border: index === selectedVariantIndex ? '2px solid #16a34a' : '1px solid #e2e8f0', 
                    background: index === selectedVariantIndex ? '#f0fdf4' : 'white', 
                    color: index === selectedVariantIndex ? '#16a34a' : '#64748b', 
                    fontSize: '13px', 
                    fontWeight: index === selectedVariantIndex ? 600 : 500, 
                    cursor: 'pointer' 
                  }}
                >{variant.name}</button>
              ))
            ) : (
              <button style={{ padding: '8px 16px', borderRadius: '8px', border: '2px solid #16a34a', background: '#f0fdf4', color: '#16a34a', fontSize: '13px', fontWeight: 600, cursor: 'pointer' }}>1 KG</button>
            )}
          </div>

          {/* Line 1: Quantity + Add to Cart */}
          <div style={{ display: 'flex', gap: '12px', alignItems: 'center', marginBottom: '10px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <button 
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
                style={{ width: '40px', height: '40px', borderRadius: '10px', border: '1px solid #e2e8f0', background: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', color: '#64748b', fontSize: '18px' }}
              ><i className="ri-subtract-line"></i></button>
              <span style={{ fontSize: '18px', fontWeight: 700, color: '#0f172a', minWidth: '32px', textAlign: 'center' }}>{quantity}</span>
              <button 
                onClick={() => setQuantity(quantity + 1)}
                style={{ width: '40px', height: '40px', borderRadius: '10px', border: '1px solid #e2e8f0', background: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', color: '#64748b', fontSize: '18px' }}
              ><i className="ri-add-line"></i></button>
            </div>
            <button 
              onClick={handleAddToCart} 
              style={{ 
                flex: 1, 
                border: '2px solid #16a34a', 
                color: '#16a34a', 
                height: '44px', 
                borderRadius: '10px', 
                fontSize: '14px', 
                fontWeight: 700, 
                background: 'white',
                cursor: 'pointer',
                display: 'flex', 
                alignItems: 'center', 
                justifyContent: 'center', 
                gap: '8px' 
              }}
            >
              <i className="ri-shopping-cart-line"></i> Add to Cart
            </button>
          </div>

          {/* Line 2: Buy Now with Bengali text */}
          <button 
            onClick={handleBuyNow} 
            style={{ 
              width: '100%', 
              background: 'linear-gradient(135deg, #16a34a 0%, #15803d 100%)', 
              color: 'white', 
              height: '52px', 
              borderRadius: '12px', 
              fontSize: '16px', 
              fontWeight: 700, 
              cursor: 'pointer',
              boxShadow: '0 4px 12px rgba(22, 163, 74, 0.3)',
              display: 'flex', 
              alignItems: 'center', 
              justifyContent: 'center', 
              gap: '8px',
              marginBottom: '12px'
            }}
          >
            <i className="ri-shopping-bag-line"></i> অর্ডার করুন ক্যাশ অন ডেলিভারিতে
          </button>

          {/* Line 3: Direct Order via Call/WhatsApp */}
          <div style={{ 
            display: 'flex', 
            alignItems: 'center', 
            justifyContent: 'center', 
            gap: '12px', 
            padding: '12px', 
            background: '#fefce8', 
            borderRadius: '10px', 
            border: '1px solid #fde047' 
          }}>
            <span style={{ fontSize: '12px', color: '#854d0e', fontWeight: 500 }}>সরাসরি অর্ডার করতে কল করুন:</span>
            <a href="tel:+8801866225512" style={{ display: 'flex', alignItems: 'center', gap: '4px', color: '#16a34a', fontWeight: 600, fontSize: '13px' }}>
              <i className="ri-phone-fill"></i> 01866225512
            </a>
            <span style={{ color: '#d1d5db' }}>|</span>
            <a href="https://wa.me/8801866225512" target="_blank" rel="noopener noreferrer" style={{ display: 'flex', alignItems: 'center', gap: '4px', color: '#25D366', fontWeight: 600, fontSize: '13px' }}>
              <i className="ri-whatsapp-fill"></i> WhatsApp
            </a>
          </div>
        </div>
      </div>

      <div className="mt-12">
        {/* Divider line above tabs */}
        <div className="border-t border-gray-200 mb-2"></div>
        <div className="flex justify-center items-center gap-3 py-1.5 mb-2 overflow-x-auto no-scrollbar whitespace-nowrap">
          <button onClick={() => setActiveTab('desc')} className={`text-sm transition-colors ${activeTab === 'desc' ? 'text-[#1F2937] font-bold' : 'text-gray-400 font-medium'}`}>Description</button>
          <div className="w-px h-3 bg-gray-300 shrink-0"></div>
          <button onClick={() => setActiveTab('rev')} className={`text-sm transition-colors ${activeTab === 'rev' ? 'text-[#1F2937] font-bold' : 'text-gray-400 font-medium'}`}>Reviews</button>
          <div className="w-px h-3 bg-gray-300 shrink-0"></div>
          <button onClick={() => setActiveTab('qa')} className={`text-sm transition-colors ${activeTab === 'qa' ? 'text-[#1F2937] font-bold' : 'text-gray-400 font-medium'}`}>FAQ</button>
        </div>
        {/* Divider line below tabs */}
        <div className="border-t border-gray-200 mb-4"></div>
        <div>
          {activeTab === 'desc' && (
            <div className="fade-in text-[0.9rem] text-[#6B7280] leading-7 text-left">
              {selectedProduct?.longDesc ? (
                <div className="whitespace-pre-wrap">{parseBoldText(selectedProduct.longDesc)}</div>
              ) : (
                <>
                  <p className="mb-4 whitespace-pre-wrap">{parseBoldText(selectedProduct?.shortDesc || 'Fresh and quality product sourced directly from trusted local farms.')}</p>
                  <ul className="text-left text-xs space-y-2 mt-4">
                    <li className="flex items-center gap-2"><i className="ri-check-line text-[#16a34a]"></i> 100% Fresh & Quality Assured</li>
                    <li className="flex items-center gap-2"><i className="ri-check-line text-[#16a34a]"></i> Sourced from Local Farms</li>
                    <li className="flex items-center gap-2"><i className="ri-check-line text-[#16a34a]"></i> Carefully Packed for Freshness</li>
                  </ul>
                </>
              )}
            </div>
          )}
          {activeTab === 'rev' && (
            <div className="fade-in">
              <div className="flex justify-center mb-6 cursor-pointer text-[#16a34a]" onClick={() => setIsModalOpen(true)}>
                <div className="flex items-center gap-2"><i className="ri-edit-circle-line text-lg"></i><span className="text-sm font-semibold underline decoration-dotted">Write a review</span></div>
              </div>
              {productReviews.length === 0 ? (
                <div className="text-center py-8 text-gray-400">
                  <i className="ri-chat-3-line text-4xl mb-2 block"></i>
                  <p className="text-sm">No reviews yet. Be the first to review!</p>
                </div>
              ) : (
                <div className="flex flex-col gap-4">
                  {productReviews.map((rev) => (
                    <div key={rev.id} className="p-4 rounded-lg bg-gray-50 border border-gray-100 fade-in w-full">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full bg-white border border-gray-200 text-[#16a34a] flex items-center justify-center text-xs font-bold">{rev.initials}</div>
                          <span className="text-sm font-bold text-[#1F2937]">{rev.name}</span>
                          <div className="flex text-yellow-400 text-[10px] ml-1">
                            {[1, 2, 3, 4, 5].map(i => <i key={i} className={`${i <= rev.rating ? 'ri-star-fill' : 'ri-star-line'}`}></i>)}
                          </div>
                        </div>
                        <span className="text-[10px] text-gray-400 font-medium">{rev.date}</span>
                      </div>
                      <div className="pl-[44px]">
                        <p className="text-xs text-[#6B7280] leading-relaxed">{rev.text}</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
          {activeTab === 'qa' && (
            <div className="fade-in">
              <div className="space-y-4">
                {selectedProductFaqs.length > 0 ? (
                  selectedProductFaqs.map((faq) => (
                    <div key={faq.id} className="border border-gray-100 rounded-lg p-4 bg-gray-50">
                      <h4 className="text-sm font-bold text-[#1F2937] mb-1 flex items-center gap-2"><i className="ri-question-fill text-[#16a34a]"></i> {faq.question}</h4>
                      <p className="text-xs text-[#6B7280] pl-6">{faq.answer}</p>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-8 text-gray-400">
                    <i className="ri-question-line text-4xl mb-2 block"></i>
                    <p className="text-sm">No FAQs available for this product.</p>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* You May Like Section */}
      {relatedProducts.length > 0 && (
        <div style={{ marginTop: '48px' }}>
          <div className="flex items-center justify-between mb-6">
            <h2 style={{ fontSize: '20px', fontWeight: 700, color: '#0f172a' }}>You May Like</h2>
            <button className="text-sm font-medium text-[#16a34a] hover:underline flex items-center gap-1">
              View All <i className="ri-arrow-right-line"></i>
            </button>
          </div>
          <div className="flex gap-3 overflow-x-auto no-scrollbar pb-2 -mx-2 px-2">
            {relatedProducts.map((item) => (
            <div
              key={item.id}
              onClick={() => handleRelatedProductClick(item.id)}
              className="flex-shrink-0 w-[140px] bg-white rounded-lg border border-gray-200 hover:border-[#16a34a] transition-all duration-300 cursor-pointer overflow-hidden group"
            >
              <div className="relative h-[100px] bg-gray-50 flex items-center justify-center">
                <img
                  src={item.img}
                  alt={item.name}
                  className="w-[70px] h-[70px] object-contain"
                  loading="lazy"
                />
                <button
                  className="absolute top-1.5 right-1.5 w-6 h-6 bg-[#16a34a] text-white rounded-full flex items-center justify-center hover:bg-[#15803d] transition-colors"
                  onClick={(e) => {
                    e.stopPropagation();
                    addToCart({ id: item.id, name: item.name, price: item.price, oldPrice: item.oldPrice, img: item.img, weight: item.weight });
                  }}
                >
                  <i className="ri-add-line text-sm"></i>
                </button>
              </div>

              <div className="p-2">
                <h3 className="text-xs font-medium text-gray-800 truncate">{item.name}</h3>
                <span className="text-sm font-bold text-[#16a34a]">TK{item.price}</span>
              </div>
            </div>
            ))}
          </div>
        </div>
      )}

      {isModalOpen && (
        <div className="fixed inset-0 z-[300] flex items-center justify-center p-5">
          <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={() => setIsModalOpen(false)}></div>
          <div className="relative bg-white w-full max-w-sm rounded-2xl shadow-2xl p-6">
            <h3 className="text-center text-lg font-bold text-[#1F2937] mb-4">Write a Review</h3>
            <div className="flex justify-center gap-2 mb-6">
              {[1, 2, 3, 4, 5].map(i => (
                <i key={i} className={`ri-star-${i <= userRating ? 'fill' : 'line'} text-2xl cursor-pointer transition-colors ${i <= userRating ? 'text-yellow-400' : 'text-gray-300 hover:text-yellow-400'}`} onClick={() => setUserRating(i)}></i>
              ))}
            </div>
            <div className="space-y-4 mb-6">
              <div>
                <label className="block text-xs font-bold text-gray-400 uppercase mb-1">Your Name</label>
                <input id="reviewName" type="text" className="w-full bg-gray-50 border border-gray-100 rounded-lg px-4 py-3 text-sm focus:outline-none focus:border-[#16a34a]" />
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-400 uppercase mb-1">Review</label>
                <textarea id="reviewText" rows={3} className="w-full bg-gray-50 border border-gray-100 rounded-lg px-4 py-3 text-sm focus:outline-none focus:border-[#16a34a] resize-none"></textarea>
              </div>
            </div>
            <button onClick={handleSubmitReview} className="w-full py-3 bg-[#16a34a] text-white font-bold rounded-lg shadow-lg hover:bg-[#15803d] transition-colors">Submit Review</button>
          </div>
        </div>
      )}
    </div>
  )
}
