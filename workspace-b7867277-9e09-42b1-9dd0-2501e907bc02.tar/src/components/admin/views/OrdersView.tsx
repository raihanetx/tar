'use client'

import React, { useState, useCallback, useEffect } from 'react'
import { useAdmin } from '@/components/admin/context/AdminContext'
import type { Order, OrderItem } from '@/types'

// Extended OrderItem for edit mode
interface EditItem extends OrderItem {
  productId?: number
  tempId: string
}

// Product type
interface Product {
  id: number
  name: string
  image: string
  price: number
  category?: string
  categoryId?: number
  discountType?: 'pct' | 'fixed'
  discountValue?: number
}

// Variant type
interface ProductVariant {
  id: number
  name: string
  stock: number
  price: number
  discountType?: 'pct' | 'fixed'
  discountValue?: number
}

// Category type
interface Category {
  id: number
  name: string
}

export function OrdersView() {
  const {
    orders,
    currentOrderFilter,
    setCurrentOrderFilter,
    selectedOrder,
    setSelectedOrder,
    setOrders,
    showToastMsg,
  } = useAdmin()

  // Edit Mode States
  const [editMode, setEditMode] = useState(false)
  const [editItems, setEditItems] = useState<EditItem[]>([])
  const [allProducts, setAllProducts] = useState<Product[]>([])
  const [allCategories, setAllCategories] = useState<Category[]>([])
  const [productVariants, setProductVariants] = useState<Record<number, ProductVariant[]>>({})
  const [selectedProducts, setSelectedProducts] = useState<number[]>([])
  const [selectedVariants, setSelectedVariants] = useState<Record<number, string>>({})
  const [quantities, setQuantities] = useState<Record<number, number>>({})
  const [saving, setSaving] = useState(false)
  const [itemVariants, setItemVariants] = useState<Record<string, ProductVariant[]>>({})
  const [showAddProduct, setShowAddProduct] = useState(false)
  const [productSearch, setProductSearch] = useState('')
  const [productPage, setProductPage] = useState(1)
  const [variantPopupProductId, setVariantPopupProductId] = useState<number | null>(null)
  const [itemVariantPopupId, setItemVariantPopupId] = useState<string | null>(null)
  const PRODUCTS_PER_PAGE = 4
  const [showInvoice, setShowInvoice] = useState(false)

  // Customer Info Edit States
  const [editCustomer, setEditCustomer] = useState('')
  const [editPhone, setEditPhone] = useState('')
  const [editAddress, setEditAddress] = useState('')

  const filteredOrders = currentOrderFilter === 'all'
    ? orders
    : orders.filter(order => order.status === currentOrderFilter)

  // Fetch all products and categories on mount
  useEffect(() => {
    const fetchData = async () => {
      try {
        const [prodRes, catRes] = await Promise.all([
          fetch('/api/products'),
          fetch('/api/categories')
        ])
        const prodData = await prodRes.json()
        const catData = await catRes.json()
        if (prodData.success) setAllProducts(prodData.data || [])
        if (catData.success) setAllCategories(catData.data || [])

        // Fetch variants for all products
        if (prodData.data && prodData.data.length > 0) {
          const variantsMap: Record<number, ProductVariant[]> = {}
          for (const p of prodData.data) {
            try {
              const vRes = await fetch(`/api/variants?productId=${p.id}`)
              const vData = await vRes.json()
              if (vData.success) variantsMap[p.id] = vData.data || []
            } catch {}
          }
          setProductVariants(variantsMap)
        }
      } catch {}
    }
    fetchData()
  }, [])

  // Enter Edit Mode
  const enterEditMode = async () => {
    if (!selectedOrder) return
    
    // Create edit items with tempIds first
    const itemsWithTempIds = selectedOrder.items.map((item, i) => ({
      ...item,
      productId: item.productId,
      tempId: `item-${i}-${Date.now()}`
    }))
    setEditItems(itemsWithTempIds)
    setEditCustomer(selectedOrder.customer)
    setEditPhone(selectedOrder.phone)
    setEditAddress(selectedOrder.address)
    setEditMode(true)
    
    // Load variants for existing items using the same tempIds
    const newItemVariants: Record<string, ProductVariant[]> = {}
    for (let i = 0; i < selectedOrder.items.length; i++) {
      const item = selectedOrder.items[i]
      if (item.productId) {
        try {
          const res = await fetch(`/api/variants?productId=${item.productId}`)
          const data = await res.json()
          if (data.success) {
            newItemVariants[itemsWithTempIds[i].tempId] = data.data || []
          }
        } catch {}
      }
    }
    setItemVariants(newItemVariants)
  }

  // Exit Edit Mode
  const exitEditMode = () => {
    setEditMode(false)
    setEditItems([])
    setSelectedProducts([])
    setSelectedVariants({})
    setQuantities({})
    setItemVariants({})
    setShowAddProduct(false)
    setProductSearch('')
    setProductPage(1)
    setEditCustomer('')
    setEditPhone('')
    setEditAddress('')
    setVariantPopupProductId(null)
    setItemVariantPopupId(null)
    setShowInvoice(false)
  }

  // Filter products by search (name, category, variety)
  const filteredProducts = allProducts.filter(p => {
    if (!productSearch) return true
    const q = productSearch.toLowerCase()
    const variants = productVariants[p.id] || []
    return p.name.toLowerCase().includes(q) ||
      (p.category && p.category.toLowerCase().includes(q)) ||
      variants.some(v => v.name.toLowerCase().includes(q))
  })

  // Pagination
  const totalPages = Math.ceil(filteredProducts.length / PRODUCTS_PER_PAGE)
  const paginatedProducts = filteredProducts.slice(
    (productPage - 1) * PRODUCTS_PER_PAGE,
    productPage * PRODUCTS_PER_PAGE
  )

  // Get category name
  const getCategoryName = (categoryId?: number) => {
    if (!categoryId) return '—'
    const cat = allCategories.find(c => c.id === categoryId)
    return cat?.name || '—'
  }

  // Get price range for product
  const getPriceRange = (productId: number) => {
    const variants = productVariants[productId]
    if (!variants || variants.length === 0) {
      const product = allProducts.find(p => p.id === productId)
      return product ? `TK ${product.price}` : '—'
    }
    const prices = variants.map(v => v.price)
    const min = Math.min(...prices)
    const max = Math.max(...prices)
    return min === max ? `TK ${min}` : `TK ${min} - ${max}`
  }

  // Get total stock for product
  const getTotalStock = (productId: number) => {
    const variants = productVariants[productId]
    if (!variants || variants.length === 0) return { total: 0, available: 0 }
    const total = variants.reduce((sum, v) => sum + v.stock, 0)
    // For now available = total (can be modified later based on reserved stock)
    return { total, available: total }
  }

  // Get variant names
  const getVariantNames = (productId: number) => {
    const variants = productVariants[productId]
    if (!variants || variants.length === 0) return '—'
    return variants.map(v => v.name).join(', ')
  }

  // Close modal completely
  const closeModal = () => {
    exitEditMode()
    setShowInvoice(false)
    setSelectedOrder(null)
  }

  // Toggle product selection
  const toggleProductSelection = (productId: number) => {
    if (selectedProducts.includes(productId)) {
      // Remove from selection
      setSelectedProducts(selectedProducts.filter(id => id !== productId))
      const newVariants = { ...selectedVariants }
      delete newVariants[productId]
      setSelectedVariants(newVariants)
      const newQuantities = { ...quantities }
      delete newQuantities[productId]
      setQuantities(newQuantities)
    } else {
      // Add to selection
      setSelectedProducts([...selectedProducts, productId])
      setSelectedVariants({ ...selectedVariants, [productId]: '' })
      setQuantities({ ...quantities, [productId]: 1 })
    }
  }

  // Update variant for a product
  const updateProductVariant = (productId: number, variantName: string) => {
    setSelectedVariants({ ...selectedVariants, [productId]: variantName })
  }

  // Update quantity for a product
  const updateProductQty = (productId: number, delta: number) => {
    const currentQty = quantities[productId] || 1
    setQuantities({ ...quantities, [productId]: Math.max(1, currentQty + delta) })
  }

  // Set exact quantity
  const setProductQty = (productId: number, qty: number) => {
    setQuantities({ ...quantities, [productId]: Math.max(1, qty) })
  }

  // Add all selected products to order
  const addSelectedProducts = () => {
    const newItems: EditItem[] = []

    for (const productId of selectedProducts) {
      const variantName = selectedVariants[productId]
      if (!variantName) continue

      const product = allProducts.find(p => p.id === productId)
      const variants = productVariants[productId] || []
      const variant = variants.find(v => v.name === variantName)
      if (!product) continue

      const price = variant ? variant.price : product.price
      const qty = quantities[productId] || 1
      let offerText: string | null = null
      let offerDiscount = 0
      const dVal = variant ? (variant.discountValue || product.discountValue || 0) : (product.discountValue || 0)
      const dType = variant ? (variant.discountType || product.discountType || 'pct') : (product.discountType || 'pct')

      if (dVal > 0) {
        if (dType === 'pct') {
          offerText = `${dVal}% OFF`
          offerDiscount = Math.round(price * qty * (dVal / 100))
        } else {
          offerText = `TK ${dVal} OFF`
          offerDiscount = Math.min(dVal * qty, price * qty)
        }
      }

      newItems.push({
        tempId: `new-${productId}-${Date.now()}`,
        name: product.name,
        variant: variant?.name || null,
        qty,
        basePrice: price,
        offerText,
        offerDiscount,
        couponCode: null,
        couponDiscount: 0,
        productId: product.id
      })
    }

    if (newItems.length === 0) {
      showToastMsg('Select variants first')
      return
    }

    setEditItems([...editItems, ...newItems])
    setSelectedProducts([])
    setSelectedVariants({})
    setQuantities({})
    setShowAddProduct(false)
    showToastMsg(`${newItems.length} product(s) added!`)
  }

  // Update quantity
  const updateQty = (tempId: string, delta: number) => {
    setEditItems(editItems.map(item => {
      if (item.tempId !== tempId) return item
      const newQty = Math.max(1, item.qty + delta)
      let newDiscount = item.offerDiscount
      if (item.offerText && item.basePrice) {
        const match = item.offerText.match(/(\d+)% OFF/)
        if (match) newDiscount = Math.round(item.basePrice * newQty * (parseInt(match[1]) / 100))
        else {
          const fixed = item.offerText.match(/TK (\d+) OFF/)
          if (fixed) newDiscount = Math.min(parseInt(fixed[1]) * newQty, item.basePrice * newQty)
        }
      }
      return { ...item, qty: newQty, offerDiscount: newDiscount }
    }))
  }

  // Load variants for item
  const loadItemVariants = async (tempId: string, productId: number) => {
    if (itemVariants[tempId]) return
    try {
      const res = await fetch(`/api/variants?productId=${productId}`)
      const data = await res.json()
      if (data.success) setItemVariants(prev => ({ ...prev, [tempId]: data.data || [] }))
    } catch {}
  }

  // Update variant
  const updateVariant = (tempId: string, variantName: string) => {
    const vList = itemVariants[tempId]
    if (!vList) return
    const v = vList.find(x => x.name === variantName)
    if (!v) return

    setEditItems(editItems.map(item => {
      if (item.tempId !== tempId) return item
      let offerText: string | null = null
      let offerDiscount = 0
      if (v.discountValue && v.discountValue > 0) {
        if (v.discountType === 'pct') {
          offerText = `${v.discountValue}% OFF`
          offerDiscount = Math.round(v.price * item.qty * (v.discountValue / 100))
        } else {
          offerText = `TK ${v.discountValue} OFF`
          offerDiscount = Math.min(v.discountValue * item.qty, v.price * item.qty)
        }
      }
      return { ...item, variant: v.name, basePrice: v.price, offerText, offerDiscount }
    }))
  }

  // Delete item
  const deleteItem = (tempId: string) => {
    setEditItems(editItems.filter(item => item.tempId !== tempId))
  }

  // Calculate totals
  const calcTotals = () => {
    const subtotal = editItems.reduce((s, i) => s + i.basePrice * i.qty, 0)
    const discount = editItems.reduce((s, i) => s + (i.offerDiscount || 0), 0)
    const coupon = editItems.reduce((s, i) => s + (i.couponDiscount || 0), 0)
    const delivery = selectedOrder?.delivery || 0
    return { subtotal, discount, coupon, delivery, total: subtotal - discount - coupon + delivery }
  }

  // Save changes
  const saveChanges = async () => {
    if (!selectedOrder || saving) return
    setSaving(true)
    const { subtotal, discount, coupon, delivery, total } = calcTotals()

    try {
      const res = await fetch('/api/orders', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id: selectedOrder.id,
          items: editItems.map(i => ({
            name: i.name, variant: i.variant, qty: i.qty, basePrice: i.basePrice,
            offerText: i.offerText, offerDiscount: i.offerDiscount || 0,
            couponCode: i.couponCode, couponDiscount: i.couponDiscount || 0, productId: i.productId
          })),
          subtotal, discount, couponAmount: coupon, delivery, total,
          customer: editCustomer,
          phone: editPhone,
          address: editAddress
        })
      })
      const result = await res.json()
      if (result.success) {
        setOrders(orders.map(o => o.id === selectedOrder.id ? { 
          ...o, 
          items: editItems, 
          subtotal, 
          discount, 
          couponAmount: coupon, 
          total,
          customer: editCustomer,
          phone: editPhone,
          address: editAddress
        } : o))
        setSelectedOrder({ 
          ...selectedOrder, 
          items: editItems, 
          subtotal, 
          discount, 
          couponAmount: coupon, 
          total,
          customer: editCustomer,
          phone: editPhone,
          address: editAddress
        })
        showToastMsg('Order updated!')
        exitEditMode()
      } else showToastMsg('Failed to update')
    } catch { showToastMsg('Error updating') }
    finally { setSaving(false) }
  }

  // Update order status
  const updateStatus = async (id: string, status: 'approved' | 'canceled') => {
    try {
      const res = await fetch('/api/orders', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, status, canceledBy: status === 'canceled' ? 'Admin' : null })
      })
      if ((await res.json()).success) {
        setOrders(orders.map(o => o.id === id ? { ...o, status, canceledBy: status === 'canceled' ? 'Admin' : null } : o))
        showToastMsg(status === 'approved' ? 'Approved!' : 'Rejected!')
      }
    } catch {}
  }

  // Update courier status
  const updateCourier = async (id: string, courierStatus: string) => {
    try {
      const res = await fetch('/api/orders', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, courierStatus })
      })
      if ((await res.json()).success) {
        setOrders(orders.map(o => o.id === id ? { ...o, courierStatus } : o))
        showToastMsg('Status updated!')
      }
    } catch {}
  }

  const copyPhone = (phone: string) => {
    navigator.clipboard.writeText(phone)
    showToastMsg('Copied!')
  }

  const courierOpts = [
    { value: 'Processing', color: '#f59e0b' },
    { value: 'Picked Up', color: '#3b82f6' },
    { value: 'On The Way', color: '#8b5cf6' },
    { value: 'Delivered', color: '#16a34a' }
  ]

  // Get current totals (edit or view)
  const currentTotals = editMode ? calcTotals() : {
    subtotal: selectedOrder?.subtotal || 0,
    discount: selectedOrder?.discount || 0,
    coupon: selectedOrder?.couponAmount || 0,
    delivery: selectedOrder?.delivery || 0,
    total: selectedOrder?.total || 0
  }

  return (
    <div className="p-4 md:p-8 bg-white min-h-[calc(100vh-80px)]" style={{ fontFamily: "'Inter', sans-serif" }}>
      {/* Header */}
      <div className="mb-6 flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-bold text-[#1c2333]">Order Management</h1>
          <p className="text-[#8a96a8] text-sm mt-1">Manage all incoming orders</p>
        </div>
        <span className="px-4 py-1.5 bg-[#f59e0b]/10 text-[#f59e0b] text-[13px] font-bold rounded-lg">
          {orders.filter(o => o.status === 'pending').length} Pending
        </span>
      </div>

      {/* Filters */}
      <div className="mb-4 flex gap-2 flex-wrap">
        {['all', 'pending', 'approved', 'canceled'].map(f => (
          <button key={f} onClick={() => setCurrentOrderFilter(f as any)}
            className={`px-4 py-2 text-[13px] font-semibold rounded-lg border transition-colors ${
              currentOrderFilter === f
                ? f === 'pending' ? 'bg-[#f59e0b] text-white border-[#f59e0b]'
                  : f === 'approved' ? 'bg-[#18a87a] text-white border-[#18a87a]'
                  : f === 'canceled' ? 'bg-[#ef4444] text-white border-[#ef4444]'
                  : 'bg-[#1c2333] text-white border-[#1c2333]'
                : 'bg-white text-[#8a96a8] border-[#e4e7ee] hover:bg-[#f5f6f9]'
            }`}>
            {f.charAt(0).toUpperCase() + f.slice(1)}
          </button>
        ))}
      </div>

      {/* Table */}
      <div className="bg-white border border-[#e4e7ee] rounded-xl shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-[13px]">
            <thead className="bg-white border-b border-[#e4e7ee]">
              <tr>
                <th className="text-left px-4 py-3 text-[11px] font-bold text-[#8a96a8] uppercase">Order</th>
                <th className="text-left px-4 py-3 text-[11px] font-bold text-[#8a96a8] uppercase">Customer</th>
                <th className="text-left px-4 py-3 text-[11px] font-bold text-[#8a96a8] uppercase">Payment</th>
                <th className="text-left px-4 py-3 text-[11px] font-bold text-[#8a96a8] uppercase">Status</th>
                <th className="text-left px-4 py-3 text-[11px] font-bold text-[#8a96a8] uppercase">Courier</th>
                <th className="text-left px-4 py-3 text-[11px] font-bold text-[#8a96a8] uppercase">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#e4e7ee]">
              {filteredOrders.map(order => (
                <tr key={order.id} className="hover:bg-[#f5f6f9]/50">
                  <td className="px-4 py-3">
                    <span className="font-mono font-medium">{order.id}</span>
                    <div className="text-[11px] text-[#8a96a8]">{order.time}</div>
                  </td>
                  <td className="px-4 py-3">
                    <span className="font-medium">{order.customer}</span>
                    <div className="text-[11px] text-[#8a96a8]">{order.phone}</div>
                  </td>
                  <td className="px-4 py-3">
                    <span className="text-[11px] font-bold uppercase">{order.paymentMethod}</span>
                    <div className="text-[11px] text-[#8a96a8] truncate max-w-[120px]">{order.address}</div>
                  </td>
                  <td className="px-4 py-3" onClick={e => e.stopPropagation()}>
                    {order.status === 'pending' ? (
                      <div className="flex gap-2">
                        <span onClick={() => updateStatus(order.id, 'approved')} className="text-[#18a87a] font-bold text-[11px] cursor-pointer hover:underline">Approve</span>
                        <span className="text-[#8a96a8]">|</span>
                        <span onClick={() => updateStatus(order.id, 'canceled')} className="text-[#ef4444] font-bold text-[11px] cursor-pointer hover:underline">Reject</span>
                      </div>
                    ) : (
                      <span className={`font-bold text-[11px] ${order.status === 'approved' ? 'text-[#18a87a]' : 'text-[#ef4444]'}`}>
                        {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                      </span>
                    )}
                  </td>
                  <td className="px-4 py-3" onClick={e => e.stopPropagation()}>
                    <select value={order.courierStatus || 'Processing'} onChange={e => updateCourier(order.id, e.target.value)}
                      className="text-[11px] px-2 py-1 rounded border border-[#e4e7ee] bg-white"
                      style={{ color: courierOpts.find(o => o.value === (order.courierStatus || 'Processing'))?.color }}>
                      {courierOpts.map(o => <option key={o.value} value={o.value}>{o.value}</option>)}
                    </select>
                  </td>
                  <td className="px-4 py-3">
                    <span onClick={() => setSelectedOrder(order)} className="text-[#3f72f5] font-medium cursor-pointer hover:underline">View</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* View/Edit Modal */}
      {selectedOrder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-6 bg-[#1c2333]/40 backdrop-blur-sm" onClick={closeModal}>
          <div className="w-full max-w-[720px] max-h-[90vh] overflow-y-auto bg-white border border-[#e4e7ee] rounded-xl shadow-lg p-5 flex flex-col gap-4" onClick={e => e.stopPropagation()}>

            {/* ACTION BAR */}
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-2 text-[13px]">
                <span className="font-mono font-semibold">{selectedOrder.id}</span>
                <span className="text-[#8a96a8]">|</span>
                <span className="text-[#8a96a8]">{selectedOrder.date}</span>
                <span className="text-[#8a96a8]">|</span>
                <span className="text-xs uppercase font-medium">{selectedOrder.paymentMethod}</span>
              </div>

              {/* ACTION BUTTONS */}
              <div className="flex items-center gap-1.5">
                <button onClick={() => window.open('tel:' + selectedOrder.phone)} 
                  className="h-[28px] w-[28px] rounded flex items-center justify-center text-[#8a96a8] hover:text-[#3f72f5] hover:bg-[#f5f6f9]">
                  <i className="ri-phone-fill text-[15px]"></i>
                </button>
                <button onClick={() => window.open('https://wa.me/' + selectedOrder.phone.replace(/[^0-9]/g, ''))} 
                  className="h-[28px] w-[28px] rounded flex items-center justify-center text-[#8a96a8] hover:text-[#18a87a] hover:bg-[#f5f6f9]">
                  <i className="ri-whatsapp-line text-[15px]"></i>
                </button>
                <button onClick={() => copyPhone(selectedOrder.phone)} 
                  className="h-[28px] w-[28px] rounded flex items-center justify-center text-[#8a96a8] hover:text-[#1c2333] hover:bg-[#f5f6f9]">
                  <i className="ri-file-copy-line text-[15px]"></i>
                </button>
                <button onClick={() => setShowInvoice(true)} 
                  className="h-[28px] w-[28px] rounded flex items-center justify-center text-[#8a96a8] hover:text-[#18a87a] hover:bg-[#f5f6f9]">
                  <i className="ri-bill-line text-[15px]"></i>
                </button>

                <div className="w-[1px] h-[18px] bg-[#e4e7ee] mx-1"></div>

                {/* Edit/Done Button */}
                {editMode ? (
                  <button onClick={saveChanges} disabled={saving}
                    className="h-[28px] px-3 rounded flex items-center justify-center bg-[#18a87a] text-white text-[11px] font-semibold gap-1 hover:bg-[#16a34a] disabled:opacity-50">
                    {saving ? 'Saving...' : 'Save'}
                  </button>
                ) : (
                  <button onClick={enterEditMode} 
                    className="h-[28px] px-3 rounded flex items-center justify-center bg-[#f59e0b] text-white text-[11px] font-semibold gap-1 hover:bg-[#d97706]">
                    <i className="ri-edit-line text-[13px]"></i> Edit
                  </button>
                )}

                <button onClick={closeModal} 
                  className="h-[30px] w-[30px] rounded-[4px] flex items-center justify-center border border-[#e4e7ee] bg-white text-[#8a96a8] hover:bg-[#f5f6f9]">
                  <i className="ri-close-line text-[18px]"></i>
                </button>
              </div>
            </div>

            {/* CUSTOMER INFO (SINGLE LINE) */}
            <div className="border border-[#e4e7ee] rounded p-3 bg-white text-sm flex items-center gap-2">
              {editMode ? (
                <>
                  <span
                    contentEditable
                    suppressContentEditableWarning
                    onBlur={e => setEditCustomer(e.currentTarget.textContent || '')}
                    className="font-medium outline-none cursor-text"
                  >{editCustomer}</span>
                  <span className="text-[#8a96a8]">|</span>
                  <span
                    contentEditable
                    suppressContentEditableWarning
                    onBlur={e => setEditPhone(e.currentTarget.textContent || '')}
                    className="font-medium outline-none cursor-text"
                  >{editPhone}</span>
                  <span className="text-[#8a96a8]">|</span>
                  <span
                    contentEditable
                    suppressContentEditableWarning
                    onBlur={e => setEditAddress(e.currentTarget.textContent || '')}
                    className="font-medium outline-none cursor-text flex-1"
                  >{editAddress}</span>
                </>
              ) : (
                <>
                  <span className="font-medium">{selectedOrder.customer}</span>
                  <span className="text-[#8a96a8]">|</span>
                  <span className="font-medium">{selectedOrder.phone}</span>
                  <span className="text-[#8a96a8]">|</span>
                  <span className="font-medium">{selectedOrder.address}</span>
                </>
              )}
            </div>

            {/* ITEMS TABLE */}
            <div className="border border-[#e4e7ee] rounded-[4px] overflow-hidden">
              <table className="w-full text-sm">
                <thead className="bg-white border-b border-[#e4e7ee]">
                  <tr>
                    <th className="text-left px-4 py-2 text-xs uppercase text-[#8a96a8]">Item</th>
                    <th className="text-left px-4 py-2 text-xs uppercase text-[#8a96a8]">Variant</th>
                    <th className="text-center px-4 py-2 text-xs uppercase text-[#8a96a8]">Qty</th>
                    <th className="text-right px-4 py-2 text-xs uppercase text-[#8a96a8]">Price</th>
                  </tr>
                </thead>
                <tbody>
                  {(editMode ? editItems : selectedOrder?.items || []).map((item, i) => {
                    const itemTotal = item.basePrice * item.qty - (item.offerDiscount || 0) - (item.couponDiscount || 0)
                    const tempId = (item as EditItem).tempId
                    
                    return (
                      <tr key={editMode ? tempId : i} className="border-b border-[#e4e7ee] last:border-0">
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-2">
                            <span>{item.name}</span>
                            {item.offerText && <span className="text-[10px] font-bold text-[#ef4444]">[{item.offerText}]</span>}
                          </div>
                        </td>
                        <td className="px-4 py-3">
                          {editMode ? (
                            <select
                              value={item.variant || ''}
                              onClick={() => {
                                // Load variants when clicking the dropdown if not loaded
                                if (item.productId && !itemVariants[tempId]?.length) {
                                  loadItemVariants(tempId, item.productId)
                                }
                              }}
                              onFocus={() => {
                                // Also load on focus for better UX
                                if (item.productId && !itemVariants[tempId]?.length) {
                                  loadItemVariants(tempId, item.productId)
                                }
                              }}
                              onChange={(e) => updateVariant(tempId, e.target.value)}
                              className="px-2 py-1 border border-[#e5e7eb] rounded-[3px] text-[13px] bg-white focus:outline-none focus:ring-1 focus:ring-[#18a87a] focus:border-[#18a87a] min-w-[80px]"
                            >
                              {/* Show current variant as selected even if variants not loaded yet */}
                              {item.variant && !itemVariants[tempId]?.length && (
                                <option value={item.variant}>{item.variant}</option>
                              )}
                              {itemVariants[tempId]?.map(v => (
                                <option key={v.id} value={v.name}>{v.name}</option>
                              ))}
                            </select>
                          ) : (
                            <span className="text-[#8a96a8]">{item.variant || '—'}</span>
                          )}
                        </td>
                        <td className="text-center px-4 py-3">
                          {editMode ? (
                            <div className="flex items-center justify-center gap-1">
                              <button onClick={() => updateQty(tempId, -1)}
                                className="w-6 h-6 rounded-[3px] border border-[#e4e7ee] bg-white flex items-center justify-center hover:bg-[#f5f6f9] text-[12px]">−</button>
                              <span className="w-5 text-center font-medium">{item.qty}</span>
                              <button onClick={() => updateQty(tempId, 1)}
                                className="w-6 h-6 rounded-[3px] border border-[#e4e7ee] bg-white flex items-center justify-center hover:bg-[#f5f6f9] text-[12px]">+</button>
                            </div>
                          ) : (
                            <span>{item.qty}</span>
                          )}
                        </td>
                        <td className="text-right font-semibold px-4 py-3">
                          <div className="flex items-center justify-end gap-3">
                            <div>
                              {item.offerDiscount > 0 || item.couponDiscount > 0 ? (
                                <div>
                                  <div className="line-through text-[#8a96a8] font-normal text-[12px]">TK {item.basePrice * item.qty}</div>
                                  <div>TK {itemTotal}</div>
                                </div>
                              ) : `TK ${itemTotal}`}
                            </div>
                            {editMode && (
                              <button onClick={() => deleteItem(tempId)}
                                className="w-6 h-6 rounded-[3px] bg-[#ef4444]/10 text-[#ef4444] flex items-center justify-center hover:bg-[#ef4444] hover:text-white flex-shrink-0">
                                <i className="ri-delete-bin-line text-[12px]"></i>
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>

            {/* Add Product Section */}
            {editMode && (
              <div className="border border-[#e4e7ee] rounded-[4px] p-4 bg-white">
                {/* Plain Text Toggle */}
                <span
                  onClick={() => {
                    setShowAddProduct(!showAddProduct)
                    if (!showAddProduct) {
                      setProductPage(1)
                      setProductSearch('')
                    }
                  }}
                  className="text-[#18a87a] text-sm cursor-pointer hover:underline"
                >
                  + Add Product
                </span>

                {/* Search & Products */}
                {showAddProduct && (
                  <div className="mt-3">
                    {/* Search Bar */}
                    <div className="relative mb-3">
                      <i className="ri-search-line absolute left-3 top-1/2 -translate-y-1/2 text-[#9ca3af]"></i>
                      <input
                        type="text"
                        value={productSearch}
                        onChange={e => {
                          setProductSearch(e.target.value)
                          setProductPage(1)
                        }}
                        placeholder="Search products by name, category, or variety..."
                        className="w-full pl-9 pr-4 py-2 border border-[#e5e7eb] rounded-[4px] text-sm focus:outline-none focus:ring-1 focus:ring-[#18a87a] focus:border-[#18a87a]"
                        autoFocus
                      />
                    </div>

                    {/* Table */}
                    <div className="overflow-x-auto border border-[#e5e7eb] rounded-[4px]">
                      <table className="w-full text-sm">
                        <thead className="bg-white border-b border-[#e5e7eb]">
                          <tr>
                            <th className="px-4 py-3 text-left text-xs font-medium text-[#6b7280] uppercase tracking-wider">Product</th>
                            <th className="px-4 py-3 text-left text-xs font-medium text-[#6b7280] uppercase tracking-wider">Variety</th>
                            <th className="px-4 py-3 text-left text-xs font-medium text-[#6b7280] uppercase tracking-wider">Quantity</th>
                            <th className="px-4 py-3 text-left text-xs font-medium text-[#6b7280] uppercase tracking-wider">Stock</th>
                            <th className="px-4 py-3 text-left text-xs font-medium text-[#6b7280] uppercase tracking-wider">Action</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-[#e5e7eb]">
                          {productSearch.trim() && paginatedProducts.map(p => {
                              const variants = productVariants[p.id] || []
                              const totalStock = variants.reduce((acc, v) => acc + v.stock, 0)
                              const selectedVariantName = selectedVariants[p.id] || (variants[0]?.name || '')
                              const currentVariant = variants.find(v => v.name === selectedVariantName)
                              const variantStock = currentVariant?.stock || 0
                              
                              return (
                                <tr key={p.id} className="hover:bg-[#f9fafb]">
                                  {/* Product: image + name + category */}
                                  <td className="px-4 py-3">
                                    <div className="flex items-center gap-3">
                                      <div className="w-10 h-10 bg-[#f3f4f6] rounded flex items-center justify-center flex-shrink-0 overflow-hidden">
                                        {p.image ? (
                                          <img src={p.image} alt={p.name} className="w-full h-full object-cover" />
                                        ) : (
                                          <i className="ri-image-line text-lg text-[#9ca3af]"></i>
                                        )}
                                      </div>
                                      <div>
                                        <div className="font-medium text-[#1f2937]">{p.name}</div>
                                        <div className="text-xs text-[#6b7280]">{p.category || '—'}</div>
                                      </div>
                                    </div>
                                  </td>

                                  {/* Variety: native select dropdown */}
                                  <td className="px-4 py-3">
                                    <select
                                      value={selectedVariantName}
                                      onChange={(e) => {
                                        const newVariant = e.target.value
                                        setSelectedVariants({ ...selectedVariants, [p.id]: newVariant })
                                        const v = variants.find(v => v.name === newVariant)
                                        if (v && (quantities[p.id] || 1) > v.stock) {
                                          setQuantities({ ...quantities, [p.id]: v.stock })
                                        }
                                      }}
                                      className="px-2 py-1 border border-[#e5e7eb] rounded-[4px] text-sm bg-white focus:outline-none focus:ring-1 focus:ring-[#18a87a] focus:border-[#18a87a]"
                                    >
                                      {variants.map(v => (
                                        <option key={v.id} value={v.name}>
                                          {v.name} (TK {v.price})
                                        </option>
                                      ))}
                                    </select>
                                  </td>

                                  {/* Quantity with plus/minus */}
                                  <td className="px-4 py-3">
                                    <div className="flex items-center gap-1">
                                      <button
                                        onClick={() => {
                                          const current = quantities[p.id] || 1
                                          if (current > 1) {
                                            setQuantities({ ...quantities, [p.id]: current - 1 })
                                          }
                                        }}
                                        className="w-6 h-6 flex items-center justify-center border border-[#e5e7eb] rounded-[3px] hover:bg-[#f3f4f6]"
                                      >
                                        −
                                      </button>
                                      <span className="w-8 text-center">{quantities[p.id] || 1}</span>
                                      <button
                                        onClick={() => {
                                          const current = quantities[p.id] || 1
                                          if (current < variantStock) {
                                            setQuantities({ ...quantities, [p.id]: current + 1 })
                                          }
                                        }}
                                        className="w-6 h-6 flex items-center justify-center border border-[#e5e7eb] rounded-[3px] hover:bg-[#f3f4f6]"
                                      >
                                        +
                                      </button>
                                    </div>
                                  </td>

                                  {/* Stock: "variantStock out of totalStock" */}
                                  <td className="px-4 py-3">
                                    <span className="text-[#1f2937]">{variantStock} out of {totalStock}</span>
                                  </td>

                                  {/* Add button */}
                                  <td className="px-4 py-3">
                                    <button
                                      onClick={() => {
                                        const variantName = selectedVariants[p.id] || (variants[0]?.name || '')
                                        if (!variantName) {
                                          showToastMsg('Select variant first')
                                          return
                                        }
                                        const variant = variants.find(v => v.name === variantName)
                                        if (!variant) return
                                        
                                        const price = variant.price
                                        const qtyToAdd = quantities[p.id] || 1
                                        let offerText: string | null = null
                                        let offerDiscount = 0
                                        const dVal = variant.discountValue || p.discountValue || 0
                                        const dType = variant.discountType || p.discountType || 'pct'

                                        if (dVal > 0) {
                                          if (dType === 'pct') {
                                            offerText = `${dVal}% OFF`
                                            offerDiscount = Math.round(price * qtyToAdd * (dVal / 100))
                                          } else {
                                            offerText = `TK ${dVal} OFF`
                                            offerDiscount = Math.min(dVal * qtyToAdd, price * qtyToAdd)
                                          }
                                        }

                                        setEditItems([...editItems, {
                                          tempId: `new-${p.id}-${Date.now()}`,
                                          name: p.name,
                                          variant: variant.name,
                                          qty: qtyToAdd,
                                          basePrice: price,
                                          offerText,
                                          offerDiscount,
                                          couponCode: null,
                                          couponDiscount: 0,
                                          productId: p.id
                                        }])

                                        showToastMsg('Product added!')
                                      }}
                                      className="px-3 py-1 bg-[#18a87a] text-white rounded-[4px] text-xs font-medium hover:bg-[#16a34a] transition flex items-center gap-1"
                                    >
                                      <i className="ri-add-line"></i> Add
                                    </button>
                                  </td>
                                </tr>
                              )
                            })}
                            {(!productSearch.trim() || paginatedProducts.length === 0) && (
                              <tr>
                                <td colSpan={5} className="px-4 py-8 text-center text-[#9ca3af]">
                                  {!productSearch.trim() ? 'Type to search products...' : 'No products found'}
                                </td>
                              </tr>
                            )}
                          </tbody>
                        </table>
                      </div>

                    {/* Pagination */}
                    {productSearch.trim() && filteredProducts.length > 0 && (
                      <div className="flex items-center justify-between mt-4 text-sm">
                        <span className="text-[#4b5563]">
                          Showing {filteredProducts.length > 0 ? (productPage - 1) * PRODUCTS_PER_PAGE + 1 : 0} – {Math.min(productPage * PRODUCTS_PER_PAGE, filteredProducts.length)} of {filteredProducts.length} products
                        </span>
                        <div className="flex gap-2">
                          <button
                            onClick={() => setProductPage(Math.max(1, productPage - 1))}
                            disabled={productPage === 1}
                            className="px-3 py-1 border border-[#e5e7eb] rounded-[4px] disabled:opacity-50 disabled:cursor-not-allowed hover:bg-[#f3f4f6]"
                          >
                            Previous
                          </button>
                          <button
                            onClick={() => setProductPage(Math.min(totalPages, productPage + 1))}
                            disabled={productPage === totalPages || totalPages === 0}
                            className="px-3 py-1 border border-[#e5e7eb] rounded-[4px] disabled:opacity-50 disabled:cursor-not-allowed hover:bg-[#f3f4f6]"
                          >
                            Next
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}

            {/* CALCULATION - Single Line */}
            <div className="border border-[#e4e7ee] rounded p-3 bg-white text-sm">
              <div className="flex items-center justify-between gap-2">
                <span className="text-[#6b7280] text-xs font-medium">Order Calculation</span>
                <div className="flex items-center gap-2 flex-wrap justify-end">
                  <span>Subtotal: <span className="font-medium">TK {currentTotals.subtotal}</span></span>
                  {currentTotals.discount > 0 && (
                    <>
                      <span className="text-[#e4e7ee]">|</span>
                      <span>Discount: <span className="font-medium text-[#ef4444]">TK {currentTotals.discount}</span></span>
                    </>
                  )}
                  {currentTotals.coupon > 0 && (
                    <>
                      <span className="text-[#e4e7ee]">|</span>
                      <span>Coupon: <span className="font-medium text-[#18a87a]">TK {currentTotals.coupon}</span></span>
                    </>
                  )}
                  <span className="text-[#e4e7ee]">|</span>
                  <span>Delivery: <span className="font-medium">{currentTotals.delivery === 0 ? 'Free' : `TK ${currentTotals.delivery}`}</span></span>
                  <span className="text-[#e4e7ee]">|</span>
                  <span className="font-semibold">Total: TK {currentTotals.total}</span>
                </div>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* INVOICE MODAL - Horizontal Style */}
      {showInvoice && selectedOrder && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/50" onClick={() => setShowInvoice(false)}>
          <div className="bg-white w-[600px] rounded-lg shadow-2xl overflow-hidden" onClick={e => e.stopPropagation()}>
            {/* Header */}
            <div className="bg-white px-6 py-4 flex items-center justify-between border-b border-[#e5e7eb]">
              <div>
                <div className="text-xl font-bold text-[#1c2333]">EcoMart</div>
                <div className="text-[11px] text-[#6b7280]">Your Trusted Grocery Partner</div>
              </div>
              <div className="text-right">
                <div className="text-xs text-[#6b7280] uppercase tracking-wider">Invoice</div>
                <div className="text-sm font-bold text-[#1c2333] mt-0.5">{selectedOrder.id}</div>
              </div>
            </div>

            {/* Content */}
            <div className="p-5">
              {/* Top Row: Invoice Info & Customer */}
              <div className="grid grid-cols-2 gap-6 pb-4 border-b border-[#e5e7eb]">
                <div>
                  <div className="text-[10px] text-[#9ca3af] uppercase tracking-wider mb-2">Invoice Details</div>
                  <div className="space-y-1 text-[13px]">
                    <div className="flex justify-between">
                      <span className="text-[#6b7280]">Date</span>
                      <span className="text-[#1c2333]">{selectedOrder.date}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-[#6b7280]">Time</span>
                      <span className="text-[#1c2333]">{selectedOrder.time}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-[#6b7280]">Payment</span>
                      <span className="text-[#1c2333] uppercase font-medium">{selectedOrder.paymentMethod}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-[#6b7280]">Status</span>
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        selectedOrder.status === 'approved' ? 'bg-[#dcfce7] text-[#16a34a]' : 
                        selectedOrder.status === 'canceled' ? 'bg-[#fee2e2] text-[#dc2626]' : 
                        'bg-[#fef3c7] text-[#d97706]'
                      }`}>
                        {selectedOrder.status.toUpperCase()}
                      </span>
                    </div>
                  </div>
                </div>
                <div>
                  <div className="text-[10px] text-[#9ca3af] uppercase tracking-wider mb-2">Bill To</div>
                  <div className="text-[13px] font-semibold text-[#1c2333]">{selectedOrder.customer}</div>
                  <div className="text-[12px] text-[#6b7280]">{selectedOrder.phone}</div>
                  <div className="text-[12px] text-[#6b7280]">{selectedOrder.address}</div>
                </div>
              </div>

              {/* Items Table */}
              <div className="py-4 border-b border-[#e5e7eb]">
                <table className="w-full text-[12px]">
                  <thead>
                    <tr className="border-b border-[#e5e7eb]">
                      <th className="text-left py-2 text-[#9ca3af] font-medium uppercase text-[10px]">Item</th>
                      <th className="text-center py-2 text-[#9ca3af] font-medium uppercase text-[10px] w-20">Variant</th>
                      <th className="text-center py-2 text-[#9ca3af] font-medium uppercase text-[10px] w-16">Qty</th>
                      <th className="text-right py-2 text-[#9ca3af] font-medium uppercase text-[10px] w-20">Amount</th>
                    </tr>
                  </thead>
                  <tbody>
                    {selectedOrder.items.map((item, i) => (
                      <tr key={i} className="border-b border-[#f3f4f6] last:border-0">
                        <td className="py-2 text-[#1c2333]">
                          {item.name}
                          {item.offerText && <span className="text-[#ef4444] text-[10px] ml-1">({item.offerText})</span>}
                        </td>
                        <td className="text-center text-[#6b7280]">{item.variant || '-'}</td>
                        <td className="text-center text-[#6b7280]">{item.qty}</td>
                        <td className="text-right font-medium text-[#1c2333]">TK {item.basePrice * item.qty - (item.offerDiscount || 0)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Bottom Row: Summary & Total */}
              <div className="grid grid-cols-2 gap-6 pt-4">
                <div className="space-y-1 text-[12px]">
                  <div className="flex justify-between">
                    <span className="text-[#6b7280]">Subtotal</span>
                    <span className="text-[#1c2333]">TK {selectedOrder.subtotal}</span>
                  </div>
                  {selectedOrder.discount > 0 && (
                    <div className="flex justify-between">
                      <span className="text-[#6b7280]">Discount</span>
                      <span className="text-[#ef4444]">-TK {selectedOrder.discount}</span>
                    </div>
                  )}
                  {selectedOrder.couponAmount > 0 && (
                    <div className="flex justify-between">
                      <span className="text-[#6b7280]">Coupon</span>
                      <span className="text-[#18a87a]">-TK {selectedOrder.couponAmount}</span>
                    </div>
                  )}
                  <div className="flex justify-between">
                    <span className="text-[#6b7280]">Delivery</span>
                    <span className="text-[#1c2333]">{selectedOrder.delivery === 0 ? 'Free' : `TK ${selectedOrder.delivery}`}</span>
                  </div>
                </div>
                <div className="bg-white rounded p-3 flex justify-between items-center border border-[#e5e7eb]">
                  <span className="text-sm font-bold text-[#1c2333]">Total</span>
                  <span className="text-xl font-bold text-[#18a87a]">TK {selectedOrder.total}</span>
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="px-5 py-2 text-center text-[11px] text-[#9ca3af] border-t border-[#e5e7eb]">
              Thank you for shopping with us!
            </div>

            {/* Actions */}
            <div className="flex border-t border-[#e5e7eb]">
              <button onClick={() => window.print()} 
                className="flex-1 py-3 flex items-center justify-center gap-1.5 text-[#18a87a] text-xs font-semibold hover:bg-[#f9fafb]">
                <i className="ri-printer-line"></i> Print
              </button>
              <div className="w-px bg-[#e5e7eb]"></div>
              <button onClick={() => setShowInvoice(false)} 
                className="flex-1 py-3 flex items-center justify-center gap-1.5 text-[#6b7280] text-xs font-semibold hover:bg-[#f9fafb]">
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default OrdersView
