import type { NextConfig } from "next";
import { config } from 'dotenv';
import { resolve } from 'path';

// Force load .env file and override system environment
config({ path: resolve(__dirname, '.env'), override: true });

const nextConfig: NextConfig = {
  output: "standalone",
  typescript: {
    // Production builds should fail on TypeScript errors
    // Set to false for production readiness
    ignoreBuildErrors: false,
  },
  reactStrictMode: true,
  allowedDevOrigins: [
    '.space.z.ai',
    '.z.ai',
  ],
  env: {
    DATABASE_URL: process.env.DATABASE_URL,
  },
};

export default nextConfig;

