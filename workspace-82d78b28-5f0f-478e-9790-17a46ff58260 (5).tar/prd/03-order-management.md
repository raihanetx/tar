# EcoMart - Order Management PRD

## Overview
This document defines the complete logic and specifications for the Order Management feature in EcoMart admin dashboard.

---

## 1. Database Schema

### Table: `orders`

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `id` | String (CUID) | Auto | Unique identifier |
| `order_number` | String | ✅ Yes | Sequential order number (ORD001, ORD002...) |
| `customer_name` | String | ✅ Yes | Customer full name |
| `customer_phone` | String | ✅ Yes | Customer phone number |
| `customer_address` | String | ✅ Yes | Full delivery address |
| `city` | String | ✅ Yes | City name |
| `location_type` | Enum | ✅ Yes | "inside_dhaka" / "outside_dhaka" / "universal" |
| `subtotal` | Decimal(10,2) | ✅ Yes | Sum of all item totals |
| `delivery_charge` | Decimal(10,2) | ✅ Yes | Delivery charge amount |
| `coupon_code` | String | ❌ Optional | Coupon code applied (if any) |
| `coupon_discount` | Decimal(10,2) | ❌ Optional | Total coupon discount amount |
| `total` | Decimal(10,2) | ✅ Yes | Final order total |
| `status` | Enum | ✅ Yes | Current order status |
| `order_date` | Timestamp | ✅ Yes | Date and time of order |
| `created_at` | Timestamp | Auto | Record creation timestamp |
| `updated_at` | Timestamp | Auto | Last update timestamp |

### Table: `order_items`

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `id` | String (CUID) | Auto | Unique identifier |
| `order_id` | String (FK) | ✅ Yes | Reference to orders table |
| `product_id` | String (FK) | ❌ Optional | Reference to products table (null if product deleted) |
| `product_name` | String | ✅ Yes | Product name at time of order |
| `variant_id` | String (FK) | ❌ Optional | Reference to product_variants table (null if variant deleted) |
| `variant_name` | String | ✅ Yes | Variant name at time of order |
| `quantity` | Integer | ✅ Yes | Quantity ordered |
| `price` | Decimal(10,2) | ✅ Yes | Original price per unit |
| `discount_type` | String | ❌ Optional | "fixed" or "percentage" (if product had discount) |
| `discount_value` | String | ❌ Optional | Discount value (e.g., "20" or "20%") |
| `discount_amount` | Decimal(10,2) | ❌ Optional | Calculated discount per unit |
| `final_price` | Decimal(10,2) | ✅ Yes | Price after discount per unit |
| `item_total` | Decimal(10,2) | ✅ Yes | quantity × final_price |
| `coupon_code` | String | ❌ Optional | Coupon code applied to this item |
| `coupon_discount` | Decimal(10,2) | ❌ Optional | Coupon discount for this item |

### Table: `order_status_history` (Optional - for tracking)

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `id` | String (CUID) | Auto | Unique identifier |
| `order_id` | String (FK) | ✅ Yes | Reference to orders table |
| `status` | String | ✅ Yes | Status that was set |
| `created_at` | Timestamp | Auto | When status was set |

### Indexes

```
orders:
- order_number (unique index)
- customer_phone (index)
- customer_name (index)
- status (index)
- order_date (index)

order_items:
- order_id (index)
- product_id (index)
```

---

## 2. Order Number Logic

### Format

```
ORD001, ORD002, ORD003, ORD004...

Format: ORD + sequential number (minimum 3 digits)
Auto-increment from last order number
```

### Generation Logic

```
When new order created:
1. Get last order_number from database
2. Extract number (e.g., ORD025 → 25)
3. Increment by 1 (25 + 1 = 26)
4. Format with padding (ORD026)
5. Assign to new order
```

---

## 3. Order Status

### Status Values

| Status | Description | Can Change To |
|--------|-------------|---------------|
| `pending` | Order placed, waiting for admin | packaging, cancelled |
| `packaging` | Order being packed | shipping, cancelled |
| `shipping` | Out for delivery | delivered, cancelled |
| `delivered` | Customer received (FINAL) | Cannot change |
| `cancelled` | Order cancelled (FINAL) | delivered (by courier decision) |

### Status Flow

```
Forward Flow Only:
┌─────────────────────────────────────────────────────┐
│                                                     │
│   pending ──► packaging ──► shipping ──► delivered │
│      │            │            │          (FINAL)  │
│      │            │            │                   │
│      └────────────┴────────────┴──► cancelled      │
│                                     (FINAL)        │
│                                         │          │
│                                         ▼          │
│                                    delivered       │
│                                  (by courier)      │
└─────────────────────────────────────────────────────┘

Cannot go backwards:
├── packaging → pending ❌
├── shipping → packaging ❌
└── delivered → anything ❌

Cancelled can change to Delivered (courier decision)
```

### Status Update Logic

```
Admin updates status:
├── From pending → Can go to: packaging, cancelled
├── From packaging → Can go to: shipping, cancelled
├── From shipping → Can go to: delivered, cancelled
├── From delivered → Cannot change (final)
└── From cancelled → Can go to: delivered (if courier resolves)
```

---

## 4. Payment Status (Automatic)

### Payment Status Logic

```
Cash on Delivery (COD) ONLY - No manual payment status

Payment status is AUTOMATICALLY determined:
├── Order status = delivered → Payment = PAID ✓
├── Order status = cancelled → Payment = NOT PAID ✗
└── Any other status → Payment = PENDING

No separate payment status field in database
No manual update option
Derived from order status
```

### Payment Status Display

| Order Status | Display Text | Color Indicator |
|--------------|--------------|-----------------|
| pending | Pending | Yellow/Orange |
| packaging | Pending | Yellow/Orange |
| shipping | Pending | Yellow/Orange |
| delivered | Paid | Green |
| cancelled | Not Paid | Red |

---

## 5. Delivery Charge Logic

### Settings Table (in settings)

| Setting Key | Description | Example Value |
|-------------|-------------|---------------|
| `delivery_inside_dhaka` | Charge for inside Dhaka | 60 |
| `delivery_outside_dhaka` | Charge for outside Dhaka | 120 |
| `delivery_universal` | Universal charge | 80 |
| `free_delivery_inside_above` | Free above (Inside Dhaka) | 1000 |
| `free_delivery_outside_above` | Free above (Outside Dhaka) | 2000 |
| `free_delivery_universal_above` | Free above (Universal) | 1500 |

### Location Types

| Type | Description |
|------|-------------|
| `inside_dhaka` | Delivery inside Dhaka city |
| `outside_dhaka` | Delivery outside Dhaka city |
| `universal` | Universal delivery location |

### Calculation Logic

```
At checkout:
1. Customer selects location_type
2. Calculate subtotal (sum of all item totals)
3. Apply delivery charge logic:

IF location_type = "inside_dhaka":
   IF subtotal >= free_delivery_inside_above:
      delivery_charge = 0 (FREE)
   ELSE:
      delivery_charge = delivery_inside_dhaka

IF location_type = "outside_dhaka":
   IF subtotal >= free_delivery_outside_above:
      delivery_charge = 0 (FREE)
   ELSE:
      delivery_charge = delivery_outside_dhaka

IF location_type = "universal":
   IF subtotal >= free_delivery_universal_above:
      delivery_charge = 0 (FREE)
   ELSE:
      delivery_charge = delivery_universal
```

---

## 6. Create Order Logic

### Required Inputs

| Field | Type | Required | Validation |
|-------|------|----------|------------|
| `customer_name` | String | ✅ Yes | Not empty |
| `customer_phone` | String | ✅ Yes | Valid phone format |
| `customer_address` | String | ✅ Yes | Not empty |
| `city` | String | ✅ Yes | Not empty |
| `location_type` | Enum | ✅ Yes | inside_dhaka / outside_dhaka / universal |
| `items` | Array | ✅ Yes | Min 1 item |
| `coupon_code` | String | ❌ No | Valid coupon code (if provided) |

### Order Item Inputs

| Field | Type | Required | Validation |
|-------|------|----------|------------|
| `product_id` | String | ✅ Yes | Valid product ID |
| `variant_id` | String | ✅ Yes | Valid variant ID |
| `quantity` | Integer | ✅ Yes | Positive integer |

### Create Flow

```
1. Customer completes checkout form
   ↓
2. Validate inputs:
   ├── Is customer_name provided? → NO → Error
   ├── Is customer_phone valid? → NO → Error
   ├── Is customer_address provided? → NO → Error
   ├── Is city provided? → NO → Error
   ├── Is location_type valid? → NO → Error
   ├── Are there items? → NO → Error
   ├── Is each product active? → NO → Error
   ├── Is each variant valid? → NO → Error
   ├── Is quantity positive? → NO → Error
   ├── Is stock available? → NO → Error
   └── If coupon provided, is it valid? → NO → Error
   ↓
3. Calculate order totals:
   ├── For each item:
   │   ├── Get product and variant data
   │   ├── Store product_name, variant_name
   │   ├── Store price
   │   ├── Store discount_type, discount_value (if any)
   │   ├── Calculate discount_amount
   │   ├── Calculate final_price = price - discount_amount
   │   └── Calculate item_total = final_price × quantity
   ├── Calculate subtotal = sum of item_totals
   ├── Calculate delivery_charge (based on location_type)
   ├── If coupon applied:
   │   ├── Validate coupon
   │   ├── Calculate coupon_discount
   │   └── Store coupon_code, coupon_discount
   └── Calculate total = subtotal + delivery_charge - coupon_discount
   ↓
4. Generate order_number:
   ├── Get last order number
   ├── Increment by 1
   └── Format: ORD{number}
   ↓
5. Save to database:
   ├── Create order record
   │   ├── order_number
   │   ├── customer_name, phone, address, city, location_type
   │   ├── subtotal, delivery_charge, coupon_code, coupon_discount, total
   │   ├── status = "pending"
   │   └── order_date = current timestamp
   └── Create order_items records
       └── All item data with product snapshot
   ↓
6. Return success with order_number
```

### Stock Check (Not Reduced)

```
At order creation:
├── Check if stock available for all items
├── If any item out of stock → Error
└── DO NOT reduce stock yet (only on delivery)
```

---

## 7. Update Order Status Logic

### Update Flow

```
1. Admin selects order
   ↓
2. Admin clicks "Update Status"
   ↓
3. Show available next statuses:
   ├── From pending → packaging, cancelled
   ├── From packaging → shipping, cancelled
   ├── From shipping → delivered, cancelled
   ├── From delivered → (no options - final)
   └── From cancelled → delivered
   ↓
4. Admin selects new status
   ↓
5. Validate status transition:
   ├── Is valid transition? → NO → Error
   └── YES → Continue
   ↓
6. Update database:
   ├── Set status = new_status
   ├── Update updated_at
   └── If status = "delivered":
       └── Reduce stock for each order item
   ↓
7. Show success message
```

### Stock Reduction Logic

```
When order status changes to "delivered":

FOR each order_item:
   UPDATE product_variants
   SET stock = stock - order_item.quantity
   WHERE id = order_item.variant_id
   
   -- Check for low stock alert
   IF stock < 10 THEN
      -- Trigger low stock notification
   END IF
END FOR
```

---

## 8. Cancel Order Logic

### Cancel Flow

```
1. Admin clicks "Cancel Order"
   ↓
2. Show confirmation:
   "Are you sure you want to cancel order {order_number}?"
   ↓
3. Admin confirms?
   ├── NO → Close, no action
   └── YES → Update database:
            ├── Set status = "cancelled"
            ├── Update updated_at
            └── DO NOT reduce stock
            ↓
         Show success message
```

### Cancel Rules

```
├── Can cancel from: pending, packaging, shipping
├── No reason required
├── No tracking of who cancelled
├── Stock NOT reduced
└── Can later change to delivered (if courier resolves)
```

---

## 9. Order Details View

### Information Displayed

| Section | Data |
|---------|------|
| **Order Info** | Order number, Order date & time, Current status, Payment status (derived) |
| **Customer Info** | Name, Phone, Address, City, Location type |
| **Items** | For each item: Product name, Variant name, Quantity, Original price, Discount (type, value, amount), Final price, Item total, Coupon applied (if any) |
| **Summary** | Subtotal, Delivery charge, Coupon code & discount (if any), Total |

### Item Display Details

```
For each order item show:
├── Product name
├── Variant name
├── Quantity
├── Original price per unit
├── Discount (if any):
│   ├── Discount type (fixed/percentage)
│   ├── Discount value
│   └── Discount amount calculated
├── Final price per unit
├── Item total (qty × final_price)
└── Coupon (if applied to this item):
    ├── Coupon code
    └── Coupon discount
```

---

## 10. Order List Table

### Table Columns

| Column | Data Source | Display |
|--------|-------------|---------|
| **Order #** | order_number | ORD001 |
| **Customer** | customer_name | Name |
| **Phone** | customer_phone | Phone number |
| **Items** | COUNT(order_items) | Number count |
| **Total** | total | ৳XXX |
| **Status** | status | Current status |
| **Date** | order_date | Date & time |
| **Actions** | - | View, Update, Cancel, Print, Call |

### List Order

```
ORDER BY order_date DESC (newest first)
```

---

## 11. Search & Filter Logic

### Search Options

| Search By | Logic |
|-----------|-------|
| **Order Number** | Exact match: WHERE order_number = '{search}' |
| **Phone Number** | Partial match: WHERE customer_phone LIKE '%{search}%' |
| **Customer Name** | Partial match: WHERE customer_name LIKE '%{search}%' |

### Filter Options

| Filter By | Logic |
|-----------|-------|
| **Status** | WHERE status = '{status}' |
| **Date Range** | WHERE order_date BETWEEN {start} AND {end} |

### Combined Search & Filter

```
Can combine search + filters:

Example 1:
├── Search: "01712345678" (phone)
├── Filter: status = "pending"
└── Result: Pending orders with phone containing "01712345678"

Example 2:
├── Search: "ORD001" (order number)
├── Filter: None
└── Result: Order with number ORD001

Example 3:
├── Search: None
├── Filter: status = "delivered" + date range (last 7 days)
└── Result: Delivered orders in last 7 days
```

---

## 12. Admin Actions

### Available Actions

| Action | Description | When Available |
|--------|-------------|----------------|
| **View Details** | Show full order information | Always |
| **Update Status** | Change to next status | Pending, Packaging, Shipping, Cancelled |
| **Cancel Order** | Set status to cancelled | Pending, Packaging, Shipping |
| **Mark Delivered** | Set status to delivered | Shipping, Cancelled |
| **Print Invoice** | Print order invoice | Always |
| **Call Customer** | Initiate phone call | Always |

### Action Buttons Logic

```
View Details: Always show
Update Status: Show if status in [pending, packaging, shipping, cancelled]
Cancel Order: Show if status in [pending, packaging, shipping]
Mark Delivered: Show if status in [shipping, cancelled]
Print Invoice: Always show
Call Customer: Always show (uses customer_phone)
```

---

## 13. Coupon Integration

### Coupon Application

```
If coupon applied to order:
├── Validate coupon:
│   ├── Does coupon exist?
│   ├── Is coupon active?
│   ├── Is coupon within expiry date?
│   ├── Does order meet minimum amount?
│   └── Is coupon within usage limit?
├── Calculate discount:
│   ├── If fixed amount: discount = coupon.value
│   └── If percentage: discount = subtotal × (coupon.value / 100)
├── Store in order:
│   ├── coupon_code
│   └── coupon_discount
└── Update total:
    └── total = subtotal + delivery_charge - coupon_discount
```

### Coupon in Order Items

```
If coupon is product-specific:
├── Store coupon_code on order_item
└── Store coupon_discount on order_item
```

---

## 14. Invoice Print Logic

### Invoice Content

| Section | Content |
|---------|---------|
| **Header** | Store name, logo, address |
| **Order Info** | Order number, Date, Status |
| **Customer Info** | Name, Phone, Address, City |
| **Items Table** | Product, Variant, Qty, Price, Discount, Total |
| **Summary** | Subtotal, Delivery, Coupon discount, Total |
| **Footer** | Thank you message, contact info |

### Print Format

```
A4 size paper format
Clean, simple layout
No colors (black & white)
Optimized for thermal printers
```

---

## 15. API Endpoints

### Create Order

```
POST /api/orders

Request Body:
{
  "customer_name": "John Doe",
  "customer_phone": "01712345678",
  "customer_address": "123 Main Street, Apartment 4B",
  "city": "Dhaka",
  "location_type": "inside_dhaka",
  "items": [
    {
      "product_id": "prod_xxx",
      "variant_id": "var_xxx",
      "quantity": 2
    },
    {
      "product_id": "prod_yyy",
      "variant_id": "var_yyy",
      "quantity": 1
    }
  ],
  "coupon_code": "SAVE50"
}

Response:
{
  "success": true,
  "data": {
    "order_number": "ORD001",
    "total": 550,
    "message": "Order placed successfully"
  }
}
```

### Get Orders List (Admin)

```
GET /api/admin/orders

Query Parameters:
- page: number (default: 1)
- limit: number (default: 10)
- search: string (optional - order #, phone, name)
- status: string (optional)
- start_date: date (optional)
- end_date: date (optional)

Response:
{
  "success": true,
  "data": [
    {
      "id": "ord_xxx",
      "order_number": "ORD001",
      "customer_name": "John Doe",
      "customer_phone": "01712345678",
      "item_count": 3,
      "total": 550,
      "status": "pending",
      "order_date": "2024-01-15T10:30:00Z"
    }
  ],
  "pagination": {
    "total": 50,
    "page": 1,
    "limit": 10,
    "total_pages": 5
  }
}
```

### Get Order Details

```
GET /api/admin/orders/{id}

Response:
{
  "success": true,
  "data": {
    "id": "ord_xxx",
    "order_number": "ORD001",
    "customer_name": "John Doe",
    "customer_phone": "01712345678",
    "customer_address": "123 Main Street",
    "city": "Dhaka",
    "location_type": "inside_dhaka",
    "subtotal": 500,
    "delivery_charge": 60,
    "coupon_code": "SAVE50",
    "coupon_discount": 50,
    "total": 510,
    "status": "pending",
    "order_date": "2024-01-15T10:30:00Z",
    "items": [
      {
        "id": "item_xxx",
        "product_name": "Apple",
        "variant_name": "1kg",
        "quantity": 2,
        "price": 100,
        "discount_type": "percentage",
        "discount_value": "10%",
        "discount_amount": 10,
        "final_price": 90,
        "item_total": 180
      }
    ]
  }
}
```

### Update Order Status

```
PATCH /api/admin/orders/{id}/status

Request Body:
{
  "status": "packaging"
}

Response:
{
  "success": true,
  "message": "Order status updated",
  "data": {
    "order_number": "ORD001",
    "status": "packaging"
  }
}
```

### Cancel Order

```
POST /api/admin/orders/{id}/cancel

Response:
{
  "success": true,
  "message": "Order cancelled successfully"
}
```

### Get Order Number Sequence

```
GET /api/admin/orders/next-number

Response:
{
  "success": true,
  "data": {
    "next_order_number": "ORD026"
  }
}
```

---

## 16. Error Handling

### Error Codes & Messages

| Error Code | Message | When |
|------------|---------|------|
| `CUSTOMER_NAME_REQUIRED` | "Customer name is required" | Empty name |
| `CUSTOMER_PHONE_REQUIRED` | "Customer phone is required" | Empty phone |
| `CUSTOMER_PHONE_INVALID` | "Invalid phone number format" | Wrong format |
| `CUSTOMER_ADDRESS_REQUIRED` | "Customer address is required" | Empty address |
| `CITY_REQUIRED` | "City is required" | Empty city |
| `LOCATION_TYPE_REQUIRED` | "Location type is required" | No location selected |
| `ITEMS_REQUIRED` | "At least 1 item is required" | No items |
| `PRODUCT_NOT_FOUND` | "Product not found" | Invalid product ID |
| `VARIANT_NOT_FOUND` | "Variant not found" | Invalid variant ID |
| `PRODUCT_INACTIVE` | "Product is not available" | Product inactive |
| `STOCK_INSUFFICIENT` | "Insufficient stock for {product}" | Not enough stock |
| `COUPON_INVALID` | "Invalid coupon code" | Coupon not found |
| `COUPON_EXPIRED` | "Coupon has expired" | Past expiry date |
| `COUPON_INACTIVE` | "Coupon is not active" | Coupon disabled |
| `COUPON_MIN_ORDER` | "Minimum order amount is ৳{amount}" | Below minimum |
| `COUPON_LIMIT_REACHED` | "Coupon usage limit reached" | Max uses reached |
| `ORDER_NOT_FOUND` | "Order not found" | Invalid order ID |
| `STATUS_TRANSITION_INVALID` | "Cannot change status from {from} to {to}" | Invalid transition |

---

## 17. Security Considerations

### Admin Only Access
- All admin order endpoints require authentication
- Validate admin session before operations

### Input Validation
- Sanitize all customer inputs
- Validate phone number format
- Validate address length
- Prevent XSS in text fields

### Rate Limiting
- Max 10 order creations per minute per IP
- Max 50 admin operations per minute

---

## 18. Data Relationships

```
orders (1) ──────► (N) order_items
    │                   │
    │                   ├──► products (N:1)
    │                   └──► product_variants (N:1)
    │
    └──► coupons (N:1, optional)
```

---

## 19. Business Rules Summary

| Rule | Description |
|------|-------------|
| **Order Number** | Sequential (ORD001, ORD002...) |
| **Customer Data** | Name, Phone, Address, City, Location type - all required |
| **Email** | Not collected |
| **Payment** | COD only, auto-derived from status |
| **Status Flow** | Forward only: pending → packaging → shipping → delivered/cancelled |
| **Final Statuses** | Delivered (final), Cancelled (final but can change to delivered) |
| **Stock Reduction** | Only when status = delivered |
| **Delivery Charge** | Based on location type + free above threshold |
| **Cancellation** | No reason needed, no tracking of who cancelled |
| **Search** | Order #, Phone, Customer name |
| **Filter** | Status, Date range |

---

## Document History

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0 | 2024-01-15 | EcoMart Team | Initial PRD |

---

**END OF ORDER MANAGEMENT PRD**
