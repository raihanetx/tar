# EcoMart - Product Requirements Documents

## Overview
This folder contains all PRD documents for the EcoMart grocery store platform. Each document defines the complete logic and specifications for a specific feature.

---

## PRD Index

| # | Document | Status | Description |
|---|----------|--------|-------------|
| 01 | [Category Management](./01-category-management.md) | ✅ Complete | Category CRUD, status toggle, delete logic |
| 02 | [Product Management](./02-product-management.md) | ✅ Complete | Products, variants, images, FAQs, related products |
| 03 | [Order Management](./03-order-management.md) | ✅ Complete | Order flow, status, delivery, COD payment |
| 04 | [Customer Profiles](./04-customer-profiles.md) | ✅ Complete | Customer tracking by phone, order history, visit tracking |
| 05 | [Abandoned Carts](./05-abandoned-checkouts.md) | ✅ Complete | Checkout visit tracking, abandoned/completed status |
| 06 | Coupon System | 📝 Pending | Coupons, discounts, validation |
| 07 | Settings & CMS | 📝 Pending | Store settings, branding, CMS |
| 08 | Dashboard | 📝 Pending | Analytics, charts, metrics |
| 09 | Storefront | 📝 Pending | Customer-facing shop |
| 10 | Checkout | 📝 Pending | Cart, checkout, COD |

---

## How to Use These Documents

1. **Before Development**: Read the relevant PRD to understand all requirements
2. **During Development**: Reference the PRD for logic and specifications
3. **After Development**: Verify all requirements are met

---

## Document Structure

Each PRD contains:
- Database Schema
- Business Logic
- API Endpoints
- UI/UX Specifications
- Error Handling
- Security Considerations

---

## Quick Reference

### Tech Stack
- **Framework**: Next.js 16 (App Router)
- **Language**: TypeScript
- **ORM**: Drizzle ORM
- **Database**: SQLite (→ Supabase later)
- **State**: React Query + Zustand
- **UI**: Tailwind CSS + shadcn/ui
- **Icons**: Remix Icon
- **Design**: Emerald Green primary, No human/animal imagery

### Key Principles
- Simple structure
- Fast performance
- Secure implementation
- Guest checkout (no customer login)
- Cash on delivery only
- No email notifications

---

**Last Updated**: 2024-01-15
