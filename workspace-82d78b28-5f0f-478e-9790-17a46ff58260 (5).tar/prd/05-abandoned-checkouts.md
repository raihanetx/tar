# EcoMart - Abandoned Checkouts PRD

## Overview
This document defines the complete logic and specifications for the Abandoned Checkouts tracking feature in EcoMart admin dashboard.

---

## 1. Database Schema

### Table: `abandoned_checkouts`

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `id` | String (CUID) | Auto | Unique identifier |
| `session_id` | String | ✅ Yes | Browser session identifier |
| `visit_number` | Integer | ✅ Yes | Visit count for this session/customer |
| `customer_name` | String | ❌ Optional | Customer name (if entered) |
| `customer_phone` | String | ❌ Optional | Customer phone (if entered) |
| `customer_address` | String | ❌ Optional | Customer address (if entered) |
| `city` | String | ❌ Optional | City (if entered) |
| `location_type` | Enum | ❌ Optional | inside_dhaka / outside_dhaka / universal |
| `items` | JSON | ✅ Yes | Array of products with quantities and prices |
| `subtotal` | Decimal(10,2) | ✅ Yes | Sum of item totals |
| `delivery_charge` | Decimal(10,2) | ❌ Optional | Calculated delivery charge |
| `total` | Decimal(10,2) | ✅ Yes | Total amount |
| `status` | Enum | ✅ Yes | "abandoned" / "completed" |
| `order_id` | String (FK) | ❌ Optional | Reference to orders if completed |
| `visited_at` | Timestamp | ✅ Yes | When checkout was visited |
| `created_at` | Timestamp | Auto | Record creation timestamp |

### Indexes

```
abandoned_checkouts:
- session_id (index)
- customer_phone (index)
- status (index)
- visited_at (index)
```

---

## 2. Tracking Logic

### When Tracking Starts

```
Tracking starts when customer LANDS on checkout page.

Trigger: Customer navigates to /checkout page
Action: Create abandoned_checkout record
```

### Tracking Flow

```
1. Customer lands on checkout page
   ↓
2. Check if session_id exists
   ↓
3. Get next visit_number for this session
   ↓
4. Create abandoned_checkout record:
   ├── session_id = browser session
   ├── visit_number = next number
   ├── items = cart items (JSON)
   ├── subtotal = cart subtotal
   ├── delivery_charge = calculated (if location selected)
   ├── total = subtotal + delivery
   ├── status = "abandoned"
   └── visited_at = current timestamp
   ↓
5. Track customer input changes:
   ├── If customer enters name → Update customer_name
   ├── If customer enters phone → Update customer_phone
   ├── If customer enters address → Update customer_address
   ├── If customer selects location → Update location_type, delivery_charge, total
   └── Only save if different from previous value
```

---

## 3. Visit Number Logic

### Visit Counting

```
Each checkout page visit = 1 visit

Customer Journey:
├── Visit 1: Lands on checkout → visit_number = 1
├── Visit 2: Returns to checkout → visit_number = 2
├── Visit 3: Returns to checkout → visit_number = 3
├── Visit 4: Returns to checkout → visit_number = 4
└── Visit 5: Completes checkout → status = "completed"

All visits are tracked separately with their own visit_number
```

### Session Tracking

```
session_id = Browser session identifier (localStorage or cookie)

If customer clears browser data:
├── New session_id generated
└── Starts from visit_number = 1 again

If customer uses same browser:
├── Same session_id
└── visit_number continues incrementing
```

---

## 4. Items Storage (JSON)

### JSON Structure

```json
{
  "items": [
    {
      "product_id": "prod_xxx",
      "product_name": "Apple",
      "variant_id": "var_xxx",
      "variant_name": "1kg",
      "quantity": 2,
      "price": 100,
      "discount_type": "percentage",
      "discount_value": "10%",
      "discount_amount": 10,
      "final_price": 90,
      "item_total": 180
    },
    {
      "product_id": "prod_yyy",
      "product_name": "Rice",
      "variant_id": "var_yyy",
      "variant_name": "5kg",
      "quantity": 1,
      "price": 500,
      "discount_type": null,
      "discount_value": null,
      "discount_amount": 0,
      "final_price": 500,
      "item_total": 500
    }
  ],
  "items_count": 2,
  "total_items_quantity": 3
}
```

---

## 5. Customer Info Logic

### When Customer Enters Info

```
Customer types in checkout form:
├── First time entering info:
│   └── SAVE to abandoned_checkout record
│
├── Same info entered again (same session):
│   └── DON'T save (already saved)
│
└── Different info entered:
    └── UPDATE to latest value
```

### Info Fields Tracked

| Field | When Saved |
|-------|------------|
| `customer_name` | When customer types and moves to next field |
| `customer_phone` | When customer types and moves to next field |
| `customer_address` | When customer types and moves to next field |
| `city` | When customer types and moves to next field |
| `location_type` | When customer selects from dropdown |

---

## 6. Status Logic

### Status Values

| Status | Color | Description |
|--------|-------|-------------|
| `abandoned` | 🔴 Red | Customer left without completing checkout |
| `completed` | 🟢 Green | Customer completed checkout and placed order |

### Status Update Flow

```
When customer completes checkout:
├── Find abandoned_checkout record by session_id + visit_number
├── Update:
│   ├── status = "completed"
│   └── order_id = newly created order ID
└── Keep record (don't delete)
```

---

## 7. Abandoned Checkout List

### Table Columns

| Column | Data | Display |
|--------|------|---------|
| **Visit #** | visit_number | 1, 2, 3... |
| **Products** | items JSON | Product names with quantities |
| **Total** | total | ৳XXX |
| **Customer** | customer_name, customer_phone | Name and phone (if provided) |
| **Time** | visited_at | How long ago (e.g., "2 hours ago") |
| **Status** | status | Green badge (completed) / Red badge (abandoned) |
| **Actions** | - | View details, Call, WhatsApp |

### Example Display

```
┌─────────┬────────────────────────────────┬─────────┬──────────────────────┬─────────────┬─────────┬─────────────────────┐
│ Visit # │ Products                       │ Total   │ Customer             │ Time        │ Status  │ Actions             │
├─────────┼────────────────────────────────┼─────────┼──────────────────────┼─────────────┼─────────┼─────────────────────┤
│    5    │ Apple (1kg) x2, Rice (5kg) x1  │ ৳680    │ John - 01712345678   │ 2 hours ago │ 🟢 Done │ View │ Call │ WhatsApp │
├─────────┼────────────────────────────────┼─────────┼──────────────────────┼─────────────┼─────────┼─────────────────────┤
│    4    │ Milk (1L) x3, Bread x2         │ ৳450    │ John - 01712345678   │ 1 day ago   │ 🔴 Left │ View │ Call │ WhatsApp │
├─────────┼────────────────────────────────┼─────────┼──────────────────────┼─────────────┼─────────┼─────────────────────┤
│    3    │ Apple (1kg) x2, Rice (5kg) x1  │ ৳680    │ -                    │ 3 days ago  │ 🔴 Left │ View                │
├─────────┼────────────────────────────────┼─────────┼──────────────────────┼─────────────┼─────────┼─────────────────────┤
│    2    │ Apple (1kg) x2, Rice (5kg) x1  │ ৳680    │ -                    │ 5 days ago  │ 🔴 Left │ View                │
├─────────┼────────────────────────────────┼────────────────┼───────────────┼─────────────┼─────────┼─────────────────────┤
│    1    │ Apple (1kg) x2                 │ ৳180    │ -                    │ 7 days ago  │ 🔴 Left │ View                │
└─────────┴────────────────────────────────┴─────────┴──────────────────────┴─────────────┴─────────┴─────────────────────┘
```

### List Order

```
ORDER BY visited_at DESC (most recent first)
```

---

## 8. Detail View

### Abandoned Checkout Details

| Section | Information |
|---------|-------------|
| **Visit Info** | Visit number, Date & Time, Status |
| **Customer Info** | Name, Phone, Address, City (if provided) |
| **Items** | Product, Variant, Quantity, Price, Total (for each) |
| **Summary** | Subtotal, Delivery charge, Total |

### Completed Checkout Details

| Section | Information |
|---------|-------------|
| **Visit Info** | Visit number, Date & Time, Status |
| **Order Info** | Order number link, Order date |
| **Customer Info** | Name, Phone, Address, City |
| **Items** | Product, Variant, Quantity, Price, Total (for each) |
| **Summary** | Subtotal, Delivery charge, Total |

---

## 9. Actions

### Available Actions

| Action | When Available | Implementation |
|--------|----------------|----------------|
| **View Details** | Always | Open detail modal/page |
| **Call Customer** | If phone provided | tel:{phone} link |
| **WhatsApp** | If phone provided | https://wa.me/{phone} link |
| **View Order** | If completed | Navigate to order details |

---

## 10. Products Display in List

### Items Formatting

```
Show as comma-separated list:

Format: {product_name} ({variant_name}) x{quantity}

Example: "Apple (1kg) x2, Rice (5kg) x1"

If more than 3 items:
"Apple (1kg) x2, Rice (5kg) x1, Milk (1L) x3 +2 more"
```

---

## 11. Time Display Logic

```
IF visited_at is within 1 hour:
   Display: "X minutes ago"
   
ELSE IF visited_at is within 24 hours:
   Display: "X hours ago"
   
ELSE IF visited_at is within 7 days:
   Display: "X days ago"
   
ELSE:
   Display: "DD MMM YYYY" (e.g., "15 Jan 2024")
```

---

## 12. Search & Filter

### Search Options

| Search By | Logic |
|-----------|-------|
| **Phone Number** | WHERE customer_phone LIKE '%{search}%' |
| **Customer Name** | WHERE customer_name LIKE '%{search}%' |

### Filter Options

| Filter By | Logic |
|-----------|-------|
| **Status** | WHERE status = 'abandoned' OR 'completed' |
| **Date Range** | WHERE visited_at BETWEEN {start} AND {end} |

---

## 13. Data Retention

### Keep Forever

```
Abandoned checkout records are kept forever.
No automatic deletion.
Admin can manually delete if needed.
```

---

## 14. Privacy & Security

### Admin Only Access

```
├── Only admins can view abandoned checkouts
├── Customers cannot see their own abandoned data
├── Data is for internal analysis only
└── No public API for abandoned checkout data
```

---

## 15. API Endpoints

### Get Abandoned Checkouts List

```
GET /api/admin/abandoned-checkouts

Query Parameters:
- page: number (default: 1)
- limit: number (default: 10)
- search: string (optional - phone or name)
- status: string (optional - "abandoned" / "completed")
- start_date: date (optional)
- end_date: date (optional)

Response:
{
  "success": true,
  "data": [
    {
      "id": "ab_xxx",
      "visit_number": 5,
      "customer_name": "John Doe",
      "customer_phone": "01712345678",
      "items_count": 2,
      "total": 680,
      "status": "completed",
      "visited_at": "2024-01-15T14:30:00Z",
      "time_ago": "2 hours ago",
      "order_id": "ord_xxx",
      "order_number": "ORD025"
    }
  ],
  "pagination": {
    "total": 50,
    "page": 1,
    "limit": 10,
    "total_pages": 5
  }
}
```

### Get Abandoned Checkout Details

```
GET /api/admin/abandoned-checkouts/{id}

Response:
{
  "success": true,
  "data": {
    "id": "ab_xxx",
    "session_id": "sess_xxx",
    "visit_number": 5,
    "customer_name": "John Doe",
    "customer_phone": "01712345678",
    "customer_address": "123 Main Street",
    "city": "Dhaka",
    "location_type": "inside_dhaka",
    "items": [
      {
        "product_id": "prod_xxx",
        "product_name": "Apple",
        "variant_name": "1kg",
        "quantity": 2,
        "price": 100,
        "final_price": 90,
        "item_total": 180
      }
    ],
    "subtotal": 680,
    "delivery_charge": 60,
    "total": 740,
    "status": "completed",
    "order_id": "ord_xxx",
    "order_number": "ORD025",
    "visited_at": "2024-01-15T14:30:00Z"
  }
}
```

### Create Abandoned Checkout (Frontend)

```
POST /api/abandoned-checkouts

Request Body:
{
  "session_id": "sess_xxx",
  "items": [...],
  "subtotal": 680,
  "delivery_charge": 60,
  "total": 740
}

Response:
{
  "success": true,
  "data": {
    "id": "ab_xxx",
    "visit_number": 1
  }
}
```

### Update Abandoned Checkout (Frontend)

```
PATCH /api/abandoned-checkouts/{id}

Request Body:
{
  "customer_name": "John Doe",
  "customer_phone": "01712345678",
  "customer_address": "123 Main Street"
}

Response:
{
  "success": true,
  "message": "Abandoned checkout updated"
}
```

### Mark as Completed (Frontend)

```
PATCH /api/abandoned-checkouts/{id}/complete

Request Body:
{
  "order_id": "ord_xxx"
}

Response:
{
  "success": true,
  "message": "Marked as completed"
}
```

---

## 16. Error Handling

### Error Codes & Messages

| Error Code | Message | When |
|------------|---------|------|
| `NOT_FOUND` | "Abandoned checkout not found" | Invalid ID |
| `SESSION_REQUIRED` | "Session ID is required" | Missing session_id |
| `ITEMS_REQUIRED` | "Items are required" | Missing items array |

---

## 17. Business Rules Summary

| Rule | Description |
|------|-------------|
| **Tracking Start** | When customer lands on checkout page |
| **Visit Number** | Each visit counted separately, increments per session |
| **Customer Info** | Save when entered, update when changed |
| **Status** | Red (abandoned) / Green (completed) |
| **Display** | Each visit shown separately |
| **Retention** | Keep forever |
| **Access** | Admin only (customers cannot see) |
| **Actions** | View, Call, WhatsApp (if phone provided) |
| **Search** | Phone, Name |
| **Filter** | Status, Date range |

---

## Document History

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0 | 2024-01-15 | EcoMart Team | Initial PRD |

---

**END OF ABANDONED CHECKOUTS PRD**
