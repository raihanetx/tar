# EcoMart - Customer Profiles PRD

## Overview
This document defines the complete logic and specifications for the Customer Profiles feature in EcoMart admin dashboard.

---

## 1. Database Schema

### Table: `customers`

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `id` | String (CUID) | Auto | Unique identifier |
| `phone` | String | ✅ Yes | Primary identifier (unique) |
| `name` | String | ✅ Yes | Customer name (from latest order) |
| `address` | String | ✅ Yes | Customer address (from latest order) |
| `city` | String | ✅ Yes | City (from latest order) |
| `total_orders` | Integer | ✅ Yes | Count of all orders - Default: 0 |
| `total_spent` | Decimal(10,2) | ✅ Yes | Sum of all order totals - Default: 0 |
| `total_visits` | Integer | ✅ Yes | Count of all checkout visits - Default: 0 |
| `first_order_date` | Timestamp | Auto | Date of first order |
| `last_order_date` | Timestamp | Auto | Date of most recent order |
| `created_at` | Timestamp | Auto | Record creation timestamp |
| `updated_at` | Timestamp | Auto | Last update timestamp |

### Indexes

```
customers:
- phone (unique index)
- name (index for search)
```

---

## 2. Customer Creation Logic

### Auto-Create from Orders

```
Customer is created automatically when an order is placed.
No manual customer creation.

When order is placed:
├── Check if phone exists in customers table
├── IF NOT EXISTS:
│   ├── Create new customer record
│   │   ├── phone = order.customer_phone
│   │   ├── name = order.customer_name
│   │   ├── address = order.customer_address
│   │   ├── city = order.city
│   │   ├── total_orders = 1
│   │   ├── total_spent = order.total
│   │   ├── first_order_date = order.order_date
│   │   └── last_order_date = order.order_date
│   └── Link order to customer
│
└── IF EXISTS:
    ├── Update customer record:
    │   ├── name = order.customer_name (latest)
    │   ├── address = order.customer_address (latest)
    │   ├── city = order.city (latest)
    │   ├── total_orders = total_orders + 1
    │   ├── total_spent = total_spent + order.total
    │   └── last_order_date = order.order_date
    └── Link order to customer
```

---

## 3. Customer Data

### Stored Information

| Data | Source | Update Rule |
|------|--------|-------------|
| `phone` | First order | Never changes (unique identifier) |
| `name` | Latest order | Updates with each new order |
| `address` | Latest order | Updates with each new order |
| `city` | Latest order | Updates with each new order |
| `total_orders` | Calculated | Increments with each order |
| `total_spent` | Calculated | Adds order total with each order |
| `first_order_date` | First order | Never changes |
| `last_order_date` | Latest order | Updates with each new order |

---

## 4. Avatar Logic

### Display Rule

```
Avatar = First letter of customer name (uppercase)

Examples:
├── "John Doe" → "J"
├── "Rahim" → "R"
├── "ABC Customer" → "A"
└── "md rahman" → "M"
```

### Avatar Style

| Property | Value |
|----------|-------|
| Text | First letter of name (uppercase) |
| Background | Default theme color |
| Shape | Circle |
| Size | Consistent across all displays |

---

## 5. Customer List Table

### Table Columns

| Column | Data Source | Display |
|--------|-------------|---------|
| **Avatar** | name | First letter in circle |
| **Name** | name | Customer name |
| **Phone** | phone | Phone number |
| **Orders** | total_orders | Number count |
| **Visits** | total_visits | Number count |
| **Total Spent** | total_spent | ৳XXX |
| **Actions** | - | View, Call, WhatsApp |

### Example Table Display

```
┌────────┬─────────────┬──────────────┬─────────┬─────────┬──────────────┬─────────────────────┐
│ Avatar │ Name        │ Phone        │ Orders  │ Visits  │ Total Spent  │ Actions             │
├────────┼─────────────┼──────────────┼─────────┼─────────┼──────────────┼─────────────────────┤
│   J    │ John Doe    │ 01712345678  │ 5       │ 8       │ ৳5,500       │ View │ Call │ WhatsApp │
├────────┼─────────────┼──────────────┼─────────┼─────────┼──────────────┼─────────────────────┤
│   R    │ Rahim       │ 01812345678  │ 3       │ 5       │ ৳2,300       │ View │ Call │ WhatsApp │
├────────┼─────────────┼──────────────┼─────────┼─────────┼──────────────┼─────────────────────┤
│   K    │ Karim Uddin │ 01912345678  │ 8       │ 12      │ ৳12,000      │ View │ Call │ WhatsApp │
└────────┴─────────────┴──────────────┴─────────┴─────────┴──────────────┴─────────────────────┘
```

### List Order

```
ORDER BY last_order_date DESC (most recent customers first)
```

---

## 6. Customer Profile View

### Profile Sections

| Section | Information |
|---------|-------------|
| **Header** | Avatar, Name |
| **Contact** | Phone, Address, City |
| **Stats** | Total Orders, Total Spent, Total Visits |
| **Order History** | List of all orders |

### Header Display

```
┌─────────────────────────────────────────────────────┐
│                   ┌─────┐                           │
│                   │  J  │                           │
│                   └─────┘                           │
│                   John Doe                          │
├─────────────────────────────────────────────────────┤
│  Phone:     01712345678                             │
│  Address:   123 Main Street, Dhaka                  │
├─────────────────────────────────────────────────────┤
│  Total Orders: 5                                    │
│  Total Spent:  ৳5,500                               │
│  Total Visits: 8                                    │
├─────────────────────────────────────────────────────┤
```

---

## 7. Order History Display

### Each Order Shown Separately

```
Order History Section:

┌─────────────────────────────────────────────────────┐
│  ORDER HISTORY                                      │
├─────────────────────────────────────────────────────┤
│                                                     │
│  ┌─────────────────────────────────────────────┐   │
│  │ Order: ORD025                               │   │
│  │ Date: Today, 10:30 AM                       │   │
│  │ Time: 2 hours ago                           │   │
│  │ Visit: 5th visit                            │   │
│  │ Items: Apple (1kg) x2, Rice (5kg) x1        │   │
│  │ Total: ৳850                                 │   │
│  │ Status: Delivered                           │   │
│  │ [View Details]                              │   │
│  └─────────────────────────────────────────────┘   │
│                                                     │
│  ┌─────────────────────────────────────────────┐   │
│  │ Order: ORD018                               │   │
│  │ Date: 7 days ago                            │   │
│  │ Time: 7 days ago                            │   │
│  │ Visit: 4th visit                            │   │
│  │ Items: Milk (1L) x3, Bread x2               │   │
│  │ Total: ৳450                                 │   │
│  │ Status: Delivered                           │   │
│  │ [View Details]                              │   │
│  └─────────────────────────────────────────────┘   │
│                                                     │
│  ┌─────────────────────────────────────────────┐   │
│  │ Order: ORD010                               │   │
│  │ Date: 15 Jan 2024                           │   │
│  │ Time: 15 days ago                           │   │
│  │ Visit: 2nd visit                            │   │
│  │ Items: Vegetables mixed x1                  │   │
│  │ Total: ৳320                                 │   │
│  │ Status: Delivered                           │   │
│  │ [View Details]                              │   │
│  └─────────────────────────────────────────────┘   │
│                                                     │
└─────────────────────────────────────────────────────┘
```

### Order Card Data

| Data | Display Logic |
|------|---------------|
| **Order Number** | order.order_number |
| **Date** | Relative (Today, Yesterday, X days ago) or absolute date |
| **Time Ago** | How long ago (e.g., "2 hours ago", "3 days ago") |
| **Visit Number** | Which visit number this order was placed on (e.g., "5th visit") |
| **Items** | List of product_name (variant_name) x quantity |
| **Total** | ৳{order.total} |
| **Status** | Current order status with badge color |
| **View Details** | Link to full order details page |

### Date Display Logic

```
IF order_date is today:
   Display: "Today, HH:MM AM/PM"
   
ELSE IF order_date is yesterday:
   Display: "Yesterday, HH:MM AM/PM"
   
ELSE IF order_date is within 7 days:
   Display: "X days ago"
   
ELSE:
   Display: "DD MMM YYYY" (e.g., "15 Jan 2024")
```

### Items Display Logic

```
Show items as comma-separated list:

Format: {product_name} ({variant_name}) x{quantity}

Example: "Apple (1kg) x2, Rice (5kg) x1, Milk (1L) x3"

If more than 3 items:
"Apple (1kg) x2, Rice (5kg) x1, Milk (1L) x3 +2 more"
```

---

## 8. Customer Actions

### Available Actions

| Action | Description | Implementation |
|--------|-------------|----------------|
| **View Profile** | Open customer profile page | Navigate to /admin/customers/{id} |
| **View Order Details** | Open specific order | Navigate to /admin/orders/{order_id} |
| **Call Customer** | Initiate phone call | tel:{phone} link |
| **WhatsApp** | Open WhatsApp chat | https://wa.me/{phone} link |

### Action Button Logic

```
Customer List:
├── View → Navigate to customer profile
├── Call → Open tel:{phone}
└── WhatsApp → Open https://wa.me/{phone}

Customer Profile:
├── Call → Open tel:{phone}
├── WhatsApp → Open https://wa.me/{phone}
└── View Order → Navigate to order details
```

---

## 9. Search & Filter Logic

### Search Options

| Search By | Logic |
|-----------|-------|
| **Phone Number** | Partial match: WHERE phone LIKE '%{search}%' |
| **Customer Name** | Partial match: WHERE name LIKE '%{search}%' |

### Search Implementation

```
Search is combined (one input field):

SELECT * FROM customers
WHERE phone LIKE '%{search}%'
   OR name LIKE '%{search}%'
ORDER BY last_order_date DESC
```

### Filter Options

| Filter | Logic |
|--------|-------|
| None currently | Can be added later if needed |

---

## 10. Customer Stats Calculation

### Total Orders

```
total_orders = COUNT of orders where customer_phone = this.phone
```

### Total Spent

```
total_spent = SUM of order.total where customer_phone = this.phone
             AND order.status != 'cancelled'
```

Note: Cancelled orders are NOT included in total_spent

### Total Visits

```
total_visits = COUNT of abandoned_checkouts where customer_phone = this.phone

Each checkout page visit counts as 1 visit.
Includes both completed and abandoned checkouts.
```

---

## 10.1 Visit Tracking Integration

### Visit Counter Update

```
When customer visits checkout page (abandoned_checkouts created):
├── Check if customer_phone exists in customers table
├── IF EXISTS:
│   └── UPDATE total_visits = total_visits + 1
└── IF NOT EXISTS:
    └── Customer will be created when order is placed
        (abandoned record tracks phone for linking)
```

### Visit Number per Order

```
Each order tracks which visit number it was:

orders table includes:
├── visit_number: Integer
└── Links to abandoned_checkouts.visit_number

When order is placed:
├── Get current visit_number from abandoned_checkouts
├── Save visit_number to order
└── This shows: "This was customer's Xth visit when they ordered"
```

---

## 11. API Endpoints

### Get Customers List

```
GET /api/admin/customers

Query Parameters:
- page: number (default: 1)
- limit: number (default: 10)
- search: string (optional - phone or name)

Response:
{
  "success": true,
  "data": [
    {
      "id": "cust_xxx",
      "name": "John Doe",
      "phone": "01712345678",
      "address": "123 Main Street, Dhaka",
      "city": "Dhaka",
      "total_orders": 5,
      "total_spent": 5500,
      "first_order_date": "2024-01-01T10:00:00Z",
      "last_order_date": "2024-01-15T14:30:00Z"
    }
  ],
  "pagination": {
    "total": 50,
    "page": 1,
    "limit": 10,
    "total_pages": 5
  }
}
```

### Get Customer Profile

```
GET /api/admin/customers/{id}

Response:
{
  "success": true,
  "data": {
    "id": "cust_xxx",
    "name": "John Doe",
    "phone": "01712345678",
    "address": "123 Main Street, Dhaka",
    "city": "Dhaka",
    "total_orders": 5,
    "total_spent": 5500,
    "first_order_date": "2024-01-01T10:00:00Z",
    "last_order_date": "2024-01-15T14:30:00Z",
    "orders": [
      {
        "id": "ord_xxx",
        "order_number": "ORD025",
        "order_date": "2024-01-15T14:30:00Z",
        "items": [
          {
            "product_name": "Apple",
            "variant_name": "1kg",
            "quantity": 2
          },
          {
            "product_name": "Rice",
            "variant_name": "5kg",
            "quantity": 1
          }
        ],
        "total": 850,
        "status": "delivered"
      }
    ]
  }
}
```

### Get Customer by Phone

```
GET /api/admin/customers/phone/{phone}

Response: Same as Get Customer Profile
```

---

## 12. Database Relationships

```
customers (1) ◄───── (N) orders
     │
     └── Linked via customer_phone = phone
```

### Order Table Update

```
Add to orders table:
- customer_id (FK to customers, optional)
- OR use customer_phone for linking

Recommended: Use customer_phone for linking (already exists)
```

---

## 13. Customer Update Triggers

### When Order is Created

```
Trigger: After order creation
Action:
1. Find customer by phone
2. IF NOT EXISTS:
   - Create new customer
3. IF EXISTS:
   - Update customer:
     - name = latest
     - address = latest
     - city = latest
     - total_orders += 1
     - total_spent += order.total
     - last_order_date = now()
```

### When Order is Cancelled

```
Trigger: After order cancellation
Action:
1. Find customer by phone
2. Update customer:
   - total_orders -= 1
   - total_spent -= order.total
```

---

## 14. Error Handling

### Error Codes & Messages

| Error Code | Message | When |
|------------|---------|------|
| `CUSTOMER_NOT_FOUND` | "Customer not found" | Invalid customer ID |
| `PHONE_EXISTS` | "Phone number already exists" | Duplicate phone (shouldn't happen) |
| `NO_ORDERS` | "No orders found for this customer" | Customer has no orders |

---

## 15. Security Considerations

### Admin Only Access
- All customer endpoints require admin authentication
- Validate admin session before operations

### Data Privacy
- Customer data is for admin use only
- Phone numbers should be protected
- No public API for customer data

---

## 16. Business Rules Summary

| Rule | Description |
|------|-------------|
| **Identifier** | Phone number (unique) |
| **Creation** | Auto-created from first order |
| **Update** | Name/address update with each new order |
| **Stats** | Total orders, Total spent (excludes cancelled), Total visits |
| **Avatar** | First letter of name |
| **Order History** | Each order shown separately with visit number |
| **Visit Tracking** | Each checkout visit counted, linked to order |
| **Actions** | View, Call, WhatsApp |
| **Search** | Phone, Name |

---

## Document History

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0 | 2024-01-15 | EcoMart Team | Initial PRD |

---

**END OF CUSTOMER PROFILES PRD**
