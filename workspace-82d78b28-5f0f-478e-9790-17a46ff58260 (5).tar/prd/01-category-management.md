# EcoMart - Category Management PRD

## Overview
This document defines the complete logic and specifications for the Category Management feature in EcoMart admin dashboard.

---

## 1. Database Schema

### Table: `categories`

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `id` | String (CUID) | Auto | Unique identifier |
| `name` | String | ✅ Yes | Category name |
| `type` | Enum | ✅ Yes | "icon" OR "image" |
| `icon_code` | String | Conditional | Remix icon code (e.g., "ri-leaf-line") - Required if type = "icon" |
| `image` | String | Conditional | Uploaded image URL/path - Required if type = "image" |
| `is_active` | Boolean | ✅ Yes | Active or Inactive status - Default: true |
| `created_at` | Timestamp | Auto | Creation date |

### Indexes
- `name` - Unique index
- `is_active` - Index for filtering

---

## 2. Add Category Logic

### Required Inputs

| Input | Type | Validation | Error Message |
|-------|------|------------|---------------|
| `name` | String | Required, Unique | "Category name is required" / "Category name already exists" |
| `type` | Enum | Required, "icon" or "image" | "Please select icon or image" |
| `icon_code` | String | Required if type = "icon" | "Icon code is required" |
| `image` | File | Required if type = "image" | "Please upload an image" |
| `is_active` | Boolean | Optional, Default: true | - |

### Add Flow

```
1. Admin clicks "Add Category" button
   ↓
2. Modal opens with form:
   ├── Type selector (Icon / Image tabs)
   ├── If Icon selected:
   │   └── Icon code input field
   │   └── Live preview of icon
   ├── If Image selected:
   │   └── Image upload area (drag-drop)
   │   └── Preview of uploaded image
   ├── Name input field
   └── Status toggle (default: Active/On)
   ↓
3. Admin fills form and clicks "Save"
   ↓
4. Validation:
   ├── Is name provided? → NO → Error: "Category name is required"
   ├── Is name unique? → NO → Error: "Category name already exists"
   ├── Is type selected? → NO → Error: "Please select icon or image"
   ├── If type = icon, is icon_code provided? → NO → Error: "Icon code is required"
   ├── If type = image, is image uploaded? → NO → Error: "Please upload an image"
   ↓
5. All validations pass?
   ├── NO → Show error, keep modal open
   └── YES → Save to database
            → Close modal
            → Show success toast: "Category created successfully"
            → Refresh category list
```

### Image Upload Specifications

| Specification | Value |
|--------------|-------|
| Max file size | 5MB |
| Allowed formats | JPG, PNG, WEBP |
| Storage location | /public/uploads/categories/ |
| File naming | {category_id}_{timestamp}.{ext} |
| Image shape | Square (thumbnail) |

---

## 3. Edit Category Logic

### Edit Flow

```
1. Admin clicks "Edit" button on category row
   ↓
2. Modal opens with pre-filled data:
   ├── Type (Icon/Image) - as previously saved
   ├── If Icon:
   │   └── Icon code input (pre-filled)
   │   └── Live preview
   ├── If Image:
   │   └── Current image preview
   │   └── Option to change image
   ├── Name input (pre-filled)
   └── Status toggle (current state)
   ↓
3. Admin modifies any field(s)
   ↓
4. Admin clicks "Save"
   ↓
5. Validation:
   ├── Is name provided? → NO → Error
   ├── Is name unique? (excluding this category) → NO → Error
   ├── If type = icon, is icon_code provided? → NO → Error
   ├── If type = image, is image present? → NO → Error
   ↓
6. All validations pass?
   ├── NO → Show error, keep modal open
   └── YES → Update in database
            → Close modal
            → Show success toast: "Category updated successfully"
            → Refresh category list
```

### Type Change Logic

| Scenario | Action |
|----------|--------|
| Change from Icon to Image | Clear icon_code, require image upload |
| Change from Image to Icon | Clear image, require icon_code |
| Keep same type | No change to stored data |

---

## 4. Delete Category Logic

### Delete Flow

```
1. Admin clicks "Delete" button on category row
   ↓
2. System checks: Does this category have products?
   ↓
3. Branch A - NO products:
   ├── Show simple confirmation dialog:
   │   "Are you sure you want to delete '{category_name}'?"
   ├── Admin confirms?
   │   ├── NO → Close dialog, no action
   │   └── YES → Delete category from database
   │           → Show success toast: "Category deleted"
   │           → Refresh category list
   ↓
4. Branch B - HAS products:
   ├── Show warning dialog:
   │   "This category has {X} products.
   │   These products will become INACTIVE if you delete this category."
   ├── Admin confirms?
   │   ├── NO → Close dialog, no action
   │   └── YES → Step 1: Get all products where category_id = this_category_id
   │             Step 2: Set each product is_active = false
   │             Step 3: Delete category from database
   │             Step 4: Show success toast: "Category deleted, {X} products set to inactive"
   │             Step 5: Refresh category list
```

### Database Actions on Delete

```sql
-- Step 1: Count products
SELECT COUNT(*) FROM products WHERE category_id = {category_id}

-- Step 2: Set products to inactive (if has products)
UPDATE products SET is_active = false WHERE category_id = {category_id}

-- Step 3: Delete category
DELETE FROM categories WHERE id = {category_id}
```

---

## 5. Status Toggle Logic

### Toggle Flow

```
1. Admin clicks toggle switch on category row
   ↓
2. Toggle visually switches position
   ↓
3. Update database:
   └── SET is_active = {new_value} WHERE id = {category_id}
   ↓
4. Effect on Storefront:
   ├── If changed to INACTIVE (false):
   │   └── All products in this category → HIDDEN on storefront
   │       (Products remain active in database but not visible because category is inactive)
   ├── If changed to ACTIVE (true):
   │   └── Products in this category → VISIBLE on storefront (if product is also active)
   ↓
5. Show success toast: "Category status updated"
6. Refresh category list (if needed)
```

### Status Visual Mapping

| Database Value | Toggle Display | Meaning |
|----------------|----------------|---------|
| `is_active = true` | ●────── (On/Right) | Category is active, products visible |
| `is_active = false` | ○────── (Off/Left) | Category is inactive, products hidden |

### Storefront Visibility Logic

```
Product visible on storefront IF:
├── Product is_active = true
AND └── Category is_active = true

Product hidden on storefront IF:
├── Product is_active = false
OR  └── Category is_active = false
```

---

## 6. Category List Display Logic

### Table Columns

| Column | Data Source | Display Logic |
|--------|-------------|---------------|
| **Category** | icon_code OR image + name | Square icon/image thumbnail + name (no gap, single column) |
| **Products** | COUNT from products table | Number of products in this category |
| **Type** | type field | "Icon Library" OR "Uploaded by Image" |
| **Status** | is_active field | Toggle switch (On/Off) |
| **Actions** | - | Edit button, Delete button |

### Column Details

#### Category Column
```
┌─────────────────┐
│ ■ CategoryName  │  ← Square icon/image + Name (no gap)
└─────────────────┘

If type = "icon":
┌─────────────────┐
│ 🥬 Vegetables   │  ← Remix icon + Name
└─────────────────┘

If type = "image":
┌─────────────────┐
│ 🖼️ Fruits       │  ← Image thumbnail + Name
└─────────────────┘
```

#### Products Column
```
Display: Integer count

Logic: SELECT COUNT(*) FROM products WHERE category_id = {this_category_id}

Includes: ALL products (active + inactive)
```

#### Type Column
```
If type = "icon" → Display: "Icon Library"
If type = "image" → Display: "Uploaded by Image"
```

#### Status Column
```
If is_active = true → Display: Toggle switch (On position ●──────)
If is_active = false → Display: Toggle switch (Off position ○──────)
```

#### Actions Column
```
┌──────────┐
│ ✏️  🗑️   │  ← Edit icon, Delete icon
└──────────┘

Edit: Opens edit modal
Delete: Opens delete confirmation
```

### List Order

```
ORDER BY created_at ASC

Result:
1. First created category → Shows first
2. Second created category → Shows second
3. Third created category → Shows third
... and so on
```

---

## 7. Icon Specifications

### Remix Icon Integration

| Specification | Value |
|--------------|-------|
| Icon Library | Remix Icon (remixicon package) |
| Icon Style | Line icons (ri-*-line) |
| Input Format | Icon code string (e.g., "ri-leaf-line") |
| Preview | Live preview shown in modal |
| Display Shape | Square |

### Example Icon Codes

| Icon Code | Preview | Usage |
|-----------|---------|-------|
| ri-leaf-line | 🍃 | Vegetables, Greens |
| ri-plant-line | 🌱 | Plants, Herbs |
| ri-apple-line | 🍎 | Fruits |
| ri-cup-line | 🥛 | Dairy, Beverages |
| ri-bread-line | 🍞 | Bakery |
| ri-shopping-basket-line | 🧺 | General |

---

## 8. API Endpoints

### Create Category
```
POST /api/admin/categories

Request Body:
{
  "name": "Vegetables",
  "type": "icon",
  "icon_code": "ri-leaf-line",
  "is_active": true
}

Response:
{
  "success": true,
  "data": {
    "id": "clx123...",
    "name": "Vegetables",
    "type": "icon",
    "icon_code": "ri-leaf-line",
    "is_active": true,
    "created_at": "2024-01-15T10:30:00Z"
  }
}
```

### Update Category
```
PATCH /api/admin/categories/{id}

Request Body:
{
  "name": "Fresh Vegetables",
  "is_active": false
}

Response:
{
  "success": true,
  "data": { updated category object }
}
```

### Delete Category
```
DELETE /api/admin/categories/{id}

Response:
{
  "success": true,
  "message": "Category deleted successfully",
  "affected_products": 5  // number of products set to inactive
}
```

### Get All Categories
```
GET /api/admin/categories

Query Parameters:
- page: number (default: 1)
- limit: number (default: 10)
- search: string (optional, search by name)

Response:
{
  "success": true,
  "data": [
    {
      "id": "clx123...",
      "name": "Vegetables",
      "type": "icon",
      "icon_code": "ri-leaf-line",
      "is_active": true,
      "product_count": 24,
      "created_at": "2024-01-15T10:30:00Z"
    }
  ],
  "pagination": {
    "total": 10,
    "page": 1,
    "limit": 10,
    "total_pages": 1
  }
}
```

### Toggle Category Status
```
PATCH /api/admin/categories/{id}/status

Request Body:
{
  "is_active": false
}

Response:
{
  "success": true,
  "message": "Category status updated"
}
```

---

## 9. Error Handling

### Error Messages

| Error Code | Message | When |
|------------|---------|------|
| `NAME_REQUIRED` | "Category name is required" | Empty name on add/edit |
| `NAME_EXISTS` | "Category name already exists" | Duplicate name |
| `TYPE_REQUIRED` | "Please select icon or image" | No type selected |
| `ICON_REQUIRED` | "Icon code is required" | Type is icon but no code |
| `IMAGE_REQUIRED` | "Please upload an image" | Type is image but no file |
| `NOT_FOUND` | "Category not found" | Invalid category ID |
| `DELETE_FAILED` | "Failed to delete category" | Database error |

---

## 10. Security Considerations

### Admin Only Access
- All category endpoints require admin authentication
- Validate admin session before any operation

### Input Validation
- Sanitize category name (trim whitespace, prevent XSS)
- Validate icon code format
- Validate image file type and size

### Rate Limiting
- Max 10 category operations per minute per admin

---

## 11. Future Considerations

### Potential Enhancements (Not in Current Scope)
- Category reordering (drag-drop)
- Category descriptions
- Category SEO (meta title, description)
- Sub-categories
- Category images with multiple sizes

---

## Document History

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0 | 2024-01-15 | EcoMart Team | Initial PRD |

---

**END OF CATEGORY MANAGEMENT PRD**
