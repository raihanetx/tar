# EcoMart - Product Management PRD

## Overview
This document defines the complete logic and specifications for the Product Management feature in EcoMart admin dashboard.

---

## 1. Database Schema

### Table: `products`

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `id` | String (CUID) | Auto | Unique identifier |
| `name` | String | ✅ Yes | Product name |
| `category_id` | String (FK) | ✅ Yes | Reference to categories table |
| `short_description` | Text | ❌ Optional | Shows on product detail below price |
| `long_description` | Text | ❌ Optional | Full detailed description |
| `is_active` | Boolean | ✅ Yes | Active/Inactive status - Default: true |
| `is_featured` | Boolean | ✅ Yes | Featured toggle - Default: false |
| `faq_enabled` | Boolean | ✅ Yes | FAQ section on/off - Default: false |
| `created_at` | Timestamp | Auto | Creation date |
| `updated_at` | Timestamp | Auto | Last update date |

### Table: `product_variants`

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `id` | String (CUID) | Auto | Unique identifier |
| `product_id` | String (FK) | ✅ Yes | Reference to products table |
| `name` | String | ✅ Yes | Variant name (can be anything: 1kg, Small, 500ml, etc.) |
| `price` | Decimal(10,2) | ✅ Yes | Original price in ৳ |
| `discount` | String | ❌ Optional | "20" for fixed OR "20%" for percentage |
| `stock` | Integer | ✅ Yes | Stock quantity |
| `sort_order` | Integer | Auto | Display order - Default: 0 |

### Table: `product_images`

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `id` | String (CUID) | Auto | Unique identifier |
| `product_id` | String (FK) | ✅ Yes | Reference to products table |
| `url` | String | ✅ Yes | Image path/URL |
| `sort_order` | Integer | ✅ Yes | Display order (0 = main image) |

### Table: `product_faqs`

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `id` | String (CUID) | Auto | Unique identifier |
| `product_id` | String (FK) | ✅ Yes | Reference to products table |
| `question` | String | ✅ Yes | Question text |
| `answer` | Text | ✅ Yes | Answer text |
| `sort_order` | Integer | Auto | Display order - Default: 0 |
| `is_enabled` | Boolean | ✅ Yes | Individual FAQ on/off - Default: true |

### Table: `related_products`

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `id` | String (CUID) | Auto | Unique identifier |
| `product_id` | String (FK) | ✅ Yes | Main product reference |
| `related_product_id` | String (FK) | ✅ Yes | Related product reference |
| `sort_order` | Integer | Auto | Display order - Default: 0 |

### Indexes

```
products:
- category_id (index)
- is_active (index)
- is_featured (index)
- name (index for search)

product_variants:
- product_id (index)

product_images:
- product_id (index)

product_faqs:
- product_id (index)

related_products:
- product_id (index)
- related_product_id (index)
```

---

## 2. Discount Logic

### Discount Input Format

| Input | Type | Calculation | Display |
|-------|------|-------------|---------|
| "20" (no %) | Fixed | Final = Price - 20 | "৳20 OFF" |
| "20%" (with %) | Percentage | Final = Price - (Price × 20 / 100) | "20% OFF" |

### Discount Calculation Examples

```
Fixed Discount Example:
├── Price: ৳100
├── Discount: "20" (fixed)
├── Final Price: ৳100 - ৳20 = ৳80
└── Display: "৳20 OFF"

Percentage Discount Example:
├── Price: ৳100
├── Discount: "20%" (percentage)
├── Final Price: ৳100 - (৳100 × 20/100) = ৳80
└── Display: "20% OFF"
```

### Discount Display on Offer/Featured Section

```
If discount type = fixed → Show: "৳{amount} OFF"
If discount type = percentage → Show: "{percentage}% OFF"

Note: Show what was entered, don't convert between types
```

### Discount Display on Product List

```
If all variants have same discount type:
├── All fixed → Show: "৳{min} OFF" (smallest fixed amount)
└── All percentage → Show: "{min}% OFF" (smallest percentage)

If mixed discount types:
└── Show: "Yes" (just indicate discount exists)

If no discount on any variant:
└── Show: "No"
```

---

## 3. Add Product Logic

### Required Inputs

| Section | Field | Required | Validation |
|---------|-------|----------|------------|
| Basic Info | `name` | ✅ Yes | Not empty, max 255 chars |
| Basic Info | `category_id` | ✅ Yes | Must exist in categories |
| Basic Info | `short_description` | ❌ No | Max 500 chars |
| Basic Info | `long_description` | ❌ No | No limit |
| Variants | `variants` | ✅ Yes | Min 1 variant required |
| Variants | `name` (per variant) | ✅ Yes | Not empty |
| Variants | `price` (per variant) | ✅ Yes | Positive number |
| Variants | `discount` (per variant) | ❌ No | Format: "20" or "20%" |
| Variants | `stock` (per variant) | ✅ Yes | Non-negative integer |
| Images | `images` | ❌ No | Max 5 images |
| FAQs | `faqs` | ❌ No | Optional |
| Related | `related_products` | ❌ No | Max 4 products |
| Settings | `is_active` | ✅ Yes | Default: true |
| Settings | `is_featured` | ✅ Yes | Default: false |

### Add Flow

```
1. Admin clicks "Add Product" button
   ↓
2. Form opens with sections:
   ├── Product Name (required)
   ├── Category (required, dropdown of active categories)
   ├── Short Description (optional)
   ├── Long Description (optional)
   ├── Variants Section
   │   ├── Default: 1 empty variant row
   │   ├── Variant Name (required)
   │   ├── Price (required)
   │   ├── Discount (optional)
   │   ├── Stock (required)
   │   ├── [Delete] button (disabled if only 1 variant)
   │   └── [+ Add Variant] button
   ├── Images Section
   │   ├── Upload area (drag-drop or click)
   │   ├── Uploaded images grid (max 5)
   │   ├── Drag to reorder
   │   └── First image = main image indicator
   ├── FAQ Section
   │   ├── Toggle On/Off
   │   ├── If On: Question + Answer fields
   │   ├── [+ Add FAQ] button
   │   └── [Delete] button per FAQ
   ├── Related Products Section
   │   ├── Select products dropdown
   │   ├── Max 4 products
   │   ├── Selected products list with remove button
   │   └── Auto-suggest from same category if empty
   └── Settings
       ├── Featured Toggle (On/Off) - Default: Off
       └── Status Toggle (Active/Inactive) - Default: Active
   ↓
3. Admin fills form and clicks "Save"
   ↓
4. Validation:
   ├── Is name provided? → NO → Error: "Product name is required"
   ├── Is category selected? → NO → Error: "Please select a category"
   ├── Is at least 1 variant? → NO → Error: "At least 1 variant is required"
   ├── Does each variant have name? → NO → Error: "Variant name is required"
   ├── Does each variant have price? → NO → Error: "Variant price is required"
   ├── Does each variant have stock? → NO → Error: "Variant stock is required"
   ├── Are there max 5 images? → NO → Error: "Maximum 5 images allowed"
   ├── Are there max 4 related products? → NO → Error: "Maximum 4 related products"
   ├── Is category active? → NO → Warning: "Selected category is inactive"
   ↓
5. All validations pass?
   ├── NO → Show errors, keep form open
   └── YES → Save to database
            ├── Create product record
            ├── Create variant records
            ├── Create image records
            ├── Create FAQ records (if any)
            ├── Create related product records (if any)
            → Show success toast: "Product created successfully"
            → Redirect to product list
```

### Image Upload Specifications

| Specification | Value |
|--------------|-------|
| Max file size | 5MB per image |
| Allowed formats | JPG, PNG, WEBP |
| Storage location | /public/uploads/products/ |
| File naming | {product_id}_{timestamp}_{index}.{ext} |
| Image shape | Square |
| Max images | 5 per product |

---

## 4. Edit Product Logic

### Edit Flow

```
1. Admin clicks "Edit" button on product row
   ↓
2. Fetch product data with all relations:
   ├── Product info
   ├── All variants
   ├── All images
   ├── All FAQs
   └── All related products
   ↓
3. Form opens with pre-filled data:
   ├── All product fields
   ├── All variants (can add/delete)
   ├── All images (can add/delete/reorder)
   ├── All FAQs (can add/delete)
   ├── All related products (can add/delete)
   └── All settings
   ↓
4. Admin modifies and clicks "Save"
   ↓
5. Same validation as Add
   ↓
6. Update database:
   ├── Update product record
   ├── Delete removed variants, add new, update existing
   ├── Delete removed images, add new, update order
   ├── Delete removed FAQs, add new, update existing
   ├── Delete removed related products, add new
   → Show success toast: "Product updated successfully"
   → Redirect to product list
```

### Variant Edit Logic

```
On Edit:
├── Existing variants: Update if changed
├── New variants: Insert new records
├── Removed variants: Delete from database
└── Must have at least 1 variant at all times
```

### Image Edit Logic

```
On Edit:
├── Existing images: Update sort_order if reordered
├── New images: Insert new records
├── Removed images: Delete from database and file system
└── Must have max 5 images
```

---

## 5. Delete Product Logic

### Delete Flow

```
1. Admin clicks "Delete" button on product row
   ↓
2. Show confirmation dialog:
   "Are you sure you want to delete '{product_name}'?"
   "This action cannot be undone."
   ↓
3. Admin confirms?
   ├── NO → Close dialog, no action
   └── YES → Delete from database
            ↓
            Delete in order (due to foreign keys):
            ├── DELETE FROM product_images WHERE product_id = {id}
            ├── DELETE FROM product_faqs WHERE product_id = {id}
            ├── DELETE FROM related_products WHERE product_id = {id} OR related_product_id = {id}
            ├── DELETE FROM product_variants WHERE product_id = {id}
            ├── DELETE FROM order_items (keep for order history, set product_id to null)
            └── DELETE FROM products WHERE id = {id}
            ↓
            → Show success toast: "Product deleted successfully"
            → Refresh product list
```

### Permanent Delete Note

```
⚠️ Delete is PERMANENT
├── Product removed from database completely
├── Cannot be recovered
├── Images deleted from file system
└── Order history: Keep order items but set product_id to null
```

---

## 6. Variant Management Logic

### Add Variant

```
Admin clicks [+ Add Variant]
   ↓
New empty variant row appears:
├── Variant Name: (empty)
├── Price: (empty)
├── Discount: (empty)
├── Stock: (empty)
└── [Delete] button (enabled if more than 1 variant)
```

### Delete Variant

```
Admin clicks [Delete] on variant row
   ↓
How many variants remaining?
   ↓
┌─────────────┬──────────────────────────────────┐
│ 1 variant   │ More than 1 variant              │
│     ↓       │        ↓                         │
│ Cannot      │ Allow delete                     │
│ delete      │ Remove variant row               │
│             │                                  │
│ Show error: │ Note: If this variant was in     │
│ "Product    │ any orders, keep variant data    │
│ must have   │ in order history                 │
│ at least    │                                  │
│ 1 variant"  │                                  │
└─────────────┴──────────────────────────────────┘
```

### Variant Display Order

```
Variants display in order they were added
sort_order: 0, 1, 2, 3...

Can reorder by dragging (updates sort_order)
```

---

## 7. FAQ Management Logic

### FAQ Toggle

```
Product has faq_enabled toggle:
├── Toggle ON (true)
│   └── FAQs visible on product detail page
│
└── Toggle OFF (false)
    └── FAQs hidden on product detail page
    └── FAQs still saved in database (not deleted)
    └── If turned ON again → FAQs appear again
```

### Add FAQ

```
Admin clicks [+ Add FAQ]
   ↓
New FAQ row appears:
├── Question: (empty)
├── Answer: (empty)
└── [Delete] button
```

### Delete FAQ

```
Admin clicks [Delete] on FAQ row
   ↓
Remove FAQ row
   ↓
FAQs are optional (can have 0 FAQs)
```

---

## 8. Related Products Logic

### Manual Selection

```
Admin selects related products during add/edit:
├── Dropdown/search to find products
├── Select up to 4 products
├── Selected products show in list
├── Can remove any selected product
└── Order matters (sort_order)
```

### Auto-Suggest Logic

```
If admin doesn't select related products:
   ↓
1. Get all products from same category
2. Exclude current product
3. Exclude inactive products
4. Exclude products in inactive categories
5. Order by created_at DESC
6. Take up to 4 products
   ↓
If 0 products found → Don't show "You May Like" section on storefront
If 1-4 products found → Show those products
```

### Related Product Display (Storefront)

```
"You May Also Like" Section:
┌─────────────────────────────────────────────────────┐
│                                                     │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐          │
│  │  Image   │  │  Image   │  │  Image   │          │
│  ├──────────┤  ├──────────┤  ├──────────┤          │
│  │ Title    │  │ Title    │  │ Title    │          │
│  │ Category │  │ Category │  │ Category │          │
│  │ Price    │  │ Price    │  │ Price    │          │
│  └──────────┘  └──────────┘  └──────────┘          │
│                                                     │
│  3 cards per row, max 4 products                    │
└─────────────────────────────────────────────────────┘
```

---

## 9. Stock Management Logic

### Stock Reduction Rule

```
Stock reduces ONLY when:
├── Order status changes to "DELIVERED"
└── Customer receives product AND pays

Stock does NOT reduce when:
├── Order placed
├── Order approved
├── Order processing
├── Order packaging
├── Order out for delivery
├── Customer cancels
└── Any status except DELIVERED
```

### Stock Reduction Database Logic

```sql
When order status updates to 'DELIVERED':

FOR each order_item IN order:
  UPDATE product_variants 
  SET stock = stock - order_item.quantity
  WHERE id = order_item.variant_id
  
  -- Check for low stock
  IF stock < 10 THEN
    -- Trigger low stock notification
  END IF
END FOR
```

### Stock Display in Product List

```
Show each variant stock separately:
├── 1 variant → "50"
├── 2 variants → "50, 30"
├── 3 variants → "50, 30, 20"
├── 4 variants → "50, 30, 20, 10"
└── etc.

Do NOT show total
Do NOT sum variants
```

---

## 10. Product Status Logic

### Visibility Rules

```
Product visible on storefront IF:
├── Product is_active = true
AND └── Category is_active = true

Product hidden on storefront IF:
├── Product is_active = false
OR  └── Category is_active = false
```

### Status Toggle Behavior

| Action | Effect |
|--------|--------|
| Product set inactive | Hidden from storefront immediately |
| Product set active | Visible on storefront (if category active) |
| Category set inactive | All products in category hidden |
| Category set active | All active products in category visible |

### Inactive Product Handling

```
When product is inactive:
├── NOT visible on storefront
├── NOT searchable on storefront
├── NOT shown in featured section
├── NOT shown in related products
├── Still visible in admin dashboard
├── Can be toggled back to active
└── All data preserved in database
```

---

## 11. Featured Products Logic

### Featured Toggle

| is_featured | Effect |
|-------------|--------|
| **true (On)** | Shows in Featured/Offer section on storefront |
| **false (Off)** | Doesn't show in Featured section |

### Featured Section Display

```
Featured Products Section shows:
├── Product main image
├── Product name
├── Discount (if any)
│   ├── Fixed: "৳20 OFF"
│   └── Percentage: "20% OFF"
└── Only active products with active categories
```

---

## 12. Product List Table (Admin Dashboard)

### Table Columns

| Column | Data Source | Display Logic |
|--------|-------------|---------------|
| **Product** | image + name + category | Main image thumbnail + Title (same column), Category name below title |
| **Variants** | COUNT(variants) | Number of variants (e.g., "3") |
| **Offer** | is_featured | "Yes" if featured, "No" if not |
| **Discount** | variants.discount | Show discount if any, "No" if none |
| **Stock** | variants.stock | Each variant stock separated (e.g., "50, 30, 20") |
| **Price Range** | variants.price | Low to High (e.g., "৳80 - ৳300") or single price |
| **Actions** | - | Edit button, Delete button |

### Example Table Display

```
┌────────────────────┬──────────┬───────┬──────────┬───────────┬─────────────┬──────────┐
│ Product            │ Variants │ Offer │ Discount │ Stock     │ Price Range │ Actions  │
├────────────────────┼──────────┼───────┼──────────┼───────────┼─────────────┼──────────┤
│ 🖼️ Apple           │ 3        │ Yes   │ 20% OFF  │ 50, 30, 20│ ৳80 - ৳300 │ ✏️  🗑️   │
│    Fruits          │          │       │          │           │             │          │
├────────────────────┼──────────┼───────┼──────────┼───────────┼─────────────┼──────────┤
│ 🖼️ Rice            │ 2        │ No    │ ৳50 OFF  │ 100, 50   │ ৳120 - ৳450│ ✏️  🗑️   │
│    Grocery         │          │       │          │           │             │          │
├────────────────────┼──────────┼───────┼──────────┼───────────┼─────────────┼──────────┤
│ 🖼️ Milk            │ 1        │ No    │ No       │ 200       │ ৳80        │ ✏️  🗑️   │
│    Dairy           │          │       │          │           │             │          │
└────────────────────┴──────────┴───────┴──────────┴───────────┴─────────────┴──────────┘
```

### Discount Column Logic

```
For each product:
├── Check all variant discounts
├── If all same type (all fixed or all percentage):
│   ├── All fixed → Show smallest: "৳{min} OFF"
│   └── All percentage → Show smallest: "{min}% OFF"
├── If mixed types → Show: "Yes"
└── If no discounts → Show: "No"
```

### Stock Column Logic

```
For each product:
├── Get all variants ordered by sort_order
├── Display stock values separated by comma
└── Example: "50, 30, 20" (first variant stock, second, third)
```

### Price Range Column Logic

```
For each product:
├── Get all variant prices
├── Find MIN price and MAX price
├── If MIN = MAX → Show single price: "৳100"
└── If different → Show range: "৳80 - ৳300"
```

### List Order

```
ORDER BY created_at DESC (newest products first)
```

---

## 13. Search & Filter Logic

### Search by Name

```sql
WHERE LOWER(name) LIKE LOWER('%{search_term}%')
```

### Filter by Category

```sql
WHERE category_id = '{category_id}'
```

### Filter by Status

```sql
WHERE is_active = {true/false}
```

### Combined Search & Filter

```
Can use search + filter together

Example 1:
├── Search: "Apple"
├── Filter: "Fruits" category
└── Result: Apple products in Fruits category only

Example 2:
├── Search: "Rice"
├── Filter: None
└── Result: All products with "Rice" in name

Example 3:
├── Search: None
├── Filter: "Dairy" category + Inactive
└── Result: Inactive products in Dairy category
```

---

## 14. API Endpoints

### Create Product

```
POST /api/admin/products

Request Body:
{
  "name": "Apple",
  "category_id": "cat_xxx",
  "short_description": "Fresh red apples from local farms",
  "long_description": "Premium quality apples, perfect for snacking...",
  "is_active": true,
  "is_featured": false,
  "faq_enabled": true,
  "variants": [
    {
      "name": "1kg",
      "price": 100,
      "discount": "20%",
      "stock": 50
    },
    {
      "name": "5kg",
      "price": 450,
      "discount": "50",
      "stock": 30
    }
  ],
  "images": [
    {"url": "/uploads/products/prod_xxx_1.jpg", "sort_order": 0},
    {"url": "/uploads/products/prod_xxx_2.jpg", "sort_order": 1}
  ],
  "faqs": [
    {
      "question": "How to store?",
      "answer": "Keep refrigerated for longer freshness"
    },
    {
      "question": "What is the shelf life?",
      "answer": "7-10 days when refrigerated"
    }
  ],
  "related_products": ["prod_yyy", "prod_zzz"]
}

Response:
{
  "success": true,
  "data": {
    "id": "prod_xxx",
    "name": "Apple",
    ...
  },
  "message": "Product created successfully"
}
```

### Update Product

```
PATCH /api/admin/products/{id}

Request Body: (all fields optional, only send what needs to be updated)
{
  "name": "Fresh Apple",
  "is_featured": true,
  "variants": [...],
  "images": [...],
  "faqs": [...],
  "related_products": [...]
}

Response:
{
  "success": true,
  "data": { updated product object },
  "message": "Product updated successfully"
}
```

### Delete Product

```
DELETE /api/admin/products/{id}

Response:
{
  "success": true,
  "message": "Product deleted successfully"
}
```

### Get Products List

```
GET /api/admin/products

Query Parameters:
- page: number (default: 1)
- limit: number (default: 10)
- search: string (optional, search by name)
- category_id: string (optional, filter by category)
- is_active: boolean (optional, filter by status)
- is_featured: boolean (optional, filter by featured)

Response:
{
  "success": true,
  "data": [
    {
      "id": "prod_xxx",
      "name": "Apple",
      "category": {
        "id": "cat_xxx",
        "name": "Fruits"
      },
      "main_image": "/uploads/products/prod_xxx_1.jpg",
      "variant_count": 3,
      "is_featured": true,
      "discount_display": "20% OFF",
      "stock_display": "50, 30, 20",
      "price_range": "৳80 - ৳300",
      "is_active": true,
      "created_at": "2024-01-15T10:30:00Z"
    }
  ],
  "pagination": {
    "total": 50,
    "page": 1,
    "limit": 10,
    "total_pages": 5
  }
}
```

### Get Single Product

```
GET /api/admin/products/{id}

Response:
{
  "success": true,
  "data": {
    "id": "prod_xxx",
    "name": "Apple",
    "category": {
      "id": "cat_xxx",
      "name": "Fruits"
    },
    "short_description": "Fresh red apples...",
    "long_description": "Premium quality...",
    "is_active": true,
    "is_featured": false,
    "faq_enabled": true,
    "variants": [
      {
        "id": "var_xxx",
        "name": "1kg",
        "price": 100,
        "discount": "20%",
        "stock": 50,
        "sort_order": 0
      }
    ],
    "images": [
      {
        "id": "img_xxx",
        "url": "/uploads/products/prod_xxx_1.jpg",
        "sort_order": 0
      }
    ],
    "faqs": [
      {
        "id": "faq_xxx",
        "question": "How to store?",
        "answer": "Keep refrigerated",
        "sort_order": 0,
        "is_enabled": true
      }
    ],
    "related_products": [
      {
        "id": "prod_yyy",
        "name": "Banana",
        "main_image": "/uploads/products/prod_yyy_1.jpg"
      }
    ],
    "created_at": "2024-01-15T10:30:00Z",
    "updated_at": "2024-01-16T14:20:00Z"
  }
}
```

### Upload Product Image

```
POST /api/admin/products/upload-image

Request: multipart/form-data
- image: File

Response:
{
  "success": true,
  "data": {
    "url": "/uploads/products/prod_xxx_timestamp.jpg"
  }
}
```

### Reorder Images

```
PATCH /api/admin/products/{id}/reorder-images

Request Body:
{
  "image_orders": [
    {"id": "img_1", "sort_order": 0},
    {"id": "img_2", "sort_order": 1},
    {"id": "img_3", "sort_order": 2}
  ]
}

Response:
{
  "success": true,
  "message": "Images reordered successfully"
}
```

---

## 15. Error Handling

### Error Codes & Messages

| Error Code | Message | When |
|------------|---------|------|
| `NAME_REQUIRED` | "Product name is required" | Empty name |
| `CATEGORY_REQUIRED` | "Please select a category" | No category selected |
| `CATEGORY_INACTIVE` | "Selected category is inactive" | Category is inactive |
| `VARIANT_MIN` | "At least 1 variant is required" | No variants |
| `VARIANT_NAME_REQUIRED` | "Variant name is required" | Empty variant name |
| `VARIANT_PRICE_REQUIRED` | "Variant price is required" | Empty variant price |
| `VARIANT_STOCK_REQUIRED` | "Variant stock is required" | Empty variant stock |
| `VARIANT_DELETE_LAST` | "Product must have at least 1 variant" | Trying to delete last variant |
| `IMAGES_MAX` | "Maximum 5 images allowed" | More than 5 images |
| `IMAGE_SIZE` | "Image size must be less than 5MB" | Large image |
| `IMAGE_FORMAT` | "Only JPG, PNG, WEBP allowed" | Invalid format |
| `RELATED_MAX` | "Maximum 4 related products allowed" | More than 4 related |
| `NOT_FOUND` | "Product not found" | Invalid product ID |
| `DELETE_FAILED` | "Failed to delete product" | Database error |

---

## 16. Security Considerations

### Admin Only Access
- All product endpoints require admin authentication
- Validate admin session before any operation

### Input Validation
- Sanitize product name (trim whitespace, prevent XSS)
- Validate category exists and is accessible
- Validate variant prices (positive numbers)
- Validate stock (non-negative integers)
- Validate discount format (number or number%)

### File Upload Security
- Validate file type (MIME type check)
- Validate file size (max 5MB)
- Generate unique filenames
- Store in non-executable directory
- Scan for malicious content

### Rate Limiting
- Max 20 product operations per minute per admin

---

## 17. Data Relationships

```
categories (1) ──────► (N) products
                              │
                              ├── (N) product_variants
                              ├── (N) product_images
                              ├── (N) product_faqs
                              └── (N) related_products
                                          │
                                          └──► products (self-reference)
```

---

## 18. Future Considerations

### Potential Enhancements (Not in Current Scope)
- Product tags/labels
- Product attributes (color, size, etc.)
- Bulk import/export
- Product duplication
- Product versioning/history
- Inventory alerts
- Product reviews/ratings
- Product SEO fields

---

## Document History

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0 | 2024-01-15 | EcoMart Team | Initial PRD |

---

**END OF PRODUCT MANAGEMENT PRD**
