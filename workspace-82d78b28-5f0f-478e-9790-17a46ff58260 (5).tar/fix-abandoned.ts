import { db } from './src/db'
import { sql } from 'drizzle-orm'

async function fixAbandonedTable() {
  try {
    // Drop the old table
    await db.run(sql`DROP TABLE IF EXISTS abandoned_checkouts`)
    console.log('Dropped old abandoned_checkouts table')
    
    // Create new table with correct schema
    await db.run(sql`
      CREATE TABLE abandoned_checkouts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        session_id TEXT NOT NULL,
        visit_number INTEGER DEFAULT 1,
        name TEXT,
        phone TEXT,
        address TEXT,
        items TEXT NOT NULL,
        subtotal REAL DEFAULT 0,
        delivery REAL DEFAULT 0,
        total REAL DEFAULT 0,
        status TEXT DEFAULT 'abandoned',
        completed_order_id TEXT,
        visit_time TEXT NOT NULL,
        visit_date TEXT NOT NULL,
        created_at INTEGER DEFAULT (unixepoch())
      )
    `)
    console.log('Created new abandoned_checkouts table')
    
    process.exit(0)
  } catch (error) {
    console.error('Error:', error)
    process.exit(1)
  }
}

fixAbandonedTable()
