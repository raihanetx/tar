import { createClient } from '@libsql/client'

const client = createClient({
  url: 'file:./db/custom.db'
})

async function checkDB() {
  try {
    // Get table info for abandoned_checkouts
    const result = await client.execute(`PRAGMA table_info(abandoned_checkouts)`)
    console.log('abandoned_checkouts columns:', JSON.stringify(result.rows, null, 2))
    
    // Get sample data
    const data = await client.execute(`SELECT * FROM abandoned_checkouts LIMIT 1`)
    console.log('Sample data:', data.rows)
    
    process.exit(0)
  } catch (error) {
    console.error('Error:', error)
    process.exit(1)
  }
}

checkDB()
