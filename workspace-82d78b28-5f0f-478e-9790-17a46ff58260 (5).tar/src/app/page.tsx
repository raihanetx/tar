'use client'

import { useState, useEffect, useCallback } from 'react'
import { ViewType } from '@/types'
import { useCartStore, useOrderStore } from '@/store'

// Layout Components
import Header from '@/components/layout/Header'
import BottomNav from '@/components/layout/BottomNav'
import Footer from '@/components/layout/Footer'

// Shop Components
import Shop from '@/components/shop/Shop'
import ProductDetail from '@/components/shop/ProductDetail'

// Cart Components
import Cart from '@/components/cart/Cart'
import Checkout from '@/components/cart/Checkout'

// Orders Components
import Orders from '@/components/orders/Orders'

// Admin Components
import AdminDashboard from '@/components/admin/AdminDashboard'

// Auth Components
import AuthWrapper from '@/components/auth/AuthWrapper'

// Content Pages
import ContentPage from '@/components/content/ContentPage'

// Spin Wheel Component
import SpinWheel, { SpinWheelTrigger } from '@/components/shop/SpinWheel'

// Main App Entry
export default function Home() {
  const [view, setView] = useState<ViewType>('shop')
  const [checkoutSessionId, setCheckoutSessionId] = useState<string>('')
  const [showSpinWheel, setShowSpinWheel] = useState(false)
  const [spinWheelDiscount, setSpinWheelDiscount] = useState<number | null>(null)
  const [deliverySettings, setDeliverySettings] = useState<{
    insideDhaka: number
    outsideDhaka: number
    freeDeliveryMin: number
    universal: boolean
    universalCharge: number
  }>({
    insideDhaka: 60,
    outsideDhaka: 120,
    freeDeliveryMin: 500,
    universal: false,
    universalCharge: 60
  })
  
  // Use Zustand stores
  const { items: cartItems, addItem: addToCart, removeItem, updateQuantity, clearCart } = useCartStore()
  const { orders, addOrder } = useOrderStore()

  // Callback for checkout session
  const handleCheckoutSession = useCallback((sessionId: string) => {
    setCheckoutSessionId(sessionId)
  }, [])

  // Fetch delivery settings
  useEffect(() => {
    const fetchSettings = async () => {
      try {
        const response = await fetch('/api/settings')
        const data = await response.json()
        if (data.success) {
          setDeliverySettings({
            insideDhaka: data.data.inside_dhaka_delivery ?? 60,
            outsideDhaka: data.data.outside_dhaka_delivery ?? 120,
            freeDeliveryMin: data.data.free_delivery_min ?? 500,
            universal: data.data.universal_delivery ?? false,
            universalCharge: data.data.universal_delivery_charge ?? 60
          })
        }
      } catch (error) {
        console.error('Error fetching settings:', error)
      }
    }
    fetchSettings()
  }, [])

  // Calculate delivery charge based on address
  const calculateDeliveryCharge = (address: string, subtotal: number): number => {
    // Free delivery if subtotal >= freeDeliveryMin
    if (subtotal >= deliverySettings.freeDeliveryMin) {
      return 0
    }
    
    // Universal delivery - same charge for all
    if (deliverySettings.universal) {
      return deliverySettings.universalCharge
    }
    
    // Auto-detect location from address
    const addressLower = address.toLowerCase()
    const dhakaKeywords = ['dhaka', 'dhanmondi', 'gulshan', 'uttara', 'mirpur', 'mohammadpur', 'banani', 'badda', 'tejgaon', 'motijheel', 'ramna', 'sabujbagh', 'khilgaon', 'kadamtali', 'demra', 'hazaribagh', 'lalbagh', 'kotwali', 'sutrapur', 'wari', 'chawkbazar', 'bangsal', 'shahbagh', 'paltan', 'jatrabari', 'shyampur', 'cantonment', 'turag', 'darussalam', 'kafrul', 'adabor', 'pallabi', 'sher-e-bangla nagar']
    
    const isInsideDhaka = dhakaKeywords.some(keyword => addressLower.includes(keyword))
    
    return isInsideDhaka ? deliverySettings.insideDhaka : deliverySettings.outsideDhaka
  }

  // Helper function to calculate offer discount for an item
  // Note: Discount applies if discountValue > 0, regardless of 'offer' flag
  // The 'offer' flag is only for showing product in "Offer Cards" section
  const calculateOfferDiscount = (item: { price: number; quantity: number; offer?: boolean; discountType?: 'pct' | 'fixed'; discountValue?: number }): { offerText: string | null; offerDiscount: number } => {
    // Apply discount if there's a valid discountValue
    if (!item.discountValue || item.discountValue <= 0) {
      return { offerText: null, offerDiscount: 0 }
    }
    
    const totalPrice = item.price * item.quantity
    
    if (item.discountType === 'pct') {
      const discount = Math.round(totalPrice * (item.discountValue / 100))
      return { 
        offerText: `${item.discountValue}% OFF`, 
        offerDiscount: discount 
      }
    } else {
      // Fixed discount
      const discount = Math.round(item.discountValue * item.quantity)
      return { 
        offerText: `TK ${item.discountValue} OFF`, 
        offerDiscount: Math.min(discount, totalPrice) 
      }
    }
  }

  const handleConfirmOrder = async (customerInfo: { name: string; phone: string; address: string }, couponCode?: string) => {
    try {
      // Calculate offer discounts for each item first
      const itemsWithOfferDiscount = cartItems.map(item => {
        const { offerText, offerDiscount } = calculateOfferDiscount(item)
        return {
          ...item,
          offerText,
          offerDiscount
        }
      })
      
      // Calculate subtotal after offer discounts (this is what coupon applies to)
      const subtotalBeforeOffer = cartItems.reduce((sum, item) => sum + item.price * (item.quantity || 1), 0)
      const totalOfferDiscount = itemsWithOfferDiscount.reduce((sum, item) => sum + item.offerDiscount, 0)
      const subtotalAfterOffer = subtotalBeforeOffer - totalOfferDiscount
      
      const delivery = calculateDeliveryCharge(customerInfo.address, subtotalAfterOffer)
      
      // Calculate coupon discount if code provided
      let couponDiscount = 0
      let couponAmount = 0
      let couponResult: { success: boolean; data?: any; applicableItems?: number[] } | null = null
      
      if (couponCode) {
        try {
          // Prepare cart items for coupon validation
          const cartItemsForCoupon = cartItems.map(item => ({
            productId: item.id,
            id: item.id,
            category: item.category || '',
            categoryId: item.categoryId,
            name: item.name
          }))
          
          const couponResponse = await fetch(`/api/coupons?code=${encodeURIComponent(couponCode.toUpperCase())}&cartItems=${encodeURIComponent(JSON.stringify(cartItemsForCoupon))}`)
          couponResult = await couponResponse.json()
          
          if (couponResult?.success && couponResult.data) {
            const coupon = couponResult.data
            
            // Determine applicable items and their subtotal
            let applicableItemsSubtotal = subtotalAfterOffer
            let applicableItems = cartItems.map(item => item.id) // All items by default
            
            if (coupon.scope !== 'all' && couponResult.applicableItems) {
              applicableItems = couponResult.applicableItems
              // Calculate subtotal for only applicable items (after offer discount)
              applicableItemsSubtotal = itemsWithOfferDiscount
                .filter(item => applicableItems.includes(item.id))
                .reduce((sum, item) => sum + (item.price * item.quantity - item.offerDiscount), 0)
            }
            
            if (coupon.type === 'pct') {
              couponDiscount = Math.round(applicableItemsSubtotal * (coupon.value / 100))
            } else {
              couponDiscount = Math.min(coupon.value, applicableItemsSubtotal)
            }
            couponAmount = couponDiscount
            
            // Distribute coupon discount proportionally among applicable items
            if (applicableItemsSubtotal > 0) {
              let distributedAmount = 0
              itemsWithOfferDiscount.forEach((item, index) => {
                if (applicableItems.includes(item.id)) {
                  const itemSubtotalAfterOffer = item.price * item.quantity - item.offerDiscount
                  const proportion = itemSubtotalAfterOffer / applicableItemsSubtotal
                  let itemCouponDiscount = 0
                  
                  if (index === itemsWithOfferDiscount.length - 1) {
                    // Last item gets remainder to avoid rounding errors
                    itemCouponDiscount = couponDiscount - distributedAmount
                  } else {
                    itemCouponDiscount = Math.round(couponDiscount * proportion)
                    distributedAmount += itemCouponDiscount
                  }
                  
                  ;(item as any).couponCode = couponCode.toUpperCase()
                  ;(item as any).couponDiscount = itemCouponDiscount
                }
              })
            }
          }
        } catch (e) {
          console.error('Error validating coupon:', e)
        }
      }
      
      const total = subtotalAfterOffer - couponDiscount + delivery
      
      // Generate order number
      const orderNumber = `ORD-${Date.now().toString().slice(-6)}`
      
      // Prepare items for order
      const orderItemsData = itemsWithOfferDiscount.map(item => ({
        name: item.name,
        variant: item.weight,
        qty: item.quantity || 1,
        basePrice: item.price,
        offerText: item.offerText,
        offerDiscount: item.offerDiscount,
        couponCode: (item as any).couponCode || null,
        couponDiscount: (item as any).couponDiscount || 0,
        productId: item.id,
      }))
      
      // Create order in database
      const response = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id: orderNumber,
          orderNumber,
          customerName: customerInfo.name,
          phone: customerInfo.phone,
          address: customerInfo.address,
          subtotal: subtotalBeforeOffer,
          delivery,
          discount: totalOfferDiscount,
          couponAmount,
          total,
          paymentMethod: 'Cash on Delivery',
          status: 'pending',
          couponCodes: couponCode ? [couponCode.toUpperCase()] : [],
          items: orderItemsData,
        }),
      })
      
      const result = await response.json()
      
      if (result.success) {
        // Mark abandoned checkout as completed
        if (checkoutSessionId) {
          try {
            await fetch('/api/abandoned', {
              method: 'PATCH',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                sessionId: checkoutSessionId,
                completedOrderId: orderNumber
              })
            })
            // Clear the session ID from storage
            if (typeof window !== 'undefined') {
              sessionStorage.removeItem('checkout_session_id')
            }
          } catch (e) {
            console.error('Error marking abandoned checkout as completed:', e)
          }
        }
        
        // Also save to local store for immediate display
        const newOrder = {
          id: orderNumber,
          customer: customerInfo.name,
          phone: customerInfo.phone,
          address: customerInfo.address,
          date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
          time: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
          paymentMethod: 'Cash on Delivery',
          status: 'pending' as const,
          courierStatus: 'Processing',
          subtotal: subtotalBeforeOffer,
          delivery,
          discount: totalOfferDiscount,
          couponCodes: couponCode ? [couponCode.toUpperCase()] : [],
          couponAmount,
          total,
          canceledBy: null,
          items: orderItemsData,
        }
        
        addOrder(newOrder)
        clearCart()
        setView('orders')
        window.scrollTo(0, 0)
      } else {
        alert('Failed to place order. Please try again.')
      }
    } catch (error) {
      console.error('Order error:', error)
      alert('An error occurred. Please try again.')
    }
  }

  // Convert cart items to the format expected by Cart component
  const cartItemsForDisplay = cartItems.map(item => ({
    ...item,
    oldPrice: item.oldPrice || item.price,
  }))

  // Check if we should show header, footer, bottom nav (not on admin or content pages)
  const showHeader = !['admin', 'about', 'terms', 'refund', 'privacy'].includes(view)
  const showFooter = !['admin', 'about', 'terms', 'refund', 'privacy'].includes(view)
  const showBottomNav = !['admin', 'about', 'terms', 'refund', 'privacy'].includes(view)

  return (
    <div className="flex flex-col min-h-screen relative">
      {showHeader && <Header view={view} setView={setView} cartCount={cartItems.reduce((sum, item) => sum + item.quantity, 0)} />}
      <div className="flex-grow w-full">
        {view === 'shop' && <Shop setView={setView} addToCart={addToCart} />}
        {view === 'product' && <ProductDetail setView={setView} addToCart={addToCart} />}
        {view === 'cart' && (
          <Cart 
            setView={setView} 
            cartItems={cartItemsForDisplay} 
            setCartItems={(items) => {
              clearCart()
              items.forEach(item => addToCart(item))
            }}
            onUpdateQuantity={(id, qty) => updateQuantity(id, qty)}
            onRemoveItem={(id) => removeItem(id)}
            freeDeliveryMin={deliverySettings.freeDeliveryMin}
          />
        )}
        {view === 'checkout' && (
          <Checkout 
            setView={setView} 
            cartItems={cartItemsForDisplay}
            deliverySettings={deliverySettings}
            onConfirm={handleConfirmOrder}
            onCheckoutSession={handleCheckoutSession}
            onRemoveItem={(id) => removeItem(id)}
          />
        )}
        {view === 'orders' && <Orders orders={orders} setView={setView} />}
        {view === 'admin' && (
          <AuthWrapper onBack={() => setView('shop')}>
            <AdminDashboard setView={setView} />
          </AuthWrapper>
        )}
        {/* Content Pages */}
        {(view === 'about' || view === 'terms' || view === 'refund' || view === 'privacy') && (
          <ContentPage type={view} setView={setView} />
        )}
      </div>
      {showFooter && <Footer setView={setView} />}
      {showBottomNav && <BottomNav view={view} setView={setView} />}
      
      {/* Spin Wheel Popup */}
      {showBottomNav && (
        <>
          <SpinWheelTrigger onClick={() => setShowSpinWheel(true)} />
          <SpinWheel 
            isOpen={showSpinWheel} 
            onClose={() => setShowSpinWheel(false)}
            onWin={(prize, discount) => {
              if (discount > 0) {
                setSpinWheelDiscount(discount)
                // You can store the discount in localStorage or state for checkout
                localStorage.setItem('spinWheelPrize', JSON.stringify({ prize, discount, claimedAt: new Date().toISOString() }))
              }
            }}
          />
        </>
      )}
    </div>
  )
}
