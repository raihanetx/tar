'use client'

import { useState } from 'react'
import { ViewType, Order } from '@/types'

interface OrdersProps {
  orders: Order[]
  setView: (v: ViewType) => void
}

export default function Orders({ orders, setView }: OrdersProps) {
  const [expandedOrderId, setExpandedOrderId] = useState<string | null>(null)

  if (orders.length === 0) {
    return (
      <div className="order-clean-wrapper">
        <div className="order-clean-empty">
          <i className="ri-file-list-3-line"></i>
          <h2>No orders yet</h2>
          <p>Your order history will appear here</p>
          <button onClick={() => setView('shop')}>Shop Now</button>
        </div>
      </div>
    )
  }

  // Get status info
  const getStatusInfo = (status: string) => {
    const statusMap: Record<string, { label: string; bgColor: string; textColor: string }> = {
      pending: { label: 'Processing', bgColor: '#FEF3C7', textColor: '#D97706' },
      packaging: { label: 'Packing', bgColor: '#FEF3C7', textColor: '#D97706' },
      shipping: { label: 'On the way', bgColor: '#DBEAFE', textColor: '#2563EB' },
      delivered: { label: 'Delivered', bgColor: '#D1FAE5', textColor: '#059669' },
      cancelled: { label: 'Cancelled', bgColor: '#FEE2E2', textColor: '#DC2626' },
      approved: { label: 'Confirmed', bgColor: '#D1FAE5', textColor: '#059669' },
    }
    return statusMap[status] || statusMap.pending
  }

  // Get product image
  const getProductImage = (itemName: string) => {
    const imageMap: Record<string, string> = {
      'carrot': 'https://i.postimg.cc/B6sD1hKt/1000020579-removebg-preview.png',
      'potato': 'https://i.postimg.cc/d1vdTWyL/1000020583-removebg-preview.png',
      'tomato': 'https://i.postimg.cc/mr7CkxtQ/1000020584-removebg-preview.png',
      'broccoli': 'https://i.postimg.cc/qR0nCm36/1000020611-removebg-preview.png',
    }
    const key = itemName.toLowerCase()
    for (const [k, v] of Object.entries(imageMap)) {
      if (key.includes(k)) return v
    }
    return 'https://i.postimg.cc/B6sD1hKt/1000020579-removebg-preview.png'
  }

  return (
    <div className="order-clean-wrapper">
      <div className="order-clean-container">
        <h1 className="order-clean-title">My Orders</h1>
        
        <div className="order-clean-list">
          {orders.map((order) => {
            const isExpanded = expandedOrderId === order.id
            const statusInfo = getStatusInfo(order.status)

            return (
              <div key={order.id} className="order-new-card">
                {/* Card Header */}
                <div 
                  className="order-new-header"
                  onClick={() => setExpandedOrderId(isExpanded ? null : order.id)}
                >
                  <div className="order-new-left">
                    <div className="order-new-id">#{order.id.slice(-6)}</div>
                    <div className="order-new-date">{order.date}</div>
                  </div>
                  <div className="order-new-right">
                    <span 
                      className="order-new-status"
                      style={{ backgroundColor: statusInfo.bgColor, color: statusInfo.textColor }}
                    >
                      {statusInfo.label}
                    </span>
                    <i className={`ri-arrow-${isExpanded ? 'up' : 'down'}-s-line order-new-arrow`}></i>
                  </div>
                </div>

                {/* Preview - Items summary */}
                {!isExpanded && (
                  <div className="order-new-preview" onClick={() => setExpandedOrderId(order.id)}>
                    <div className="order-new-preview-items">
                      {order.items.slice(0, 3).map((item, idx) => (
                        <img key={idx} src={getProductImage(item.name)} alt={item.name} />
                      ))}
                      {order.items.length > 3 && (
                        <span className="order-new-more">+{order.items.length - 3}</span>
                      )}
                    </div>
                    <div className="order-new-preview-total">
                      <span>Total</span>
                      <strong>TK {order.total}</strong>
                    </div>
                  </div>
                )}

                {/* Expanded Details */}
                {isExpanded && (
                  <div className="order-new-details">
                    {/* Items List */}
                    <div className="order-new-section">
                      <div className="order-new-items-grid">
                        {order.items.map((item, idx) => (
                          <div key={idx} className="order-new-item-row">
                            <img src={getProductImage(item.name)} alt={item.name} />
                            <div className="order-new-item-info">
                              <span className="order-new-item-name">{item.name}</span>
                              <span className="order-new-item-variant">{item.variant} × {item.qty}</span>
                            </div>
                            <span className="order-new-item-price">TK {item.basePrice * item.qty}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Customer & Delivery */}
                    <div className="order-new-section order-new-info-grid">
                      <div className="order-new-info-col">
                        <span className="order-new-info-label">Name</span>
                        <span className="order-new-info-value">{order.customer}</span>
                      </div>
                      <div className="order-new-info-col">
                        <span className="order-new-info-label">Phone</span>
                        <span className="order-new-info-value">{order.phone}</span>
                      </div>
                      <div className="order-new-info-col full">
                        <span className="order-new-info-label">Address</span>
                        <span className="order-new-info-value">{order.address}</span>
                      </div>
                      <div className="order-new-info-col">
                        <span className="order-new-info-label">Est. Delivery</span>
                        <span className="order-new-info-value highlight">1 - 7 Days</span>
                      </div>
                    </div>

                    {/* Payment Summary */}
                    <div className="order-new-summary">
                      <div className="order-new-summary-row">
                        <span>Subtotal</span>
                        <span>TK {order.subtotal}</span>
                      </div>
                      {order.discount > 0 && (
                        <div className="order-new-summary-row green">
                          <span>Discount</span>
                          <span>-TK {order.discount}</span>
                        </div>
                      )}
                      <div className="order-new-summary-row">
                        <span>Delivery</span>
                        <span>{order.delivery > 0 ? `TK ${order.delivery}` : 'FREE'}</span>
                      </div>
                      <div className="order-new-summary-total">
                        <span>Pay to Rider</span>
                        <span>TK {order.total}</span>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}
