import { db } from './src/db'
import { sql } from 'drizzle-orm'

async function checkDB() {
  try {
    // Get table info for abandoned_checkouts
    const result = await db.run(sql`PRAGMA table_info(abandoned_checkouts)`)
    console.log('abandoned_checkouts columns:', result)
    
    // Check if table exists
    const tables = await db.run(sql`SELECT name FROM sqlite_master WHERE type='table'`)
    console.log('All tables:', tables)
    
    process.exit(0)
  } catch (error) {
    console.error('Error:', error)
    process.exit(1)
  }
}

checkDB()
