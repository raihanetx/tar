import { Database } from 'bun:sqlite'

const db = new Database('/home/z/my-project/db/custom.db')

// Add password_display column if not exists
try {
  db.run(`ALTER TABLE admin_users ADD COLUMN password_display TEXT`)
  console.log('Added password_display column')
} catch (e) {
  console.log('password_display column already exists or error:', e)
}

db.close()
console.log('Done!')
