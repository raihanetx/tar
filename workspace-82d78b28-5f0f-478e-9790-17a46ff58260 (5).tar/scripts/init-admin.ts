import { createClient } from '@libsql/client'
import bcrypt from 'bcryptjs'
import crypto from 'crypto'

// Encryption helpers
const ENCRYPTION_KEY = process.env.ENCRYPTION_KEY || 'ecomart-encryption-key-32ch'
const ALGORITHM = 'aes-256-cbc'
const IV_LENGTH = 16

const getKey = (): Buffer => {
  const key = ENCRYPTION_KEY.padEnd(32, '0').slice(0, 32)
  return Buffer.from(key, 'utf8')
}

function encrypt(text: string): string {
  if (!text) return ''
  const iv = crypto.randomBytes(IV_LENGTH)
  const cipher = crypto.createCipheriv(ALGORITHM, getKey(), iv)
  let encrypted = cipher.update(text, 'utf8', 'hex')
  encrypted += cipher.final('hex')
  return iv.toString('hex') + ':' + encrypted
}

async function initAdmin() {
  const client = createClient({
    url: 'file:/home/z/my-project/db/custom.db'
  })

  try {
    console.log('🔄 Creating admin_users table if not exists...')
    
    // Create table with password_display column
    await client.execute(`
      CREATE TABLE IF NOT EXISTS admin_users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL,
        password_display TEXT,
        name TEXT,
        created_at INTEGER DEFAULT (unixepoch()),
        updated_at INTEGER DEFAULT (unixepoch())
      )
    `)
    
    console.log('✅ Table created/verified')
    
    // Check if admin exists
    const result = await client.execute('SELECT * FROM admin_users LIMIT 1')
    
    if (result.rows.length > 0) {
      console.log('✅ Admin user already exists')
      
      // Check if password_display exists, if not add it
      const user = result.rows[0]
      if (!user.password_display) {
        console.log('📝 Adding password_display for existing user...')
        const encryptedPassword = encrypt('admin123')
        await client.execute({
          sql: 'UPDATE admin_users SET password_display = ? WHERE id = ?',
          args: [encryptedPassword, user.id]
        })
        console.log('✅ Updated password_display')
      }
      return
    }
    
    console.log('📝 Creating default admin user...')
    
    // Create default admin
    const password = 'admin123'
    const hashedPassword = await bcrypt.hash(password, 10)
    const encryptedPassword = encrypt(password)
    
    await client.execute({
      sql: 'INSERT INTO admin_users (username, password, password_display, name) VALUES (?, ?, ?, ?)',
      args: ['admin', hashedPassword, encryptedPassword, 'Administrator']
    })
    
    console.log('')
    console.log('   ╔══════════════════════════════════╗')
    console.log('   ║      ADMIN LOGIN CREDENTIALS      ║')
    console.log('   ╠══════════════════════════════════╣')
    console.log('   ║  Username: admin                  ║')
    console.log('   ║  Password: admin123               ║')
    console.log('   ╠══════════════════════════════════╣')
    console.log('   ║  ⚠️ Change password after login!  ║')
    console.log('   ╚══════════════════════════════════╝')
    console.log('')
  } catch (error) {
    console.error('❌ Error:', error)
  }
}

initAdmin()
