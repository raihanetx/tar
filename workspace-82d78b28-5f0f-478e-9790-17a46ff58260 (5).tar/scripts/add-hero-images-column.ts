import { Database } from 'bun:sqlite'

const db = new Database('/home/z/my-project/db/custom.db')

try {
  // Add hero_images column to settings table
  db.run(`ALTER TABLE settings ADD COLUMN hero_images TEXT DEFAULT '[]'`)
  console.log('Added hero_images column to settings table')
} catch (e) {
  console.log('Column may already exist:', e)
}

db.close()
console.log('Done!')
