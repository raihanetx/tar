import { Database } from 'bun:sqlite'

const db = new Database('/home/z/my-project/db/custom.db')

db.run(`
  CREATE TABLE IF NOT EXISTS api_credentials (
    id INTEGER PRIMARY KEY DEFAULT 1,
    steadfast_api_key TEXT,
    steadfast_secret_key TEXT,
    webhook_url TEXT,
    created_at INTEGER DEFAULT (unixepoch()),
    updated_at INTEGER DEFAULT (unixepoch())
  )
`)

// Insert default row if not exists
db.run(`INSERT OR IGNORE INTO api_credentials (id) VALUES (1)`)

console.log('api_credentials table created successfully')

db.close()
