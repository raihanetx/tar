import { createClient } from '@libsql/client'

const db = createClient({
  url: 'file:./db/custom.db'
})

async function main() {
  try {
    await db.execute("ALTER TABLE variants ADD COLUMN price REAL DEFAULT 0")
    console.log('Added price column to variants')
  } catch (e: any) {
    if (e.message.includes('duplicate column')) {
      console.log('price column already exists')
    } else {
      console.error('Error:', e)
    }
  }
  
  try {
    await db.execute("ALTER TABLE variants ADD COLUMN discount TEXT DEFAULT '0%'")
    console.log('Added discount column to variants')
  } catch (e: any) {
    if (e.message.includes('duplicate column')) {
      console.log('discount column already exists')
    } else {
      console.error('Error:', e)
    }
  }
}

main().catch(console.error)
