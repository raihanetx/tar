import { createClient } from '@libsql/client'

const client = createClient({
  url: 'file:./db/custom.db'
})

async function migrate() {
  console.log('Adding discount columns to products and variants tables...')
  
  try {
    // Add columns to products table
    const productColumns = await client.execute("PRAGMA table_info(products)")
    const productColumnNames = productColumns.rows.map(r => r.name)
    
    if (!productColumnNames.includes('discount_type')) {
      console.log('Adding discount_type to products...')
      await client.execute("ALTER TABLE products ADD COLUMN discount_type TEXT DEFAULT 'pct'")
    }
    
    if (!productColumnNames.includes('discount_value')) {
      console.log('Adding discount_value to products...')
      await client.execute("ALTER TABLE products ADD COLUMN discount_value REAL DEFAULT 0")
    }
    
    // Add columns to variants table
    const variantColumns = await client.execute("PRAGMA table_info(variants)")
    const variantColumnNames = variantColumns.rows.map(r => r.name)
    
    if (!variantColumnNames.includes('discount_type')) {
      console.log('Adding discount_type to variants...')
      await client.execute("ALTER TABLE variants ADD COLUMN discount_type TEXT DEFAULT 'pct'")
    }
    
    if (!variantColumnNames.includes('discount_value')) {
      console.log('Adding discount_value to variants...')
      await client.execute("ALTER TABLE variants ADD COLUMN discount_value REAL DEFAULT 0")
    }
    
    // Migrate existing discount data from old format to new format
    console.log('Migrating existing discount data...')
    
    // Get all products with discount
    const products = await client.execute("SELECT id, discount FROM products WHERE discount IS NOT NULL AND discount != '0%'")
    for (const row of products.rows) {
      const discount = row.discount as string
      const { type, value } = parseDiscount(discount)
      await client.execute({
        sql: "UPDATE products SET discount_type = ?, discount_value = ? WHERE id = ?",
        args: [type, value, row.id]
      })
      console.log(`Updated product ${row.id}: ${discount} -> ${type}: ${value}`)
    }
    
    // Get all variants with discount
    const variantsResult = await client.execute("SELECT id, discount FROM variants WHERE discount IS NOT NULL AND discount != '0%'")
    for (const row of variantsResult.rows) {
      const discount = row.discount as string
      const { type, value } = parseDiscount(discount)
      await client.execute({
        sql: "UPDATE variants SET discount_type = ?, discount_value = ? WHERE id = ?",
        args: [type, value, row.id]
      })
      console.log(`Updated variant ${row.id}: ${discount} -> ${type}: ${value}`)
    }
    
    console.log('Migration completed successfully!')
  } catch (error) {
    console.error('Migration error:', error)
    throw error
  }
}

// Parse discount string like "10%" or "50" or "50tk"
function parseDiscount(discount: string): { type: 'pct' | 'fixed'; value: number } {
  if (!discount || discount === '0%' || discount === '0') {
    return { type: 'pct', value: 0 }
  }
  
  const cleanDiscount = discount.toLowerCase().trim()
  
  // Check if it's a percentage (e.g., "10%", "10 %")
  if (cleanDiscount.includes('%')) {
    const num = parseFloat(cleanDiscount.replace('%', '').trim())
    return { type: 'pct', value: isNaN(num) ? 0 : num }
  }
  
  // Check if it's a fixed amount (e.g., "50", "50tk", "50 tk")
  const numStr = cleanDiscount.replace('tk', '').replace('৳', '').trim()
  const num = parseFloat(numStr)
  
  if (!isNaN(num) && num > 0) {
    // If the number is > 100, it's likely a percentage, otherwise fixed
    // But we'll treat anything without % as fixed for now
    return { type: 'fixed', value: num }
  }
  
  return { type: 'pct', value: 0 }
}

migrate()
