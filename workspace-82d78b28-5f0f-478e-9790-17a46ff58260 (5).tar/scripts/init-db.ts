import { Database } from 'bun:sqlite';

const db = new Database('./db/custom.db');

console.log('Creating tables...');

// Create categories table
db.run(`
  CREATE TABLE IF NOT EXISTS categories (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    type TEXT DEFAULT 'icon',
    icon TEXT,
    image TEXT,
    items INTEGER DEFAULT 0,
    status TEXT DEFAULT 'Active',
    created_at INTEGER DEFAULT (unixepoch())
  )
`);

// Create products table
db.run(`
  CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    category TEXT NOT NULL,
    category_id TEXT REFERENCES categories(id),
    image TEXT NOT NULL,
    price REAL NOT NULL,
    old_price REAL,
    discount TEXT DEFAULT '0%',
    offer INTEGER DEFAULT 0,
    status TEXT DEFAULT 'active',
    short_desc TEXT,
    long_desc TEXT,
    weight TEXT,
    created_at INTEGER DEFAULT (unixepoch()),
    updated_at INTEGER DEFAULT (unixepoch())
  )
`);

// Create variants table
db.run(`
  CREATE TABLE IF NOT EXISTS variants (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    stock INTEGER NOT NULL,
    initial_stock INTEGER NOT NULL,
    product_id INTEGER NOT NULL REFERENCES products(id)
  )
`);

// Create customers table
db.run(`
  CREATE TABLE IF NOT EXISTS customers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    phone TEXT NOT NULL,
    address TEXT,
    email TEXT,
    total_spent REAL DEFAULT 0,
    total_orders INTEGER DEFAULT 0,
    created_at INTEGER DEFAULT (unixepoch())
  )
`);

// Create orders table
db.run(`
  CREATE TABLE IF NOT EXISTS orders (
    id TEXT PRIMARY KEY,
    customer_id INTEGER REFERENCES customers(id),
    customer_name TEXT NOT NULL,
    phone TEXT NOT NULL,
    address TEXT NOT NULL,
    date TEXT NOT NULL,
    time TEXT NOT NULL,
    payment_method TEXT NOT NULL,
    status TEXT DEFAULT 'pending',
    courier_status TEXT,
    subtotal REAL NOT NULL,
    delivery REAL NOT NULL,
    discount REAL DEFAULT 0,
    coupon_amount REAL DEFAULT 0,
    total REAL NOT NULL,
    canceled_by TEXT,
    coupon_codes TEXT DEFAULT '[]',
    created_at INTEGER DEFAULT (unixepoch()),
    updated_at INTEGER DEFAULT (unixepoch())
  )
`);

// Create order_items table
db.run(`
  CREATE TABLE IF NOT EXISTS order_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    variant TEXT,
    qty INTEGER NOT NULL,
    base_price REAL NOT NULL,
    offer_text TEXT,
    offer_discount REAL DEFAULT 0,
    coupon_code TEXT,
    coupon_discount REAL DEFAULT 0,
    order_id TEXT NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    product_id INTEGER REFERENCES products(id)
  )
`);

// Create coupons table
db.run(`
  CREATE TABLE IF NOT EXISTS coupons (
    id TEXT PRIMARY KEY,
    code TEXT NOT NULL UNIQUE,
    type TEXT NOT NULL,
    value REAL NOT NULL,
    scope TEXT NOT NULL,
    expiry TEXT,
    selected_products TEXT,
    selected_categories TEXT,
    created_at INTEGER DEFAULT (unixepoch())
  )
`);

// Create abandoned_checkouts table
db.run(`
  CREATE TABLE IF NOT EXISTS abandoned_checkouts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    phone TEXT NOT NULL,
    address TEXT,
    visit_time TEXT NOT NULL,
    visit_date TEXT NOT NULL,
    total_visits INTEGER DEFAULT 1,
    completed_orders INTEGER DEFAULT 0,
    history TEXT NOT NULL,
    created_at INTEGER DEFAULT (unixepoch())
  )
`);

// Create settings table
db.run(`
  CREATE TABLE IF NOT EXISTS settings (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    website_name TEXT DEFAULT 'Krishi Bitan',
    slogan TEXT,
    favicon_url TEXT,
    inside_dhaka_delivery REAL DEFAULT 60,
    outside_dhaka_delivery REAL DEFAULT 120,
    free_delivery_min REAL DEFAULT 500,
    whatsapp_number TEXT,
    phone_number TEXT,
    facebook_url TEXT,
    messenger_username TEXT,
    about_us TEXT,
    terms_conditions TEXT,
    refund_policy TEXT,
    privacy_policy TEXT
  )
`);

// Insert default settings
db.run(`
  INSERT OR IGNORE INTO settings (id) VALUES (1)
`);

// Create reviews table
db.run(`
  CREATE TABLE IF NOT EXISTS reviews (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    initials TEXT NOT NULL,
    name TEXT NOT NULL,
    rating INTEGER NOT NULL,
    text TEXT NOT NULL,
    date TEXT NOT NULL,
    product_id INTEGER REFERENCES products(id),
    customer_id INTEGER REFERENCES customers(id)
  )
`);

console.log('Tables created successfully!');

db.close();
