import { defineConfig } from 'drizzle-kit'

// Neon PostgreSQL connection URL
const DATABASE_URL = 'postgresql://neondb_owner:npg_fpYOD6th3nBT@ep-misty-mouse-a17jt54s-pooler.ap-southeast-1.aws.neon.tech/neondb?sslmode=require'

export default defineConfig({
  schema: './src/db/schema.ts',
  out: './drizzle',
  dialect: 'postgresql',
  dbCredentials: {
    url: DATABASE_URL,
  },
})
