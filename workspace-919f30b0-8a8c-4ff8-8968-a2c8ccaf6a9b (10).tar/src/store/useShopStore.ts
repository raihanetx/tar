import { create } from 'zustand'
import { persist } from 'zustand/middleware'

// Types
export interface ShopCategory {
  id: string
  name: string
  type: string
  icon: string | null
  image: string | null
  items: number
  status: string
}

export interface ShopProduct {
  id: number
  name: string
  category: string
  categoryId: string | null
  image: string
  price: number
  oldPrice: number | null
  discount: string
  discountType: string | null
  discountValue: number | null
  offer: boolean
  status: string
  shortDesc: string | null
  inStock: boolean
  stockCount: number
  hasVariants: boolean
}

export interface ProductVariant {
  id: number
  name: string
  stock: number
  initialStock: number
  price: number
  discount: string
  discountType: string | null
  discountValue: number | null
  productId: number
}

export interface ProductImage {
  id: number
  url: string
  sortOrder: number
  productId: number
}

export interface ProductFaq {
  id: number
  question: string
  answer: string
  sortOrder: number
  productId: number
}

export interface RelatedProduct {
  id: number
  relatedProductId: number
  sortOrder: number
  productId: number
  product: ShopProduct | null
}

export interface ProductReview {
  id: number
  initials: string
  name: string
  rating: number
  text: string
  date: string
  productId: number | null
  customerId: number | null
}

export interface ShopSettings {
  websiteName: string
  slogan: string
  logoUrl: string
  faviconUrl: string
  heroImages: string[]
  whatsappNumber: string
  phoneNumber: string
  facebookUrl: string
  messengerUsername: string
  insideDhakaDelivery: number
  outsideDhakaDelivery: number
  freeDeliveryMin: number
  universalDelivery: boolean
  universalDeliveryCharge: number
  firstSectionName: string
  firstSectionSlogan: string
  secondSectionName: string
  secondSectionSlogan: string
  thirdSectionName: string
  thirdSectionSlogan: string
}

// Default settings (minimal defaults - actual data comes from database)
const defaultSettings: ShopSettings = {
  websiteName: 'EcoMart',
  slogan: 'Your trusted marketplace for fresh organic products and groceries.',
  logoUrl: '', // Empty - will be loaded from database
  faviconUrl: '',
  heroImages: [], // Empty - will be loaded from database
  whatsappNumber: '',
  phoneNumber: '',
  facebookUrl: '',
  messengerUsername: '',
  insideDhakaDelivery: 60,
  outsideDhakaDelivery: 120,
  freeDeliveryMin: 500,
  universalDelivery: false,
  universalDeliveryCharge: 60,
  firstSectionName: 'Categories',
  firstSectionSlogan: '',
  secondSectionName: 'Offers',
  secondSectionSlogan: '',
  thirdSectionName: 'Featured',
  thirdSectionSlogan: '',
}

interface ShopState {
  categories: ShopCategory[]
  products: ShopProduct[]
  settings: ShopSettings
  variantMap: Record<number, ProductVariant[]>
  selectedProductId: number | null
  selectedProductVariants: ProductVariant[]
  selectedProductImages: ProductImage[]
  selectedProductFaqs: ProductFaq[]
  selectedProductRelated: RelatedProduct[]
  selectedProductReviews: ProductReview[]
  selectedProduct: ShopProduct | null
  isLoading: boolean
  isProductLoading: boolean
  settingsLoaded: boolean
  error: string | null
  searchQuery: string
  selectedCategory: string | null
  lastFetch: number

  // Actions
  fetchData: () => Promise<void>
  setSelectedProduct: (productId: number | null) => Promise<void>
  addReview: (productId: number, review: { name: string; rating: number; text: string }) => Promise<boolean>
  setSearchQuery: (query: string) => void
  setSelectedCategory: (category: string | null) => void
}

// Cache duration - don't refetch if data is fresh
const CACHE_DURATION = 30 * 1000 // 30 seconds

// SMART: In-memory cache (NOT localStorage - too much data!)
let memoryCache: {
  categories: ShopCategory[]
  products: ShopProduct[]
  settings: ShopSettings
  variantMap: Record<number, ProductVariant[]>
  lastFetch: number
} | null = null

export const useShopStore = create<ShopState>()(
  persist(
    (set, get) => ({
      categories: memoryCache?.categories || [],
      products: memoryCache?.products || [],
      settings: memoryCache?.settings || defaultSettings,
      variantMap: memoryCache?.variantMap || {},
      selectedProductId: null,
      selectedProductVariants: [],
      selectedProductImages: [],
      selectedProductFaqs: [],
      selectedProductRelated: [],
      selectedProductReviews: [],
      selectedProduct: null,
      isLoading: !memoryCache, // Only loading if no cache
      isProductLoading: false,
      settingsLoaded: !!memoryCache,
      error: null,
      searchQuery: '',
      selectedCategory: null,
      lastFetch: memoryCache?.lastFetch || 0,

      // SINGLE API CALL for all shop data
      fetchData: async () => {
        const now = Date.now()
        const { lastFetch, products, categories } = get()
        
        // Check memory cache first (instant!)
        if (memoryCache && now - memoryCache.lastFetch < CACHE_DURATION) {
          set({
            categories: memoryCache.categories,
            products: memoryCache.products,
            settings: memoryCache.settings,
            variantMap: memoryCache.variantMap,
            isLoading: false,
            settingsLoaded: true,
          })
          return
        }
        
        // Skip if data is fresh and we have data
        if (now - lastFetch < CACHE_DURATION && products.length > 0 && categories.length > 0) {
          set({ isLoading: false })
          return
        }

        set({ isLoading: true, error: null })
        
        try {
          // SINGLE API CALL - lightning fast!
          const response = await fetch('/api/shop-data')
          const result = await response.json()
          
          if (result.success) {
            // Use variantMap from API (includes discount info)
            const variantMap: Record<number, ProductVariant[]> = {}
            if (result.data.variantMap) {
              Object.entries(result.data.variantMap).forEach(([id, variants]: [string, any]) => {
                variantMap[parseInt(id)] = variants.map((v: any) => ({
                  id: v.id,
                  name: v.name,
                  stock: v.stock,
                  initialStock: v.stock,
                  price: v.price,
                  discount: v.discount || '0%',
                  discountType: v.discountType || 'pct',
                  discountValue: v.discountValue || 0,
                  productId: parseInt(id),
                }))
              })
            }

            // SMART: Update memory cache (fast, no localStorage quota issues!)
            memoryCache = {
              categories: result.data.categories,
              products: result.data.products,
              settings: result.data.settings,
              variantMap: variantMap,
              lastFetch: now,
            }

            set({
              categories: result.data.categories,
              products: result.data.products,
              settings: result.data.settings,
              variantMap: variantMap,
              settingsLoaded: true,
              isLoading: false,
              lastFetch: now,
            })
          } else {
            set({ error: result.error || 'Failed to load', isLoading: false })
          }
        } catch (error) {
          console.error('Shop data fetch error:', error)
          set({ error: 'Failed to load data', isLoading: false })
        }
      },

      // SINGLE API CALL for product details
      setSelectedProduct: async (productId: number | null) => {
        set({ selectedProductId: productId })
        
        if (!productId) {
          set({
            selectedProduct: null,
            selectedProductVariants: [],
            selectedProductImages: [],
            selectedProductFaqs: [],
            selectedProductRelated: [],
            selectedProductReviews: [],
          })
          return
        }

        // Set product from cache immediately for instant display
        const { products, variantMap } = get()
        const product = products.find(p => p.id === productId)
        if (product) {
          set({
            selectedProduct: product,
            selectedProductVariants: (variantMap[productId] || []).map(v => ({
              ...v,
              initialStock: v.stock,
              discount: '0%',
              discountType: null,
              discountValue: null,
              productId: productId
            }))
          })
        }
        
        set({ isProductLoading: true })
        
        try {
          // SINGLE API CALL for all product details
          const response = await fetch(`/api/product-details?productId=${productId}`)
          const result = await response.json()
          
          if (result.success) {
            set({
              selectedProduct: result.data.product,
              selectedProductVariants: result.data.variants,
              selectedProductImages: result.data.images,
              selectedProductFaqs: result.data.faqs,
              selectedProductRelated: result.data.relatedProducts.map((p: any) => ({
                id: p.id,
                relatedProductId: p.id,
                sortOrder: 0,
                productId: productId,
                product: p
              })),
              selectedProductReviews: result.data.reviews,
              isProductLoading: false,
            })
          } else {
            set({ isProductLoading: false })
          }
        } catch (error) {
          console.error('Product details fetch error:', error)
          set({ isProductLoading: false })
        }
      },

      addReview: async (productId: number, review: { name: string; rating: number; text: string }) => {
        try {
          const response = await fetch('/api/reviews', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ ...review, productId })
          })
          const data = await response.json()
          if (data.success) {
            set(state => ({
              selectedProductReviews: [data.data, ...state.selectedProductReviews]
            }))
            return true
          }
          return false
        } catch (error) {
          console.error('Error adding review:', error)
          return false
        }
      },

      setSearchQuery: (query: string) => set({ searchQuery: query }),
      setSelectedCategory: (category: string | null) => set({ selectedCategory: category }),
    }),
    {
      name: 'shop-storage',
      // SMART: Only persist lastFetch timestamp (tiny data, no quota issues!)
      // Products/categories/settings are cached in memory, NOT localStorage
      partialize: (state) => ({
        lastFetch: state.lastFetch,
      }),
    }
  )
)
