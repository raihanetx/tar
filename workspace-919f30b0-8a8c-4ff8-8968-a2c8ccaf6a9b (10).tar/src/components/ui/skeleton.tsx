import { cn } from "@/lib/utils"

function Skeleton({ className, ...props }: React.ComponentProps<"div">) {
  return (
    <div
      data-slot="skeleton"
      className={cn("skeleton-shimmer rounded-md", className)}
      {...props}
    />
  )
}

// Headline Skeleton - for section titles (matches text-lg md:text-2xl font-bold)
function HeadlineSkeleton({ 
  className, 
  width = '150px',
  height = '24px',
  centered = false
}: { 
  className?: string
  width?: string
  height?: string
  centered?: boolean
}) {
  return (
    <span 
      className={cn("skeleton-headline", centered && "mx-auto block", className)}
      style={{ width, height }}
    />
  )
}

// Subheadline Skeleton - for section subtitles (matches text-xs md:text-sm)
function SubheadlineSkeleton({ 
  className,
  width = '200px',
  centered = false
}: { 
  className?: string
  width?: string
  centered?: boolean
}) {
  return (
    <span 
      className={cn("skeleton-text mt-0.5", centered && "mx-auto block", className)}
      style={{ width, height: '14px' }}
    />
  )
}

// Text Skeleton - for inline text
function TextSkeleton({ 
  className, 
  lines = 1,
  width 
}: { 
  className?: string
  lines?: number
  width?: string | number
}) {
  return (
    <div className={cn("space-y-2", className)}>
      {Array.from({ length: lines }).map((_, i) => (
        <span 
          key={i} 
          className="skeleton-text block"
          style={{ 
            width: width 
              ? (typeof width === 'number' ? `${width}px` : width)
              : (i === lines - 1 ? '60%' : '100%'),
            height: '14px'
          }}
        />
      ))}
    </div>
  )
}

// Product Card Skeleton - EXACTLY matches the product card template
function ProductCardSkeleton() {
  return (
    <div className="bg-white p-3 border border-gray-200 rounded-xl w-full min-h-[230px] md:min-h-[260px] flex flex-col">
      {/* Discount badge placeholder */}
      <div className="absolute top-2 left-2 skeleton-rounded w-12 h-5 opacity-0" />
      
      {/* Image area */}
      <div className="flex-grow flex items-center justify-center py-2">
        <Skeleton className="w-full h-[130px] md:h-[150px] rounded-lg" />
      </div>
      
      {/* Content area */}
      <div className="flex flex-col mt-auto">
        {/* Product name */}
        <span className="skeleton-text block w-3/4" style={{ height: '14px' }} />
        {/* Price row */}
        <div className="flex items-center gap-2 mb-2 mt-1">
          <span className="skeleton-text" style={{ width: '60px', height: '14px' }} />
        </div>
        {/* Button */}
        <Skeleton className="h-9 md:h-10 w-full rounded-md" />
      </div>
    </div>
  )
}

// Category Skeleton - EXACTLY matches category item
function CategorySkeleton() {
  return (
    <div className="flex-shrink-0 flex flex-col items-center">
      <div className="skeleton-rounded w-[60px] h-[60px] md:w-[85px] md:h-[85px]" />
      <span className="skeleton-text mt-1.5" style={{ width: '48px', height: '11px' }} />
    </div>
  )
}

// Hero Slider Skeleton - matches hero banner
function HeroSkeleton() {
  return (
    <Skeleton className="h-full w-full rounded-2xl" />
  )
}

// Offer Card Skeleton - EXACTLY matches offer card template
function OfferCardSkeleton() {
  return (
    <div className="bg-white rounded-lg flex relative border border-gray-200 overflow-hidden shrink-0 w-[250px] h-[100px]">
      {/* Left Side: Image placeholder */}
      <div className="w-1/2 h-full bg-gray-50 border-r border-gray-100 flex items-center justify-center p-1">
        <Skeleton className="w-full h-full rounded-none" />
      </div>
      {/* Right Side: Content */}
      <div className="w-1/2 p-2 flex flex-col justify-center gap-1">
        <span className="skeleton-text" style={{ width: '40px', height: '9px' }} />
        <span className="skeleton-text" style={{ width: '80%', height: '14px' }} />
        <span className="skeleton-text" style={{ width: '50px', height: '13px' }} />
      </div>
    </div>
  )
}

// Product Detail Skeleton
function ProductDetailSkeleton() {
  return (
    <div className="bg-white min-h-screen p-4 md:p-20">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-10">
        {/* Image Section */}
        <div className="flex flex-col">
          <Skeleton className="w-full h-[280px] md:h-[350px] rounded-2xl" />
          <div className="grid grid-cols-4 gap-2 mt-3">
            {[1, 2, 3, 4].map((i) => (
              <Skeleton key={i} className="aspect-square rounded-lg" />
            ))}
          </div>
        </div>
        
        {/* Content Section */}
        <div className="flex flex-col">
          {/* Title */}
          <span className="skeleton-text mb-3" style={{ width: '80%', height: '28px' }} />
          
          {/* Price Row */}
          <div className="flex items-center gap-3 mb-5">
            <span className="skeleton-text" style={{ width: '100px', height: '24px' }} />
            <span className="skeleton-text" style={{ width: '70px', height: '18px' }} />
          </div>
          
          {/* Description */}
          <div className="space-y-2 mb-6">
            <span className="skeleton-text block" style={{ height: '14px' }} />
            <span className="skeleton-text block" style={{ height: '14px' }} />
            <span className="skeleton-text block" style={{ width: '70%', height: '14px' }} />
          </div>
          
          {/* Variants */}
          <div className="mb-4">
            <span className="skeleton-text mb-2 block" style={{ width: '100px', height: '14px' }} />
            <div className="flex gap-2">
              <Skeleton className="h-10 w-20 rounded-lg" />
              <Skeleton className="h-10 w-20 rounded-lg" />
              <Skeleton className="h-10 w-20 rounded-lg" />
            </div>
          </div>
          
          {/* Buttons */}
          <Skeleton className="h-12 w-full rounded-xl mt-4" />
          <Skeleton className="h-14 w-full rounded-xl mt-3" />
        </div>
      </div>
    </div>
  )
}

// Cart Item Skeleton
function CartItemSkeleton() {
  return (
    <div className="bg-white border border-gray-200 rounded-xl p-3 flex items-center gap-3">
      <Skeleton className="w-16 h-16 rounded-lg" />
      <div className="flex-1 space-y-2">
        <span className="skeleton-text block" style={{ width: '80%', height: '14px' }} />
        <span className="skeleton-text block" style={{ width: '50%', height: '12px' }} />
      </div>
      <Skeleton className="h-8 w-20 rounded-lg" />
    </div>
  )
}

// Section Header Skeleton - EXACTLY matches section headers
function SectionHeaderSkeleton({ 
  titleWidth = '150px',
  subtitleWidth = '180px',
  className
}: { 
  titleWidth?: string
  subtitleWidth?: string
  className?: string
}) {
  return (
    <div className={cn("text-center mb-3 md:mb-4", className)}>
      <HeadlineSkeleton width={titleWidth} height="20px" centered />
      <SubheadlineSkeleton width={subtitleWidth} centered />
    </div>
  )
}

// Content Wrapper with Fade-in Animation
function ContentWrapper({ 
  children, 
  isLoading,
  skeleton,
  className
}: { 
  children: React.ReactNode
  isLoading: boolean
  skeleton: React.ReactNode
  className?: string
}) {
  return (
    <div className={cn("relative", className)}>
      {/* Skeleton - fades out when loading is done */}
      <div 
        className={cn(
          "transition-all duration-500 ease-out",
          isLoading ? "opacity-100" : "opacity-0 pointer-events-none absolute inset-0"
        )}
      >
        {skeleton}
      </div>
      
      {/* Content - fades in when loading is done */}
      <div 
        className={cn(
          "transition-all duration-500 ease-out",
          isLoading ? "opacity-0" : "opacity-100"
        )}
      >
        {children}
      </div>
    </div>
  )
}

export { 
  Skeleton, 
  HeadlineSkeleton,
  SubheadlineSkeleton,
  TextSkeleton,
  ProductCardSkeleton, 
  CategorySkeleton, 
  HeroSkeleton, 
  OfferCardSkeleton,
  ProductDetailSkeleton,
  CartItemSkeleton,
  SectionHeaderSkeleton,
  ContentWrapper
}
