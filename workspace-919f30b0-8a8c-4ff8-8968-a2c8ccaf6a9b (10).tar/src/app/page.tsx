'use client'

import { Suspense, useEffect, useCallback } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import MainLayout from '@/components/layout/MainLayout'
import Shop from '@/components/shop/Shop'
import ContentPage from '@/components/content/ContentPage'
import { useCartStore, useShopStore } from '@/store'
import { useAppRouter } from '@/hooks/useAppRouter'
import { useVisitorTracking } from '@/hooks/useVisitorTracking'

function HomeContent() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const { navigate } = useAppRouter()
  
  const { items: cartItems, addItem: addToCart } = useCartStore()
  const { fetchData } = useShopStore()
  
  // Track visitor session for analytics
  useVisitorTracking()
  
  // Fetch initial data
  useEffect(() => {
    fetchData()
  }, [fetchData])
  
  // Handle category click - navigate to category page
  const handleCategoryClick = useCallback((categoryName: string) => {
    navigate('category', { categoryName })
  }, [navigate])

  // Handle navigation
  const handleNavigate = useCallback(() => {
    navigate('shop')
  }, [navigate])
  
  // Handle content pages (about, terms, etc.)
  const page = searchParams.get('page')
  if (page && ['about', 'terms', 'refund', 'privacy'].includes(page)) {
    return (
      <MainLayout>
        <ContentPage type={page as 'about' | 'terms' | 'refund' | 'privacy'} setView={() => router.push('/')} />
      </MainLayout>
    )
  }

  return (
    <MainLayout>
      <Shop 
        setView={handleNavigate} 
        addToCart={addToCart} 
        onCategoryClick={handleCategoryClick}
      />
    </MainLayout>
  )
}

// Simple loading fallback - no skeleton, just transparent
function LoadingFallback() {
  return (
    <div className="flex flex-col min-h-screen relative pb-16 md:pb-0">
      {/* Header placeholder - will show immediately */}
      <header className="w-full bg-white border-b border-gray-200 shadow-[0_1px_4px_rgba(0,0,0,0.08)] flex items-center justify-between px-3 md:px-[2.5rem] h-[56px] md:h-[110px] sticky top-0 z-[200]" />
      <div className="flex-grow w-full" />
    </div>
  )
}

export default function Home() {
  return (
    <Suspense fallback={<LoadingFallback />}>
      <HomeContent />
    </Suspense>
  )
}
