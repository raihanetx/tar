import { drizzle } from 'drizzle-orm/neon-http'
import { neon } from '@neondatabase/serverless'
import { drizzle as drizzlePg } from 'drizzle-orm/postgres-js'
import postgres from 'postgres'
import * as schema from './schema'

// ============================================
// SECURITY: No hardcoded credentials!
// DATABASE_URL must be configured in environment
// ============================================

/**
 * Get database URL - MUST be configured in environment
 * Throws clear error if not configured
 */
function getDatabaseUrl(): string {
  const dbUrl = process.env.DATABASE_URL
  
  if (!dbUrl) {
    throw new Error(
      '❌ DATABASE_URL not configured!\n' +
      'Please set DATABASE_URL in your .env file.\n' +
      '\n' +
      'For PostgreSQL (production):\n' +
      '  DATABASE_URL=postgresql://user:password@host:5432/database\n' +
      '\n' +
      'For local PostgreSQL:\n' +
      '  DATABASE_URL=postgres://user:password@localhost:5432/database\n' +
      '\n' +
      'For Neon (serverless):\n' +
      '  DATABASE_URL=postgresql://user:password@host.neon.tech/database?sslmode=require'
    )
  }
  
  // Validate URL format
  if (!dbUrl.startsWith('postgresql://') && 
      !dbUrl.startsWith('postgres://') &&
      !dbUrl.startsWith('file:')) {
    throw new Error(
      `❌ Invalid DATABASE_URL format!\n` +
      'Must start with postgresql://, postgres://, or file:'
    )
  }
  
  return dbUrl
}

// ============================================
// Create database connection
// ============================================

const DATABASE_URL = getDatabaseUrl()

// Determine if this is a Neon connection (has neon.tech in URL)
const isNeonConnection = DATABASE_URL.includes('neon.tech') || 
                         DATABASE_URL.includes('-pooler.')

let dbInstance: ReturnType<typeof drizzle> | ReturnType<typeof drizzlePg> | null = null

if (DATABASE_URL.startsWith('file:')) {
  // SQLite file - need better-sqlite3, show warning
  console.warn(
    '⚠️ SQLite file detected but better-sqlite3 is not installed.\n' +
    'Please use PostgreSQL for production or install better-sqlite3.\n' +
    'Falling back to in-memory connection attempt...'
  )
}

// Create the appropriate connection
if (isNeonConnection) {
  // Use Neon serverless driver (optimized for Neon databases)
  const sql = neon(DATABASE_URL, {
    fetchConnectionCache: true,
  })
  dbInstance = drizzle(sql, { schema })
} else {
  // Use standard postgres driver (for local/other PostgreSQL)
  const client = postgres(DATABASE_URL, {
    max: 10,
    idle_timeout: 20,
    connect_timeout: 10,
  })
  dbInstance = drizzlePg(client, { schema })
}

export const db = dbInstance

// ============================================
// Global caches that persist across requests
// ============================================

declare global {
  var __settingsCache: { data: any; timestamp: number } | undefined
  var __shopDataCache: { data: any; timestamp: number } | undefined
  var __dashboardCache: { data: any; timestamp: number; timeFrame: string } | undefined
  var __courierCredentials: { data: any; timestamp: number } | undefined
}

// Cache getters/setters
export function getCachedSettings() {
  return globalThis.__settingsCache || null
}

export function setCachedSettings(data: any) {
  globalThis.__settingsCache = { data, timestamp: Date.now() }
}

export function getCachedShopData() {
  return globalThis.__shopDataCache || null
}

export function setCachedShopData(data: any) {
  globalThis.__shopDataCache = { data, timestamp: Date.now() }
}

export function getCachedDashboard(timeFrame: string) {
  const cache = globalThis.__dashboardCache
  if (cache && cache.timeFrame === timeFrame) {
    return cache
  }
  return null
}

export function setCachedDashboard(data: any, timeFrame: string) {
  globalThis.__dashboardCache = { data, timestamp: Date.now(), timeFrame }
}

export function getCachedCourierCredentials() {
  return globalThis.__courierCredentials || null
}

export function setCachedCourierCredentials(data: any) {
  globalThis.__courierCredentials = { data, timestamp: Date.now() }
}

// Clear all caches (useful for testing or forced refresh)
export function clearAllCaches() {
  globalThis.__settingsCache = undefined
  globalThis.__shopDataCache = undefined
  globalThis.__dashboardCache = undefined
  globalThis.__courierCredentials = undefined
}

// Re-export schema
export * from './schema'
export type Database = typeof db
