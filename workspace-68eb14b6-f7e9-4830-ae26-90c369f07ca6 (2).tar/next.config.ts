import type { NextConfig } from "next";
import { config } from 'dotenv';
import { resolve } from 'path';

// Force load .env file and override system environment
config({ path: resolve(__dirname, '.env'), override: true });

const nextConfig: NextConfig = {
  output: "standalone",
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
  allowedDevOrigins: [
    '.space.z.ai',
    '.z.ai',
  ],
  turbopack: {
    root: __dirname,
  },
  env: {
    DATABASE_URL: process.env.DATABASE_URL,
  },
};

export default nextConfig;
