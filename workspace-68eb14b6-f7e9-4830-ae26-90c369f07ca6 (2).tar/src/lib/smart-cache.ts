// Smart Cache - Simple but effective caching strategies

// In-memory cache for fast access (cleared on page refresh)
const memoryCache = new Map<string, { data: any; timestamp: number }>()

// Cache durations
export const CACHE_DURATIONS = {
  SHOP_DATA: 30 * 1000,      // 30 seconds - products, categories
  SETTINGS: 5 * 60 * 1000,   // 5 minutes - settings rarely change
  PRODUCT: 60 * 1000,        // 1 minute - product details
}

// Get from memory cache
export function getMemoryCache<T>(key: string): T | null {
  const cached = memoryCache.get(key)
  if (!cached) return null
  return cached.data as T
}

// Set memory cache
export function setMemoryCache<T>(key: string, data: T): void {
  memoryCache.set(key, { data, timestamp: Date.now() })
}

// Get from localStorage (survives refresh) - for small data only!
export function getLocalCache<T>(key: string): T | null {
  if (typeof window === 'undefined') return null
  
  try {
    const raw = localStorage.getItem(`cache_${key}`)
    if (!raw) return null
    
    const cached = JSON.parse(raw)
    
    // Check if expired
    if (cached.expiry && Date.now() > cached.expiry) {
      localStorage.removeItem(`cache_${key}`)
      return null
    }
    
    return cached.data as T
  } catch {
    return null
  }
}

// Set localStorage cache with expiry
export function setLocalCache<T>(key: string, data: T, maxAgeMs: number = CACHE_DURATIONS.SETTINGS): void {
  if (typeof window === 'undefined') return
  
  try {
    localStorage.setItem(`cache_${key}`, JSON.stringify({
      data,
      expiry: Date.now() + maxAgeMs,
    }))
  } catch {
    // localStorage might be full
  }
}

// Check if cache is fresh
export function isCacheFresh(timestamp: number, maxAgeMs: number): boolean {
  return Date.now() - timestamp < maxAgeMs
}

// Preload image for faster display
export function preloadImage(url: string): void {
  if (!url || url.startsWith('data:')) return
  
  const img = new Image()
  img.src = url
}

// Prefetch API endpoint - browser will cache the response
export function prefetchApi(endpoint: string): void {
  if (typeof window === 'undefined') return
  
  // Use native prefetch
  const link = document.createElement('link')
  link.rel = 'prefetch'
  link.href = endpoint
  document.head.appendChild(link)
  
  // Clean up after 5 seconds
  setTimeout(() => link.remove(), 5000)
}

// Batch prefetch multiple images
export function prefetchImages(urls: string[]): void {
  urls.forEach(url => preloadImage(url))
}
