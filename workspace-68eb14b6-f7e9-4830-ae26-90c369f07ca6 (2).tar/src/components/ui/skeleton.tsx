import { cn } from "@/lib/utils"

// Simple pulse-based skeleton - cleaner look
function Skeleton({ className, ...props }: React.ComponentProps<"div">) {
  return (
    <div
      data-slot="skeleton"
      className={cn("skeleton-pulse-subtle rounded-md", className)}
      {...props}
    />
  )
}

// Headline Skeleton - for section titles (matches text-lg md:text-2xl font-bold)
function HeadlineSkeleton({ 
  className, 
  width = '150px',
  height = '24px',
  centered = false
}: { 
  className?: string
  width?: string
  height?: string
  centered?: boolean
}) {
  return (
    <span 
      className={cn("skeleton-text-subtle", centered && "mx-auto block", className)}
      style={{ width, height }}
    />
  )
}

// Subheadline Skeleton - for section subtitles (matches text-xs md:text-sm)
function SubheadlineSkeleton({ 
  className,
  width = '200px',
  centered = false
}: { 
  className?: string
  width?: string
  centered?: boolean
}) {
  return (
    <span 
      className={cn("skeleton-text-subtle mt-1", centered && "mx-auto block", className)}
      style={{ width, height: '14px' }}
    />
  )
}

// Text Skeleton - for inline text
function TextSkeleton({ 
  className, 
  lines = 1,
  width 
}: { 
  className?: string
  lines?: number
  width?: string | number
}) {
  return (
    <div className={cn("space-y-2", className)}>
      {Array.from({ length: lines }).map((_, i) => (
        <span 
          key={i} 
          className="skeleton-text-subtle block"
          style={{ 
            width: width 
              ? (typeof width === 'number' ? `${width}px` : width)
              : (i === lines - 1 ? '60%' : '100%'),
            height: '14px'
          }}
        />
      ))}
    </div>
  )
}

// Product Card Skeleton - Clean realistic look
function ProductCardSkeleton() {
  return (
    <div className="bg-white p-3 border border-gray-200 rounded-xl w-full min-h-[230px] md:min-h-[260px] flex flex-col">
      {/* Image area - lighter placeholder */}
      <div className="flex-grow flex items-center justify-center py-2">
        <div className="w-full h-[130px] md:h-[150px] bg-gray-100 rounded-lg" />
      </div>
      
      {/* Content area */}
      <div className="flex flex-col mt-auto">
        {/* Product name placeholder */}
        <div className="h-3.5 bg-gray-100 rounded w-3/4 mb-2" />
        {/* Price row */}
        <div className="flex items-center gap-2 mb-2.5">
          <div className="h-3.5 bg-gray-100 rounded w-16" />
        </div>
        {/* Button placeholder */}
        <div className="h-9 md:h-10 bg-gray-100 rounded-md w-full" />
      </div>
    </div>
  )
}

// Category Skeleton - Clean realistic look
function CategorySkeleton() {
  return (
    <div className="flex-shrink-0 flex flex-col items-center">
      <div className="w-[60px] h-[60px] md:w-[85px] md:h-[85px] bg-gray-100 rounded-lg" />
      <div className="h-2.5 bg-gray-100 rounded mt-1.5 w-12" />
    </div>
  )
}

// Hero Slider Skeleton - Clean look
function HeroSkeleton() {
  return (
    <div className="h-full w-full rounded-2xl bg-gray-100 flex items-center justify-center">
      {/* Content placeholder inside hero */}
      <div className="text-center px-6">
        <div className="h-5 bg-gray-200 rounded w-32 mx-auto mb-3" />
        <div className="h-3 bg-gray-200 rounded w-48 mx-auto" />
      </div>
    </div>
  )
}

// Offer Card Skeleton - Clean realistic look
function OfferCardSkeleton() {
  return (
    <div className="bg-white rounded-lg flex relative border border-gray-200 overflow-hidden shrink-0 w-[250px] h-[100px]">
      {/* Left Side: Image placeholder */}
      <div className="w-1/2 h-full bg-gray-50 border-r border-gray-100 flex items-center justify-center p-1">
        <div className="w-full h-full bg-gray-100 rounded" />
      </div>
      {/* Right Side: Content */}
      <div className="w-1/2 p-2 flex flex-col justify-center gap-1.5">
        <div className="h-2 bg-gray-100 rounded w-10" />
        <div className="h-3.5 bg-gray-100 rounded w-4/5" />
        <div className="h-3 bg-gray-100 rounded w-14" />
      </div>
    </div>
  )
}

// Product Detail Skeleton
function ProductDetailSkeleton() {
  return (
    <div className="bg-white min-h-screen p-4 md:p-20">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-10">
        {/* Image Section */}
        <div className="flex flex-col">
          <div className="w-full h-[280px] md:h-[350px] bg-gray-100 rounded-2xl" />
          <div className="grid grid-cols-4 gap-2 mt-3">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="aspect-square bg-gray-100 rounded-lg" />
            ))}
          </div>
        </div>
        
        {/* Content Section */}
        <div className="flex flex-col">
          {/* Title */}
          <div className="h-7 bg-gray-100 rounded w-4/5 mb-4" />
          
          {/* Price Row */}
          <div className="flex items-center gap-3 mb-5">
            <div className="h-6 bg-gray-100 rounded w-24" />
            <div className="h-4 bg-gray-100 rounded w-16" />
          </div>
          
          {/* Description */}
          <div className="space-y-2 mb-6">
            <div className="h-3.5 bg-gray-100 rounded w-full" />
            <div className="h-3.5 bg-gray-100 rounded w-full" />
            <div className="h-3.5 bg-gray-100 rounded w-3/4" />
          </div>
          
          {/* Variants */}
          <div className="mb-4">
            <div className="h-3.5 bg-gray-100 rounded w-24 mb-2" />
            <div className="flex gap-2">
              <div className="h-10 w-20 bg-gray-100 rounded-lg" />
              <div className="h-10 w-20 bg-gray-100 rounded-lg" />
              <div className="h-10 w-20 bg-gray-100 rounded-lg" />
            </div>
          </div>
          
          {/* Buttons */}
          <div className="h-12 bg-gray-100 rounded-xl mt-4 w-full" />
          <div className="h-14 bg-gray-100 rounded-xl mt-3 w-full" />
        </div>
      </div>
    </div>
  )
}

// Cart Item Skeleton
function CartItemSkeleton() {
  return (
    <div className="bg-white border border-gray-200 rounded-xl p-3 flex items-center gap-3">
      <div className="w-16 h-16 bg-gray-100 rounded-lg" />
      <div className="flex-1 space-y-2">
        <div className="h-3.5 bg-gray-100 rounded w-4/5" />
        <div className="h-3 bg-gray-100 rounded w-1/2" />
      </div>
      <div className="h-8 w-20 bg-gray-100 rounded-lg" />
    </div>
  )
}

// Section Header Skeleton - Clean realistic look
function SectionHeaderSkeleton({ 
  titleWidth = '150px',
  subtitleWidth = '180px',
  className
}: { 
  titleWidth?: string
  subtitleWidth?: string
  className?: string
}) {
  return (
    <div className={cn("text-center mb-3 md:mb-4", className)}>
      <div className="h-5 bg-gray-100 rounded mx-auto mb-1" style={{ width: titleWidth }} />
      <div className="h-3.5 bg-gray-100 rounded mx-auto" style={{ width: subtitleWidth }} />
    </div>
  )
}

// Full Page Shop Skeleton - Simple Loading text
function ShopPageSkeleton() {
  return (
    <main className="flex-grow flex items-center justify-center min-h-[60vh]">
      <div className="text-center">
        <p className="text-gray-500 text-lg font-medium animate-pulse">Loading...</p>
      </div>
    </main>
  )
}

// Content Wrapper with Fade-in Animation
function ContentWrapper({ 
  children, 
  isLoading,
  skeleton,
  className
}: { 
  children: React.ReactNode
  isLoading: boolean
  skeleton: React.ReactNode
  className?: string
}) {
  return (
    <div className={cn("relative", className)}>
      {/* Skeleton - fades out when loading is done */}
      <div 
        className={cn(
          "transition-all duration-500 ease-out",
          isLoading ? "opacity-100" : "opacity-0 pointer-events-none absolute inset-0"
        )}
      >
        {skeleton}
      </div>
      
      {/* Content - fades in when loading is done */}
      <div 
        className={cn(
          "transition-all duration-500 ease-out",
          isLoading ? "opacity-0" : "opacity-100"
        )}
      >
        {children}
      </div>
    </div>
  )
}

export { 
  Skeleton, 
  HeadlineSkeleton,
  SubheadlineSkeleton,
  TextSkeleton,
  ProductCardSkeleton, 
  CategorySkeleton, 
  HeroSkeleton, 
  OfferCardSkeleton,
  ProductDetailSkeleton,
  CartItemSkeleton,
  SectionHeaderSkeleton,
  ContentWrapper,
  ShopPageSkeleton
}
