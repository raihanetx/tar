import 'dotenv/config'

console.log('===== INSTRUMENT =====')
console.log('DATABASE_URL:', process.env.DATABASE_URL ? 'SET (length: ' + process.env.DATABASE_URL.length + ')' : 'NOT SET')
console.log('======================')
