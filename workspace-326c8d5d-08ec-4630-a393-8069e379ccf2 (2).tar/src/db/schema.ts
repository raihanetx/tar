import { sqliteTable, text, integer, real } from 'drizzle-orm/sqlite-core'
import { sql } from 'drizzle-orm'

// ============================================
// CATEGORIES
// ============================================
export const categories = sqliteTable('categories', {
  id: text('id').primaryKey(),
  name: text('name').notNull(),
  type: text('type').default('icon'), // 'icon' or 'image'
  icon: text('icon'),
  image: text('image'),
  items: integer('items').default(0),
  status: text('status').default('Active'),
  createdAt: integer('created_at', { mode: 'timestamp' }).default(sql`(unixepoch())`),
})

// ============================================
// PRODUCTS
// ============================================
export const products = sqliteTable('products', {
  id: integer('id').primaryKey({ autoIncrement: true }),
  name: text('name').notNull(),
  category: text('category').notNull(),
  categoryId: text('category_id').references(() => categories.id),
  image: text('image').notNull(),
  price: real('price').notNull(),
  oldPrice: real('old_price'),
  discount: text('discount').default('0%'), // Legacy field - kept for backward compatibility
  discountType: text('discount_type').default('pct'), // 'pct' for percentage, 'fixed' for fixed amount
  discountValue: real('discount_value').default(0), // Numeric value: 10 for 10% or 50 for 50 TK
  offer: integer('offer', { mode: 'boolean' }).default(false),
  status: text('status').default('active'),
  shortDesc: text('short_desc'),
  longDesc: text('long_desc'),
  weight: text('weight'),
  createdAt: integer('created_at', { mode: 'timestamp' }).default(sql`(unixepoch())`),
  updatedAt: integer('updated_at', { mode: 'timestamp' }).default(sql`(unixepoch())`),
})

export const variants = sqliteTable('variants', {
  id: integer('id').primaryKey({ autoIncrement: true }),
  name: text('name').notNull(),
  stock: integer('stock').notNull(),
  initialStock: integer('initial_stock').notNull(),
  price: real('price').default(0),
  discount: text('discount').default('0%'), // Legacy field - kept for backward compatibility
  discountType: text('discount_type').default('pct'), // 'pct' for percentage, 'fixed' for fixed amount
  discountValue: real('discount_value').default(0), // Numeric value: 10 for 10% or 50 for 50 TK
  productId: integer('product_id').references(() => products.id).notNull(),
})

export const productImages = sqliteTable('product_images', {
  id: integer('id').primaryKey({ autoIncrement: true }),
  url: text('url').notNull(),
  sortOrder: integer('sort_order').default(0),
  productId: integer('product_id').references(() => products.id).notNull(),
})

export const productFaqs = sqliteTable('product_faqs', {
  id: integer('id').primaryKey({ autoIncrement: true }),
  question: text('question').notNull(),
  answer: text('answer').notNull(),
  sortOrder: integer('sort_order').default(0),
  productId: integer('product_id').references(() => products.id).notNull(),
})

export const relatedProducts = sqliteTable('related_products', {
  id: integer('id').primaryKey({ autoIncrement: true }),
  relatedProductId: integer('related_product_id').references(() => products.id).notNull(),
  sortOrder: integer('sort_order').default(0),
  productId: integer('product_id').references(() => products.id).notNull(),
})

// ============================================
// CUSTOMERS
// ============================================
export const customers = sqliteTable('customers', {
  id: integer('id').primaryKey({ autoIncrement: true }),
  name: text('name').notNull(),
  phone: text('phone').notNull().unique(),
  address: text('address'),
  email: text('email'),
  totalSpent: real('total_spent').default(0),
  totalOrders: integer('total_orders').default(0),
  createdAt: integer('created_at', { mode: 'timestamp' }).default(sql`(unixepoch())`),
})

// ============================================
// REVIEWS
// ============================================
export const reviews = sqliteTable('reviews', {
  id: integer('id').primaryKey({ autoIncrement: true }),
  initials: text('initials').notNull(),
  name: text('name').notNull(),
  rating: integer('rating').notNull(),
  text: text('text').notNull(),
  date: text('date').notNull(),
  productId: integer('product_id').references(() => products.id),
  customerId: integer('customer_id').references(() => customers.id),
})

// ============================================
// ORDERS
// ============================================
export const orders = sqliteTable('orders', {
  id: text('id').primaryKey(),
  customerId: integer('customer_id').references(() => customers.id),
  customerName: text('customer_name').notNull(),
  phone: text('phone').notNull(),
  address: text('address').notNull(),
  date: text('date').notNull(),
  time: text('time').notNull(),
  paymentMethod: text('payment_method').notNull(),
  status: text('status').default('pending'), // pending, approved, canceled
  courierStatus: text('courier_status'), // in_review, pending, delivered, partial_delivered, cancelled, hold, unknown
  // Steadfast Courier Integration Fields
  consignmentId: integer('consignment_id'), // Steadfast consignment ID
  trackingCode: text('tracking_code'), // Steadfast tracking code
  courierDeliveredAt: text('courier_delivered_at'), // When delivered
  // Order totals
  subtotal: real('subtotal').notNull(),
  delivery: real('delivery').notNull(),
  discount: real('discount').default(0),
  couponCodes: text('coupon_codes').default('[]'),
  couponAmount: real('coupon_amount').default(0),
  total: real('total').notNull(),
  canceledBy: text('canceled_by'),
  createdAt: integer('created_at', { mode: 'timestamp' }).default(sql`(unixepoch())`),
  updatedAt: integer('updated_at', { mode: 'timestamp' }).default(sql`(unixepoch())`),
})

export const orderItems = sqliteTable('order_items', {
  id: integer('id').primaryKey({ autoIncrement: true }),
  name: text('name').notNull(),
  variant: text('variant'),
  qty: integer('qty').notNull(),
  basePrice: real('base_price').notNull(),
  offerText: text('offer_text'),
  offerDiscount: real('offer_discount').default(0),
  couponCode: text('coupon_code'),
  couponDiscount: real('coupon_discount').default(0),
  orderId: text('order_id').references(() => orders.id, { onDelete: 'cascade' }).notNull(),
  productId: integer('product_id').references(() => products.id),
})

// ============================================
// COUPONS
// ============================================
export const coupons = sqliteTable('coupons', {
  id: text('id').primaryKey(),
  code: text('code').notNull().unique(),
  type: text('type').notNull(), // 'pct' or 'fixed'
  value: real('value').notNull(),
  scope: text('scope').notNull(), // 'all', 'products', 'categories'
  expiry: text('expiry'),
  selectedProducts: text('selected_products'), // JSON array of product IDs
  selectedCategories: text('selected_categories'), // JSON array of category IDs
  createdAt: integer('created_at', { mode: 'timestamp' }).default(sql`(unixepoch())`),
})

// ============================================
// ABANDONED CHECKOUTS
// ============================================
export const abandonedCheckouts = sqliteTable('abandoned_checkouts', {
  id: integer('id').primaryKey({ autoIncrement: true }),
  sessionId: text('session_id').notNull(),
  visitNumber: integer('visit_number').default(1),
  name: text('name'),
  phone: text('phone'),
  address: text('address'),
  items: text('items').notNull(), // JSON
  subtotal: real('subtotal').default(0),
  delivery: real('delivery').default(0),
  total: real('total').default(0),
  status: text('status').default('abandoned'), // 'abandoned' or 'completed'
  completedOrderId: text('completed_order_id'),
  visitTime: text('visit_time').notNull(),
  visitDate: text('visit_date').notNull(),
  createdAt: integer('created_at', { mode: 'timestamp' }).default(sql`(unixepoch())`),
})

// ============================================
// SETTINGS
// ============================================
export const settings = sqliteTable('settings', {
  id: integer('id').primaryKey().default(1),
  websiteName: text('website_name').default('EcoMart'),
  slogan: text('slogan'),
  logoUrl: text('logo_url'),
  faviconUrl: text('favicon_url'),
  heroImages: text('hero_images'), // JSON array of image URLs
  insideDhakaDelivery: real('inside_dhaka_delivery').default(60),
  outsideDhakaDelivery: real('outside_dhaka_delivery').default(120),
  freeDeliveryMin: real('free_delivery_min').default(500),
  universalDelivery: integer('universal_delivery', { mode: 'boolean' }).default(false),
  universalDeliveryCharge: real('universal_delivery_charge').default(60),
  whatsappNumber: text('whatsapp_number'),
  phoneNumber: text('phone_number'),
  facebookUrl: text('facebook_url'),
  messengerUsername: text('messenger_username'),
  aboutUs: text('about_us'),
  termsConditions: text('terms_conditions'),
  refundPolicy: text('refund_policy'),
  privacyPolicy: text('privacy_policy'),
  // Steadfast Courier Integration
  courierEnabled: integer('courier_enabled', { mode: 'boolean' }).default(false),
  courierApiKey: text('courier_api_key'),
  courierSecretKey: text('courier_secret_key'),
})

// ============================================
// ANALYTICS
// ============================================
export const productViews = sqliteTable('product_views', {
  id: integer('id').primaryKey({ autoIncrement: true }),
  productId: integer('product_id').references(() => products.id).notNull(),
  viewCount: integer('view_count').default(1),
  date: text('date').notNull(), // YYYY-MM-DD format for daily tracking
  createdAt: integer('created_at', { mode: 'timestamp' }).default(sql`(unixepoch())`),
})

export const cartEvents = sqliteTable('cart_events', {
  id: integer('id').primaryKey({ autoIncrement: true }),
  productId: integer('product_id').references(() => products.id).notNull(),
  action: text('action').notNull(), // 'add' or 'remove'
  date: text('date').notNull(), // YYYY-MM-DD format
  createdAt: integer('created_at', { mode: 'timestamp' }).default(sql`(unixepoch())`),
})

// ============================================
// ADMIN USERS (For Authentication)
// ============================================
export const adminUsers = sqliteTable('admin_users', {
  id: integer('id').primaryKey({ autoIncrement: true }),
  username: text('username').notNull().unique(),
  password: text('password').notNull(), // Hashed with bcrypt
  passwordDisplay: text('password_display'), // Encrypted for display
  name: text('name'),
  createdAt: integer('created_at', { mode: 'timestamp' }).default(sql`(unixepoch())`),
  updatedAt: integer('updated_at', { mode: 'timestamp' }).default(sql`(unixepoch())`),
})

// Type export for admin user
export type AdminUser = typeof adminUsers.$inferSelect

// ============================================
// API CREDENTIALS (Encrypted Storage)
// ============================================
export const apiCredentials = sqliteTable('api_credentials', {
  id: integer('id').primaryKey().default(1),
  // Steadfast Courier
  steadfastApiKey: text('steadfast_api_key'),
  steadfastSecretKey: text('steadfast_secret_key'), // Encrypted
  webhookUrl: text('webhook_url'),
  // Metadata
  createdAt: integer('created_at', { mode: 'timestamp' }).default(sql`(unixepoch())`),
  updatedAt: integer('updated_at', { mode: 'timestamp' }).default(sql`(unixepoch())`),
})

// Type export for API credentials
export type ApiCredentials = typeof apiCredentials.$inferSelect
