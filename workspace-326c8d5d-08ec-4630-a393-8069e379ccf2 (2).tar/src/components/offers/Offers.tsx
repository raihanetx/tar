'use client'

import { useState, useEffect } from 'react'
import { ViewType, Coupon } from '@/types'

interface OffersProps {
  setView: (v: ViewType) => void
}

interface OfferSettings {
  freeDeliveryMin: number
  insideDhakaDelivery: number
  outsideDhakaDelivery: number
  universalDelivery: boolean
  universalDeliveryCharge: number
}

export default function Offers({ setView }: OffersProps) {
  const [settings, setSettings] = useState<OfferSettings>({
    freeDeliveryMin: 500,
    insideDhakaDelivery: 60,
    outsideDhakaDelivery: 120,
    universalDelivery: false,
    universalDeliveryCharge: 60
  })
  const [coupons, setCoupons] = useState<Coupon[]>([])
  const [copiedCode, setCopiedCode] = useState<string | null>(null)

  useEffect(() => {
    window.scrollTo(0, 0)
  }, [])

  useEffect(() => {
    const fetchSettings = async () => {
      try {
        const response = await fetch('/api/settings')
        const data = await response.json()
        if (data.success && data.data) {
          setSettings({
            freeDeliveryMin: data.data.free_delivery_min || 500,
            insideDhakaDelivery: data.data.inside_dhaka_delivery || 60,
            outsideDhakaDelivery: data.data.outside_dhaka_delivery || 120,
            universalDelivery: data.data.universal_delivery || false,
            universalDeliveryCharge: data.data.universal_delivery_charge || 60
          })
        }
      } catch (error) {
        console.error('Error fetching settings:', error)
      }
    }
    fetchSettings()
  }, [])

  useEffect(() => {
    const fetchCoupons = async () => {
      try {
        const response = await fetch('/api/coupons?public=true')
        const data = await response.json()
        if (data.success && data.coupons) {
          setCoupons(data.coupons)
        }
      } catch (error) {
        console.error('Error fetching coupons:', error)
      }
    }
    fetchCoupons()
  }, [])

  const copyToClipboard = (code: string) => {
    navigator.clipboard.writeText(code)
    setCopiedCode(code)
    setTimeout(() => setCopiedCode(null), 2000)
  }

  const formatDate = (dateString: string) => {
    if (!dateString) return ''
    const date = new Date(dateString)
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
  }

  return (
    <div className="bg-gray-50 min-h-screen pb-20">
      {/* Header */}
      <div className="bg-white border-b border-gray-100 sticky top-0 z-10">
        <div className="max-w-lg mx-auto px-4 py-4">
          <h1 className="text-lg font-bold text-center text-gray-900">Offers</h1>
        </div>
      </div>

      <div className="max-w-lg mx-auto px-4 py-4 space-y-4">
        {/* Free Delivery Offer */}
        <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
          <div className="p-4">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                <i className="ri-truck-line text-green-600 text-lg"></i>
              </div>
              <div>
                <h2 className="font-semibold text-gray-900">Free Delivery</h2>
                <p className="text-xs text-gray-500">On orders above TK {settings.freeDeliveryMin}</p>
              </div>
            </div>
          </div>
          <div className="bg-gray-50 px-4 py-3 border-t border-gray-100">
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-500">Inside Dhaka</span>
              <span className="font-medium text-gray-900">TK {settings.insideDhakaDelivery}</span>
            </div>
            {!settings.universalDelivery && (
              <div className="flex items-center justify-between text-sm mt-2">
                <span className="text-gray-500">Outside Dhaka</span>
                <span className="font-medium text-gray-900">TK {settings.outsideDhakaDelivery}</span>
              </div>
            )}
          </div>
        </div>

        {/* Coupon Codes */}
        {coupons.length > 0 && (
          <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
            <div className="p-4 border-b border-gray-100">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-orange-100 rounded-full flex items-center justify-center">
                  <i className="ri-coupon-3-line text-orange-600 text-lg"></i>
                </div>
                <div>
                  <h2 className="font-semibold text-gray-900">Coupon Codes</h2>
                  <p className="text-xs text-gray-500">Copy & use at checkout</p>
                </div>
              </div>
            </div>
            <div className="divide-y divide-gray-100">
              {coupons.map((coupon) => (
                <div key={coupon.id} className="p-4">
                  <div className="flex items-center justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-gray-900 truncate">{coupon.code}</span>
                        <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-green-100 text-green-700">
                          {coupon.type === 'pct' ? `${coupon.value}% OFF` : `TK ${coupon.value}`}
                        </span>
                      </div>
                      <div className="flex items-center gap-2 mt-1 text-xs text-gray-500">
                        <span>
                          {coupon.scope === 'all' && 'All products'}
                          {coupon.scope === 'products' && 'Selected products'}
                          {coupon.scope === 'categories' && 'Selected categories'}
                        </span>
                        {coupon.expiry && (
                          <>
                            <span>•</span>
                            <span>Until {formatDate(coupon.expiry)}</span>
                          </>
                        )}
                      </div>
                    </div>
                    <button
                      onClick={() => copyToClipboard(coupon.code)}
                      className={`shrink-0 px-4 py-2 rounded-md text-sm font-medium transition-all ${
                        copiedCode === coupon.code
                          ? 'bg-green-600 text-white'
                          : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                      }`}
                    >
                      {copiedCode === coupon.code ? 'Copied!' : 'Copy'}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* No Coupons */}
        {coupons.length === 0 && (
          <div className="bg-white rounded-lg border border-gray-200 p-6 text-center">
            <div className="w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-3">
              <i className="ri-coupon-line text-gray-400 text-xl"></i>
            </div>
            <p className="text-gray-500 text-sm">No active coupons available</p>
            <p className="text-gray-400 text-xs mt-1">Check back later for new offers</p>
          </div>
        )}

        {/* Shop Now Button */}
        <button
          onClick={() => setView('shop')}
          className="w-full bg-[#16a34a] text-white py-3.5 rounded-lg font-semibold hover:bg-[#15803d] transition-colors mt-4"
        >
          Shop Now
        </button>
      </div>
    </div>
  )
}
