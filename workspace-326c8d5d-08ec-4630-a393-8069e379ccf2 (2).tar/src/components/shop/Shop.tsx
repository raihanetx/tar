'use client'

import { useState, useEffect } from 'react'
import { CartItem, ViewType } from '@/types'
import { useShopStore } from '@/store/useShopStore'

interface ShopProps {
  setView: (v: ViewType) => void
  addToCart: (item: CartItem) => void
}

export default function Shop({ setView, addToCart }: ShopProps) {
  const [currentHero, setCurrentHero] = useState(0)
  const { categories, products, settings, isLoading, fetchData, setSelectedProduct, searchQuery, selectedCategory, setSelectedCategory } = useShopStore()
  
  // Use heroImages from settings (loaded from database)
  const heroImages = settings.heroImages

  useEffect(() => {
    fetchData()
  }, [fetchData])

  // Filter products based on search query and selected category
  const filteredProducts = products.filter(p => {
    if (p.status !== 'active') return false
    if (searchQuery.trim() && !p.name.toLowerCase().includes(searchQuery.toLowerCase())) return false
    if (selectedCategory && p.category !== selectedCategory) return false
    return true
  })

  // Group products by category
  const productsByCategory = categories
    .filter(c => c.status === 'Active')
    .map(cat => ({
      ...cat,
      products: filteredProducts.filter(p => p.category === cat.name)
    }))
    .filter(cat => cat.products.length > 0)

  // Handle category click
  const handleCategoryClick = (categoryName: string) => {
    if (selectedCategory === categoryName) {
      setSelectedCategory(null) // Toggle off if same category
    } else {
      setSelectedCategory(categoryName)
    }
  }

  // Handle product click - set selected product and navigate
  const handleProductClick = async (productId: number) => {
    await setSelectedProduct(productId)
    setView('product')
  }
  // Carousel interval
  useEffect(() => {
    if (heroImages.length === 0) return
    const interval = setInterval(() => {
      setCurrentHero((prev) => (prev + 1) % heroImages.length)
    }, 4000)
    return () => clearInterval(interval)
  }, [heroImages.length])

  // Filter products with offers for the offer cards section
  const offerProducts = products.filter(p => p.offer).slice(0, 3)

  return (
    <main className="flex-grow">
      {/* Hero Carousel */}
      <section className="w-full pb-4 md:pb-6">
        <div className="mx-3 mt-3 md:mx-6 md:mt-6 relative h-[180px] md:h-[300px] rounded-2xl overflow-hidden shadow-lg group">
          {heroImages.map((img, i) => (
            <div
              key={i}
              className={`absolute inset-0 bg-cover bg-center transition-opacity duration-700 ${i === currentHero ? 'opacity-100' : 'opacity-0'}`}
              style={{backgroundImage: `url('${img}')`}}
            ></div>
          ))}
          <div className="absolute inset-0 bg-gradient-to-r from-black/50 to-transparent"></div>
          {/* Carousel Indicators */}
          <div className="absolute bottom-3 left-1/2 transform -translate-x-1/2 flex gap-2">
            {heroImages.map((_, i) => (
              <button
                key={i}
                onClick={() => setCurrentHero(i)}
                className={`w-2 h-2 rounded-full transition-all ${i === currentHero ? 'bg-white w-4' : 'bg-white/50'}`}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="py-4 md:py-8">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center mb-4 md:mb-6">
            <h2 className="text-lg md:text-2xl font-bold text-gray-900 font-bangla">ক্যাটাগরি</h2>
            <p className="text-gray-500 mt-1 text-xs md:text-sm font-bangla">আপনার প্রয়োজনীয় সবকিছু এখানেই পাবেন</p>
          </div>
          
          {isLoading ? (
            <div className="flex justify-center">
              <div className="flex gap-3 md:gap-4 overflow-x-auto pb-2">
                {[1, 2, 3, 4, 5].map((i) => (
                  <div key={i} className="flex-shrink-0 flex flex-col items-center animate-pulse">
                    <div className="w-[60px] h-[60px] md:w-[85px] md:h-[85px] rounded-xl bg-gray-200"></div>
                    <div className="w-12 h-3 bg-gray-200 rounded mt-1.5"></div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="flex justify-center">
              <div className="flex gap-3 md:gap-4 overflow-x-auto md:flex-wrap md:justify-center pb-2 md:pb-0 -mx-4 px-4 md:mx-0 md:px-0 no-scrollbar">
                {categories.filter(c => c.status === 'Active').map((cat) => (
                  <div 
                    key={cat.id} 
                    className={`flex-shrink-0 flex flex-col items-center group cursor-pointer ${selectedCategory === cat.name ? 'ring-2 ring-[#16a34a] rounded-xl' : ''}`}
                    onClick={() => handleCategoryClick(cat.name)}
                  >
                    <div className={`w-[60px] h-[60px] md:w-[85px] md:h-[85px] rounded-xl border flex items-center justify-center text-gray-700 transition-colors duration-300 mb-1.5 overflow-hidden ${selectedCategory === cat.name ? 'border-[#16a34a] bg-[#f0fdf4] text-[#16a34a]' : 'border-gray-200 bg-white group-hover:text-[#16a34a] group-hover:border-[#16a34a]'}`}>
                      {cat.type === 'icon' && cat.icon ? (
                        <i className={`${cat.icon} text-2xl md:text-3xl`}></i>
                      ) : cat.type === 'image' && cat.image ? (
                        <img src={cat.image} alt={cat.name} className="w-full h-full object-cover" />
                      ) : (
                        <i className="ri-folder-line text-2xl md:text-3xl"></i>
                      )}
                    </div>
                    <span className="text-[11px] md:text-xs font-medium text-gray-700">{cat.name}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </section>

      {/* OFFER CARDS SECTION - Only show if there are offer products */}
      {offerProducts.length > 0 && (
        <section id="offers" className="py-4 md:py-6">
          <div className="container mx-auto px-4 md:px-6">
            <div className="mb-4 text-center">
              <h2 className="text-lg md:text-2xl font-bold text-gray-900">Offer Cards</h2>
              <p className="text-gray-500 mt-0.5 text-xs md:text-sm">Exclusive deals just for you</p>
            </div>
            <div className="flex gap-3 md:gap-4 overflow-x-auto no-scrollbar pb-2 -mx-4 px-4 md:mx-0 md:px-0">
              {offerProducts.map((product) => {
                // Format discount text with OFF in capital letters
                const discountValue = product.discountValue ?? 0
                const discountType = product.discountType ?? 'pct'
                const discountText = discountValue > 0
                  ? (discountType === 'pct' ? `${discountValue}% OFF` : `TK ${discountValue} OFF`)
                  : product.discount
                
                // Calculate original price for display (same logic as normal product cards)
                let originalPrice = product.oldPrice
                if (!originalPrice || originalPrice <= product.price) {
                  if (discountValue > 0) {
                    if (discountType === 'pct') {
                      originalPrice = Math.round(product.price * 100 / (100 - discountValue))
                    } else {
                      originalPrice = product.price + discountValue
                    }
                  }
                }
                
                return (
                  <div 
                    key={product.id} 
                    className="bg-white rounded-xl flex items-center overflow-hidden border border-gray-200 transition-all shrink-0 w-[220px] md:w-[280px] h-[90px] md:h-[110px] cursor-pointer hover:border-[#16a34a]" 
                    onClick={() => handleProductClick(product.id)}
                  >
                    <div className="w-[90px] md:w-[110px] h-full flex justify-center items-center p-2 md:p-3">
                      <img src={product.image} alt={product.name} className="max-w-full max-h-full object-contain" />
                    </div>
                    <div className="w-[1px] h-[65%] bg-gray-200"></div>
                    <div className="flex-1 py-2 px-3 flex flex-col justify-center">
                      <div className="text-[10px] md:text-xs text-[#ff4757] font-bold mb-0.5 md:mb-1">{discountText}</div>
                      <h2 className="text-[12px] md:text-sm font-semibold text-gray-800 mb-0.5 md:mb-1 truncate">{product.name}</h2>
                      <div className="flex items-center gap-2">
                        <span className="text-[13px] md:text-sm font-bold text-[#16a34a]">TK {product.price}</span>
                        {originalPrice && originalPrice > product.price && (
                          <span className="text-[9px] md:text-[10px] line-through text-gray-400">TK {originalPrice}</span>
                        )}
                      </div>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        </section>
      )}

      {/* Product Grid - Category Wise */}
      <section className="pb-12 pt-4">
        <div className="container mx-auto px-4 md:px-6">
          {isLoading ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3 md:gap-5">
              {[1, 2, 3, 4, 5, 6, 7, 8].map((i) => (
                <div key={i} className="bg-white p-3 border border-gray-200 rounded-xl animate-pulse">
                  <div className="h-[130px] md:h-[150px] bg-gray-200 rounded-lg mb-2"></div>
                  <div className="h-4 bg-gray-200 rounded mb-2"></div>
                  <div className="h-3 bg-gray-200 rounded w-1/2 mb-2"></div>
                  <div className="h-8 bg-gray-200 rounded-full"></div>
                </div>
              ))}
            </div>
          ) : filteredProducts.length > 0 ? (
            // Show products grouped by category
            productsByCategory.map((category) => (
              <div key={category.id} className="mb-8 md:mb-12">
                {/* Category Name - Center Aligned with dashes */}
                <div className="text-center mb-5 md:mb-6">
                  <h2 className="text-base md:text-lg font-normal text-gray-400">— {category.name} —</h2>
                </div>
                
                {/* Product Cards - Left Aligned Grid */}
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3 md:gap-5 justify-items-start">
                  {category.products.map((item) => {
                    // Calculate discount percentage from discountValue
                    const discountValue = item.discountValue ?? 0
                    const discountType = item.discountType ?? 'pct'
                    
                    // Calculate original price for display
                    let originalPrice = item.oldPrice
                    if (!originalPrice || originalPrice <= item.price) {
                      if (discountValue > 0) {
                        if (discountType === 'pct') {
                          originalPrice = Math.round(item.price * 100 / (100 - discountValue))
                        } else {
                          originalPrice = item.price + discountValue
                        }
                      }
                    }
                    
                    const hasDiscount = discountValue > 0 || (originalPrice && originalPrice > item.price)
                    
                    return (
                      <div 
                        key={item.id} 
                        onClick={() => handleProductClick(item.id)} 
                        className="bg-white p-3 relative cursor-pointer transition-all duration-300 flex flex-col w-full min-h-[230px] md:min-h-[260px] border border-gray-200 rounded-xl hover:border-[#16a34a]"
                      >
                        {hasDiscount && (
                          <span className="absolute top-2 left-2 bg-red-500 text-white text-[9px] md:text-[10px] font-bold px-2 py-0.5 rounded z-10">
                            -{discountValue > 0 
                              ? (discountType === 'pct' ? `${discountValue}%` : `TK ${discountValue}`)
                              : item.discount}
                          </span>
                        )}
                        <div className="flex-grow flex items-center justify-center py-2">
                          <div className="w-full h-[130px] md:h-[150px] flex items-center justify-center">
                            <img src={item.image} alt={item.name} className="w-full h-full object-contain" loading="lazy"/>
                          </div>
                        </div>
                        <div className="flex flex-col mt-auto">
                          <h3 className="text-sm font-medium text-gray-800 truncate font-bangla">{item.name}</h3>
                          <div className="flex items-center gap-2 mb-2 mt-1">
                            <span className="text-sm font-semibold text-[#16a34a]">TK {item.price}</span>
                            {originalPrice && originalPrice > item.price && (
                              <span className="text-xs text-gray-400 line-through">TK {originalPrice}</span>
                            )}
                          </div>
                          <button 
                            className="w-full text-xs font-semibold py-2 flex items-center justify-center gap-1 bg-[#16a34a] text-white rounded-lg border-none cursor-pointer transition-transform duration-200 active:scale-95" 
                            onClick={(e) => { 
                              e.stopPropagation(); 
                              addToCart({
                                id: item.id,
                                name: item.name,
                                price: item.price,
                                oldPrice: originalPrice || item.price,
                                img: item.image,
                                weight: '1 KG',
                                category: item.category,
                                categoryId: item.categoryId,
                                offer: item.offer,
                                discountType: item.discountType as 'pct' | 'fixed' | undefined,
                                discountValue: item.discountValue,
                              });
                            }}
                          >
                            <i className="ri-shopping-cart-line text-sm"></i>
                            Add to Cart
                          </button>
                        </div>
                      </div>
                    )
                  })}
                </div>
              </div>
            ))
          ) : (
            <div className="text-center py-12">
              <p className="text-gray-500">
                {searchQuery && selectedCategory 
                  ? `No products found for "${searchQuery}" in ${selectedCategory}` 
                  : searchQuery 
                    ? `No products found for "${searchQuery}"` 
                    : selectedCategory 
                      ? `No products in ${selectedCategory} category` 
                      : 'No products available'}
              </p>
              {selectedCategory && (
                <button 
                  onClick={() => setSelectedCategory(null)}
                  className="mt-3 text-[#16a34a] text-sm font-medium hover:underline"
                >
                  Clear category filter
                </button>
              )}
            </div>
          )}
        </div>
      </section>
    </main>
  )
}
