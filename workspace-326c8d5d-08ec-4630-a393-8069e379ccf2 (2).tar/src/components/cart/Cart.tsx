'use client'

import { CartItem, ViewType } from '@/types'

interface CartProps {
  setView: (v: ViewType) => void
  cartItems: CartItem[]
  setCartItems: (items: CartItem[]) => void
  onUpdateQuantity?: (id: number, quantity: number) => void
  onRemoveItem?: (id: number) => void
  freeDeliveryMin?: number
}

export default function Cart({ setView, cartItems, setCartItems, onUpdateQuantity, onRemoveItem, freeDeliveryMin = 500 }: CartProps) {
  // Handle quantity change
  const handleQuantityChange = (index: number, newQuantity: number) => {
    if (newQuantity < 1) return
    
    if (onUpdateQuantity) {
      onUpdateQuantity(cartItems[index].id, newQuantity)
    } else {
      const newItems = [...cartItems]
      newItems[index] = { ...newItems[index], quantity: newQuantity }
      setCartItems(newItems)
    }
  }

  // Handle remove item
  const handleRemoveItem = (index: number) => {
    const item = cartItems[index]
    if (onRemoveItem) {
      onRemoveItem(item.id)
    } else {
      const newItems = [...cartItems]
      newItems.splice(index, 1)
      setCartItems(newItems)
    }
  }

  if (cartItems.length === 0) {
    return (
      <div className="cart-clean-wrapper">
        <div className="cart-clean-empty">
          <i className="ri-shopping-cart-2-line"></i>
          <h2>Your cart is empty</h2>
          <p>Add some products to get started</p>
          <button onClick={() => setView('shop')}>Shop Now</button>
        </div>
      </div>
    )
  }

  // Calculate subtotal using quantity
  const subtotal = cartItems.reduce((acc, item) => acc + (item.price * (item.quantity || 1)), 0)
  const totalItems = cartItems.reduce((acc, item) => acc + (item.quantity || 1), 0)
  const remainingForFreeDelivery = freeDeliveryMin - subtotal

  return (
    <div className="cart-clean-wrapper">
      <div className="cart-clean-container">
        
        {/* ITEM LIST */}
        <div className="cart-clean-list">
          {cartItems.map((item, index) => (
            <div key={index} className="cart-clean-item">
              <img src={item.img} className="cart-clean-img" alt={item.name} />
              <div className="cart-clean-info">
                <div className="cart-clean-name-row">
                  <span className="cart-clean-name">{item.name}</span> 
                  <span className="cart-clean-weight">({item.weight})</span>
                </div>
                <div className="cart-clean-action-row">
                  <div className="cart-clean-price">TK {item.price * (item.quantity || 1)}</div>
                  <div className="cart-clean-qty-group">
                    <button 
                      className="cart-clean-qbtn" 
                      onClick={() => handleQuantityChange(index, (item.quantity || 1) - 1)}
                    >
                      <i className="ri-subtract-line"></i>
                    </button>
                    <span className="cart-clean-qval">{item.quantity || 1}</span>
                    <button 
                      className="cart-clean-qbtn" 
                      onClick={() => handleQuantityChange(index, (item.quantity || 1) + 1)}
                    >
                      <i className="ri-add-line"></i>
                    </button>
                  </div>
                </div>
              </div>
              <button className="cart-clean-del" onClick={() => handleRemoveItem(index)}>
                <i className="ri-delete-bin-line"></i>
              </button>
            </div>
          ))}
        </div>

        {/* SUMMARY */}
        <div className="cart-clean-summary">
          <div className="cart-clean-os-row">
            <span>Subtotal ({totalItems} items)</span>
            <span>TK {subtotal.toFixed(2)}</span>
          </div>
          <div className="cart-clean-os-row">
            <span>Shipping</span>
            <span className="cart-clean-shipping-text">Calculated at checkout</span>
          </div>
          <div className="cart-clean-os-row cart-clean-total">
            <span>Total</span>
            <span>TK {subtotal.toFixed(2)}</span>
          </div>
        </div>

        {/* BUTTONS */}
        <div className="cart-clean-buttons">
          <button className="cart-clean-btn cart-clean-btn-continue" onClick={() => setView('shop')}>
            Continue
          </button>
          <button className="cart-clean-btn cart-clean-btn-checkout" onClick={() => setView('checkout')}>
            Checkout
          </button>
        </div>

        {/* PROMO BANNER - Free Delivery */}
        <div className="cart-clean-promo">
          <div className="cart-clean-promo-icon">
            <i className="ri-truck-line"></i>
          </div>
          <div className="cart-clean-promo-text">
            {remainingForFreeDelivery > 0 ? (
              <>
                Add <strong>TK {remainingForFreeDelivery}</strong> more to get <strong>FREE delivery!</strong>
              </>
            ) : (
              <>
                🎉 You qualify for <strong>FREE delivery!</strong>
              </>
            )}
          </div>
        </div>

      </div>
    </div>
  )
}
