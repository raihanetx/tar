'use client'

import React, { useState } from 'react'
import { useSession, signOut } from 'next-auth/react'
import { useAdmin } from '@/components/admin/context/AdminContext'

const CredentialsView: React.FC = () => {
  const { credentials, setCredentials, showToastMsg } = useAdmin()
  const { data: session } = useSession()
  const [isLoading, setIsLoading] = useState(false)
  const [apiLoading, setApiLoading] = useState(false)
  const [steadfastKeyChanged, setSteadfastKeyChanged] = useState(false)
  
  // Show credentials states
  const [showCurrentCredentials, setShowCurrentCredentials] = useState(false)
  const [currentCredentials, setCurrentCredentials] = useState<{ username: string; password: string } | null>(null)
  const [loadingCredentials, setLoadingCredentials] = useState(false)
  const [showSteadfastCredentials, setShowSteadfastCredentials] = useState(false)
  const [steadfastCredentials, setSteadfastCredentials] = useState<{ apiKey: string; secretKey: string; webhookUrl: string } | null>(null)
  const [loadingSteadfast, setLoadingSteadfast] = useState(false)

  const handleShowCurrentCredentials = async () => {
    if (showCurrentCredentials) {
      setShowCurrentCredentials(false)
      return
    }
    
    setLoadingCredentials(true)
    try {
      const response = await fetch('/api/admin-users/current')
      const result = await response.json()
      
      if (result.success) {
        setCurrentCredentials({
          username: result.data.username,
          password: result.data.password
        })
        setShowCurrentCredentials(true)
      } else {
        showToastMsg(result.error || 'Failed to fetch credentials')
      }
    } catch (error) {
      console.error('Error fetching current credentials:', error)
      showToastMsg('Failed to fetch credentials')
    } finally {
      setLoadingCredentials(false)
    }
  }

  const handleShowSteadfastCredentials = async () => {
    if (showSteadfastCredentials) {
      setShowSteadfastCredentials(false)
      return
    }
    
    setLoadingSteadfast(true)
    try {
      const response = await fetch('/api/credentials?reveal=true')
      const result = await response.json()
      
      if (!result.error) {
        setSteadfastCredentials({
          apiKey: result.steadfastApiKey || '',
          secretKey: result.steadfastSecretKey || '',
          webhookUrl: result.webhookUrl || ''
        })
        setShowSteadfastCredentials(true)
      } else {
        showToastMsg(result.error || 'Failed to fetch credentials')
      }
    } catch (error) {
      console.error('Error fetching steadfast credentials:', error)
      showToastMsg('Failed to fetch credentials')
    } finally {
      setLoadingSteadfast(false)
    }
  }

  const handleSaveAccount = async (e: React.FormEvent) => {
    e.preventDefault()
    
    const isChangingUsername = credentials.username && credentials.username !== session?.user?.username
    const isChangingPassword = credentials.newPassword || credentials.currentPassword
    
    if (isChangingPassword) {
      if (!credentials.currentPassword) {
        showToastMsg('Please enter your current password!')
        return
      }
      
      if (!credentials.newPassword) {
        showToastMsg('Please enter a new password!')
        return
      }
      
      if (credentials.newPassword !== credentials.confirmPassword) {
        showToastMsg('New passwords do not match!')
        return
      }
      
      if (credentials.newPassword.length < 6) {
        showToastMsg('New password must be at least 6 characters!')
        return
      }
    }
    
    if (!isChangingUsername && !isChangingPassword) {
      showToastMsg('No changes to save!')
      return
    }

    setIsLoading(true)

    try {
      const response = await fetch('/api/admin-users', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          currentUsername: session?.user?.username || 'admin',
          newUsername: isChangingUsername ? credentials.username : undefined,
          currentPassword: credentials.currentPassword || undefined,
          newPassword: credentials.newPassword || undefined
        })
      })

      const result = await response.json()

      if (result.success) {
        if (isChangingPassword) {
          showToastMsg('Credentials updated! Logging out...')
          setTimeout(() => {
            signOut({ redirect: false })
          }, 1500)
        } else {
          showToastMsg('Username updated successfully!')
          setCredentials({
            ...credentials,
            currentPassword: '',
            newPassword: '',
            confirmPassword: ''
          })
          setShowCurrentCredentials(false)
          setCurrentCredentials(null)
          setIsLoading(false)
        }
      } else {
        showToastMsg(result.error || 'Failed to update!')
        setIsLoading(false)
      }
    } catch (error) {
      console.error('Error updating credentials:', error)
      showToastMsg('Failed to update!')
      setIsLoading(false)
    }
  }

  const handleSaveSteadfast = async (e: React.FormEvent) => {
    e.preventDefault()
    setApiLoading(true)

    try {
      const response = await fetch('/api/credentials', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          steadfastApiKey: credentials.steadfastApiKey,
          steadfastSecretKey: steadfastKeyChanged ? credentials.steadfastSecretKey : '****',
          webhookUrl: credentials.webhookUrl
        })
      })

      const result = await response.json()

      if (result.success) {
        showToastMsg('Steadfast credentials saved!')
        setSteadfastKeyChanged(false)
        setShowSteadfastCredentials(false)
        setSteadfastCredentials(null)
        fetchCredentials()
      } else {
        showToastMsg(result.error || 'Failed to save!')
      }
    } catch (error) {
      console.error('Error saving Steadfast credentials:', error)
      showToastMsg('Failed to save!')
    } finally {
      setApiLoading(false)
    }
  }

  const fetchCredentials = async () => {
    try {
      const response = await fetch('/api/credentials')
      const data = await response.json()
      if (!data.error) {
        setCredentials(prev => ({
          ...prev,
          steadfastApiKey: data.steadfastApiKey || '',
          steadfastSecretKey: data.steadfastSecretKey || '',
          webhookUrl: data.webhookUrl || '',
        }))
      }
    } catch (error) {
      console.error('Error fetching credentials:', error)
    }
  }

  return (
    <div className="p-4 md:p-8" style={{fontFamily: "'Inter', sans-serif", backgroundColor: '#ffffff', color: '#0f172a', margin: '0', minHeight: 'calc(100vh - 80px)'}}>
      <div style={{width: '100%', maxWidth: '700px', margin: '0 auto', padding: '20px'}}>
        {/* Page Header */}
        <div style={{marginBottom: '32px'}}>
          <h1 style={{fontSize: '28px', fontWeight: 600, marginBottom: '8px'}}>Credentials</h1>
          <p style={{color: '#64748b', fontSize: '15px'}}>Manage your admin account and Steadfast courier integration.</p>
        </div>

        {/* Current User Info */}
        <div style={{
          backgroundColor: '#f0fdf4',
          border: '1px solid #bbf7d0',
          borderRadius: '12px',
          padding: '20px',
          marginBottom: '24px',
          display: 'flex',
          alignItems: 'center',
          gap: '16px'
        }}>
          <div style={{
            width: '48px',
            height: '48px',
            background: '#16a34a',
            borderRadius: '50%',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: 'white',
            fontWeight: 700,
            fontSize: '20px'
          }}>
            {session?.user?.name?.charAt(0).toUpperCase() || 'A'}
          </div>
          <div style={{flex: 1}}>
            <div style={{fontSize: '16px', fontWeight: 600, color: '#0f172a'}}>
              {session?.user?.name || 'Administrator'}
            </div>
            <div style={{fontSize: '14px', color: '#64748b'}}>
              Logged in as <strong>{session?.user?.username || 'admin'}</strong>
            </div>
          </div>
        </div>

        {/* Account Credentials Card */}
        <div style={{backgroundColor: '#ffffff', border: '1px solid #e2e8f0', borderRadius: '12px', padding: '32px', marginBottom: '32px', boxShadow: '0 1px 3px rgba(0,0,0,0.05)'}}>
          <div style={{marginBottom: '24px', paddingBottom: '16px', borderBottom: '1px solid #e2e8f0'}}>
            <h2 style={{fontSize: '18px', fontWeight: 600, color: '#0f172a', display: 'flex', alignItems: 'center', gap: '8px'}}>
              <i className="ri-shield-keyhole-line" style={{color: '#16a34a'}}></i>
              Account Credentials
            </h2>
            <p style={{fontSize: '14px', color: '#64748b', marginTop: '4px'}}>Update your admin username and password.</p>
          </div>

          {/* Show Current Credentials Button */}
          <div style={{marginBottom: '24px', padding: '16px', backgroundColor: '#ffffff', borderRadius: '8px', border: '1px solid #e2e8f0'}}>
            <div style={{display: 'flex', alignItems: 'center', justifyContent: 'space-between'}}>
              <div>
                <div style={{fontSize: '14px', fontWeight: 500, color: '#0f172a'}}>Current Credentials</div>
                <div style={{fontSize: '13px', color: '#64748b'}}>Click to view your current username and password</div>
              </div>
              <button
                type="button"
                onClick={handleShowCurrentCredentials}
                disabled={loadingCredentials}
                style={{
                  backgroundColor: showCurrentCredentials ? '#ef4444' : '#16a34a',
                  color: 'white',
                  border: 'none',
                  padding: '10px 16px',
                  borderRadius: '6px',
                  fontSize: '13px',
                  fontWeight: 500,
                  cursor: loadingCredentials ? 'wait' : 'pointer',
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: '6px'
                }}
              >
                {loadingCredentials ? (
                  <>
                    <i className="ri-loader-4-line" style={{animation: 'spin 1s linear infinite'}}></i>
                    Loading...
                  </>
                ) : showCurrentCredentials ? (
                  <>
                    <i className="ri-eye-off-line"></i>
                    Hide
                  </>
                ) : (
                  <>
                    <i className="ri-eye-line"></i>
                    Show
                  </>
                )}
              </button>
            </div>
            
            {showCurrentCredentials && currentCredentials && (
              <div style={{marginTop: '16px', paddingTop: '16px', borderTop: '1px dashed #e2e8f0'}}>
                <div style={{display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px'}}>
                  <div>
                    <div style={{fontSize: '12px', color: '#64748b', marginBottom: '4px'}}>Current Username</div>
                    <div style={{fontSize: '16px', fontWeight: 600, color: '#0f172a', fontFamily: 'monospace', backgroundColor: '#fff', padding: '8px 12px', borderRadius: '6px', border: '1px solid #e2e8f0'}}>
                      {currentCredentials.username}
                    </div>
                  </div>
                  <div>
                    <div style={{fontSize: '12px', color: '#64748b', marginBottom: '4px'}}>Current Password</div>
                    <div style={{fontSize: '16px', fontWeight: 600, color: '#0f172a', fontFamily: 'monospace', backgroundColor: '#fff', padding: '8px 12px', borderRadius: '6px', border: '1px solid #e2e8f0'}}>
                      {currentCredentials.password}
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>

          <form onSubmit={handleSaveAccount}>
            {/* Username Field */}
            <div style={{marginBottom: '20px'}}>
              <label style={{display: 'block', fontSize: '14px', fontWeight: 500, color: '#0f172a', marginBottom: '8px'}}>
                New Username
              </label>
              <input 
                type="text" 
                placeholder="new username" 
                value={credentials.username} 
                disabled={isLoading}
                onChange={(e) => setCredentials({...credentials, username: e.target.value})}
                style={{
                  width: '100%', 
                  padding: '12px 16px', 
                  border: '1px solid #e2e8f0', 
                  borderRadius: '8px', 
                  fontSize: '14px', 
                  color: '#0f172a', 
                  backgroundColor: isLoading ? '#f3f4f6' : '#ffffff', 
                  outline: 'none'
                }}
              />
              <p style={{fontSize: '12px', color: '#9ca3af', marginTop: '6px'}}>Leave empty to keep current username</p>
            </div>

            <div style={{marginBottom: '20px', paddingTop: '16px', borderTop: '1px dashed #e2e8f0'}}>
              <p style={{fontSize: '13px', color: '#64748b', marginBottom: '16px'}}>Enter current password to verify identity, then set new password:</p>
            </div>

            <div style={{marginBottom: '20px'}}>
              <label style={{display: 'block', fontSize: '14px', fontWeight: 500, color: '#0f172a', marginBottom: '8px'}}>
                Current Password <span style={{color: '#ef4444'}}>*</span>
              </label>
              <input 
                type="password" 
                placeholder="your current password" 
                value={credentials.currentPassword} 
                disabled={isLoading}
                onChange={(e) => setCredentials({...credentials, currentPassword: e.target.value})}
                style={{
                  width: '100%', 
                  padding: '12px 16px', 
                  border: '1px solid #e2e8f0', 
                  borderRadius: '8px', 
                  fontSize: '14px', 
                  color: '#0f172a', 
                  backgroundColor: isLoading ? '#f3f4f6' : '#ffffff', 
                  outline: 'none'
                }}
              />
            </div>

            <div style={{display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px', marginBottom: '12px'}}>
              <div>
                <label style={{display: 'block', fontSize: '14px', fontWeight: 500, color: '#0f172a', marginBottom: '8px'}}>
                  New Password
                </label>
                <input 
                  type="password" 
                  placeholder="new password" 
                  value={credentials.newPassword}
                  disabled={isLoading}
                  onChange={(e) => setCredentials({...credentials, newPassword: e.target.value})}
                  style={{
                    width: '100%', 
                    padding: '12px 16px', 
                    border: '1px solid #e2e8f0', 
                    borderRadius: '8px', 
                    fontSize: '14px', 
                    color: '#0f172a', 
                    backgroundColor: isLoading ? '#f3f4f6' : '#ffffff', 
                    outline: 'none'
                  }}
                />
                <p style={{fontSize: '12px', color: '#9ca3af', marginTop: '6px'}}>Minimum 6 characters</p>
              </div>
              <div>
                <label style={{display: 'block', fontSize: '14px', fontWeight: 500, color: '#0f172a', marginBottom: '8px'}}>
                  Confirm New Password
                </label>
                <input 
                  type="password" 
                  placeholder="Confirm new password" 
                  value={credentials.confirmPassword}
                  disabled={isLoading}
                  onChange={(e) => setCredentials({...credentials, confirmPassword: e.target.value})}
                  style={{
                    width: '100%', 
                    padding: '12px 16px', 
                    border: '1px solid #e2e8f0', 
                    borderRadius: '8px', 
                    fontSize: '14px', 
                    color: '#0f172a', 
                    backgroundColor: isLoading ? '#f3f4f6' : '#ffffff', 
                    outline: 'none'
                  }}
                />
              </div>
            </div>

            <div style={{display: 'flex', justifyContent: 'flex-end', marginTop: '12px'}}>
              <button 
                type="submit"
                disabled={isLoading}
                style={{
                  backgroundColor: isLoading ? '#9ca3af' : '#16a34a', 
                  color: 'white', 
                  border: 'none', 
                  padding: '12px 24px', 
                  borderRadius: '8px', 
                  fontSize: '14px', 
                  fontWeight: 500, 
                  cursor: isLoading ? 'not-allowed' : 'pointer', 
                  display: 'inline-flex', 
                  alignItems: 'center', 
                  gap: '8px'
                }}
              >
                {isLoading ? (
                  <>
                    <i className="ri-loader-4-line" style={{animation: 'spin 1s linear infinite'}}></i>
                    Saving...
                  </>
                ) : (
                  <>
                    <i className="ri-save-line"></i>
                    Save Changes
                  </>
                )}
              </button>
            </div>
          </form>
        </div>

        {/* Steadfast Courier Card */}
        <div style={{backgroundColor: '#ffffff', border: '1px solid #e2e8f0', borderRadius: '12px', padding: '32px', marginBottom: '0', boxShadow: '0 1px 3px rgba(0,0,0,0.05)'}}>
          <div style={{marginBottom: '24px', paddingBottom: '16px', borderBottom: '1px solid #e2e8f0'}}>
            <h2 style={{fontSize: '18px', fontWeight: 600, color: '#0f172a', display: 'flex', alignItems: 'center', gap: '8px'}}>
              <i className="ri-truck-line" style={{color: '#16a34a'}}></i>
              Steadfast Courier
            </h2>
            <p style={{fontSize: '14px', color: '#64748b', marginTop: '4px'}}>Configure Steadfast courier API credentials.</p>
          </div>

          {/* Show Steadfast Credentials Button */}
          <div style={{marginBottom: '24px', padding: '16px', backgroundColor: '#ffffff', borderRadius: '8px', border: '1px solid #e2e8f0'}}>
            <div style={{display: 'flex', alignItems: 'center', justifyContent: 'space-between'}}>
              <div>
                <div style={{fontSize: '14px', fontWeight: 500, color: '#0f172a'}}>Current Steadfast Credentials</div>
                <div style={{fontSize: '13px', color: '#64748b'}}>Click to view your API Key and Secret Key</div>
              </div>
              <button
                type="button"
                onClick={handleShowSteadfastCredentials}
                disabled={loadingSteadfast}
                style={{
                  backgroundColor: showSteadfastCredentials ? '#ef4444' : '#16a34a',
                  color: 'white',
                  border: 'none',
                  padding: '10px 16px',
                  borderRadius: '6px',
                  fontSize: '13px',
                  fontWeight: 500,
                  cursor: loadingSteadfast ? 'wait' : 'pointer',
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: '6px'
                }}
              >
                {loadingSteadfast ? (
                  <>
                    <i className="ri-loader-4-line" style={{animation: 'spin 1s linear infinite'}}></i>
                    Loading...
                  </>
                ) : showSteadfastCredentials ? (
                  <>
                    <i className="ri-eye-off-line"></i>
                    Hide
                  </>
                ) : (
                  <>
                    <i className="ri-eye-line"></i>
                    Show
                  </>
                )}
              </button>
            </div>
            
            {showSteadfastCredentials && steadfastCredentials && (
              <div style={{marginTop: '16px', paddingTop: '16px', borderTop: '1px dashed #e2e8f0'}}>
                <div style={{marginBottom: '12px'}}>
                  <div style={{fontSize: '12px', color: '#64748b', marginBottom: '4px'}}>API Key</div>
                  <div style={{fontSize: '14px', fontWeight: 600, color: '#0f172a', fontFamily: 'monospace', backgroundColor: '#fff', padding: '8px 12px', borderRadius: '6px', border: '1px solid #e2e8f0', wordBreak: 'break-all'}}>
                    {steadfastCredentials.apiKey || '(not set)'}
                  </div>
                </div>
                <div style={{marginBottom: '12px'}}>
                  <div style={{fontSize: '12px', color: '#64748b', marginBottom: '4px'}}>Secret Key</div>
                  <div style={{fontSize: '14px', fontWeight: 600, color: '#0f172a', fontFamily: 'monospace', backgroundColor: '#fff', padding: '8px 12px', borderRadius: '6px', border: '1px solid #e2e8f0', wordBreak: 'break-all'}}>
                    {steadfastCredentials.secretKey || '(not set)'}
                  </div>
                </div>
                <div>
                  <div style={{fontSize: '12px', color: '#64748b', marginBottom: '4px'}}>Webhook URL</div>
                  <div style={{fontSize: '14px', fontWeight: 600, color: '#0f172a', fontFamily: 'monospace', backgroundColor: '#fff', padding: '8px 12px', borderRadius: '6px', border: '1px solid #e2e8f0', wordBreak: 'break-all'}}>
                    {steadfastCredentials.webhookUrl || '(not set)'}
                  </div>
                </div>
              </div>
            )}
          </div>

          <form onSubmit={handleSaveSteadfast}>
            <div style={{marginBottom: '20px'}}>
              <label style={{display: 'block', fontSize: '14px', fontWeight: 500, color: '#0f172a', marginBottom: '8px'}}>API Key</label>
              <input 
                type="text" 
                placeholder="Your Steadfast API Key" 
                value={credentials.steadfastApiKey} 
                onChange={(e) => setCredentials({...credentials, steadfastApiKey: e.target.value})}
                style={{
                  width: '100%', 
                  padding: '12px 16px', 
                  border: '1px solid #e2e8f0', 
                  borderRadius: '8px', 
                  fontSize: '14px', 
                  color: '#0f172a', 
                  backgroundColor: '#ffffff', 
                  outline: 'none'
                }}
              />
            </div>

            <div style={{marginBottom: '20px'}}>
              <label style={{display: 'block', fontSize: '14px', fontWeight: 500, color: '#0f172a', marginBottom: '8px'}}>Secret Key</label>
              <input 
                type="password" 
                placeholder="your secret key" 
                value={credentials.steadfastSecretKey} 
                onChange={(e) => {
                  setCredentials({...credentials, steadfastSecretKey: e.target.value})
                  setSteadfastKeyChanged(true)
                }}
                style={{
                  width: '100%', 
                  padding: '12px 16px', 
                  border: '1px solid #e2e8f0', 
                  borderRadius: '8px', 
                  fontSize: '14px', 
                  color: '#0f172a', 
                  backgroundColor: '#ffffff', 
                  outline: 'none'
                }}
              />
              {credentials.steadfastSecretKey?.includes('****') && (
                <p style={{fontSize: '12px', color: '#9ca3af', marginTop: '6px'}}>Key is set. Enter new key to update.</p>
              )}
            </div>

            <div style={{marginBottom: '20px'}}>
              <label style={{display: 'block', fontSize: '14px', fontWeight: 500, color: '#0f172a', marginBottom: '8px'}}>Webhook URL</label>
              <input 
                type="url" 
                placeholder="https://yourdomain.com/api/webhook" 
                value={credentials.webhookUrl} 
                onChange={(e) => setCredentials({...credentials, webhookUrl: e.target.value})}
                style={{
                  width: '100%', 
                  padding: '12px 16px', 
                  border: '1px solid #e2e8f0', 
                  borderRadius: '8px', 
                  fontSize: '14px', 
                  color: '#0f172a', 
                  backgroundColor: '#ffffff', 
                  outline: 'none'
                }}
              />
            </div>

            <div style={{display: 'flex', justifyContent: 'flex-end', marginTop: '12px'}}>
              <button 
                type="submit"
                disabled={apiLoading}
                style={{
                  backgroundColor: apiLoading ? '#9ca3af' : '#16a34a', 
                  color: 'white', 
                  border: 'none', 
                  padding: '12px 24px', 
                  borderRadius: '8px', 
                  fontSize: '14px', 
                  fontWeight: 500, 
                  cursor: apiLoading ? 'not-allowed' : 'pointer', 
                  display: 'inline-flex', 
                  alignItems: 'center', 
                  gap: '8px'
                }}
              >
                <i className="ri-save-line"></i>
                Save Credentials
              </button>
            </div>
          </form>
        </div>
      </div>

      <style>{`
        @keyframes spin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  )
}

export default CredentialsView
