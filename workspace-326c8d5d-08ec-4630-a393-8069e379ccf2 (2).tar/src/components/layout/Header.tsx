'use client'

import { useState } from 'react'
import { ViewType } from '@/types'
import { useShopStore } from '@/store/useShopStore'
import { 
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet'
import {
  Home,
  Grid3X3,
  Gift,
  ShoppingBag,
  FileText,
  User,
  Info,
  FileCheck,
  RotateCcw,
  Shield,
  Phone,
  ChevronRight
} from 'lucide-react'

interface HeaderProps {
  view: ViewType
  setView: (v: ViewType) => void
  cartCount: number
}

interface NavItem {
  id: ViewType
  label: string
  icon: React.ReactNode
  divider?: boolean
}

const navItems: NavItem[] = [
  { id: 'shop', label: 'Home', icon: <Home className="w-5 h-5" /> },
  { id: 'shop', label: 'Categories', icon: <Grid3X3 className="w-5 h-5" /> },
  { id: 'offers', label: 'Offers', icon: <Gift className="w-5 h-5" /> },
  { id: 'orders', label: 'My Orders', icon: <FileText className="w-5 h-5" /> },
  { id: 'profile', label: 'My Profile', icon: <User className="w-5 h-5" /> },
  { id: 'cart', label: 'Cart', icon: <ShoppingBag className="w-5 h-5" />, divider: true },
  { id: 'about', label: 'About Us', icon: <Info className="w-5 h-5" /> },
  { id: 'terms', label: 'Terms & Conditions', icon: <FileCheck className="w-5 h-5" /> },
  { id: 'refund', label: 'Refund Policy', icon: <RotateCcw className="w-5 h-5" /> },
  { id: 'privacy', label: 'Privacy Policy', icon: <Shield className="w-5 h-5" /> },
]

export default function Header({ view, setView, cartCount }: HeaderProps) {
  const { settings, searchQuery, setSearchQuery } = useShopStore()
  const logoUrl = settings.logoUrl
  const [localSearch, setLocalSearch] = useState(searchQuery)
  const [menuOpen, setMenuOpen] = useState(false)

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    setSearchQuery(localSearch)
    if (view !== 'shop') {
      setView('shop')
    }
  }

  const handleSearchChange = (value: string) => {
    setLocalSearch(value)
    // Real-time search as user types
    setSearchQuery(value)
  }

  const handleNavClick = (navView: ViewType) => {
    setView(navView)
    setMenuOpen(false)
    if (navView === 'shop') {
      setSearchQuery('')
      setLocalSearch('')
    }
  }

  return (
    <header className="w-full bg-white border-b border-gray-200 shadow-[0_1px_4px_rgba(0,0,0,0.08)] flex items-center justify-between px-3 md:px-[2rem] h-[70px] md:h-[100px] sticky top-0 z-[200]">
      <div className="flex items-center shrink-0 w-auto">
        <div className="flex items-center gap-2 cursor-pointer" onClick={() => { setView('shop'); setSearchQuery(''); setLocalSearch(''); }}>
          <img src={logoUrl} alt="Logo" className="h-[70px] w-[70px] md:h-[90px] md:w-[90px] object-contain" />
        </div>
      </div>

      <form className="hidden md:flex flex-1 justify-center mx-[1rem] max-w-2xl" onSubmit={handleSearch}>
        <div className="flex items-center border border-gray-300 rounded-full px-6 w-full bg-transparent h-12 relative transition-all duration-200 focus-within:border-orange-500">
          <input 
            type="text" 
            name="search" 
            placeholder="Search Product" 
            className="w-full outline-none bg-transparent text-lg text-gray-700 placeholder-gray-400 pr-10" 
            value={localSearch}
            onChange={(e) => handleSearchChange(e.target.value)}
          />
          <button type="submit" className="absolute right-5 cursor-pointer hover:text-black transition-colors">
            <i className="ri-search-line text-gray-400 text-2xl"></i>
          </button>
        </div>
      </form>

      <form className="md:hidden flex items-center border border-gray-300 rounded-full px-3 bg-white h-[36px] flex-1 mr-4 ml-2 relative" onSubmit={handleSearch}>
        <input 
          type="text" 
          name="search" 
          placeholder="Search..." 
          className="w-full outline-none bg-transparent text-sm text-gray-700 placeholder-gray-400 pr-6 pb-[1px]" 
          value={localSearch}
          onChange={(e) => handleSearchChange(e.target.value)}
        />
        <button type="submit" className="absolute right-2">
          <i className="ri-search-line text-gray-400 text-base"></i>
        </button>
      </form>

      {/* Desktop Navigation */}
      <div className="hidden md:flex items-center justify-end h-10 shrink-0 gap-0">
        <div className="px-5 border-r border-gray-200 cursor-pointer hover:text-orange-500 relative transition-colors h-full flex items-center" onClick={() => setView('offers')}>
          <div className="relative">
            <i className="ri-gift-line text-[28px] text-gray-600 leading-none"></i>
          </div>
        </div>
        <div className="px-5 border-r border-gray-200 cursor-pointer hover:text-orange-500 relative transition-colors h-full flex items-center" onClick={() => setView('cart')}>
          <div className="relative">
            <i className="ri-shopping-bag-line text-[28px] text-gray-600 leading-none"></i>
            {cartCount > 0 && <span className="absolute -top-1 -right-1 h-4 w-4 bg-red-500 rounded-full text-[9px] text-white flex items-center justify-center font-bold border-2 border-white">{cartCount}</span>}
          </div>
        </div>
        <div className="px-5 border-r border-gray-200 cursor-pointer hover:text-orange-500 transition-colors h-full flex items-center" onClick={() => setView('orders')}>
          <i className="ri-file-list-3-line text-[28px] text-gray-600 leading-none"></i>
        </div>
        <div className="px-5 border-r border-gray-200 cursor-pointer hover:text-orange-500 transition-colors h-full flex items-center" onClick={() => setView('profile')}>
          <i className="ri-user-line text-[28px] text-gray-600 leading-none"></i>
        </div>
        
        {/* 3-Dot Menu Button */}
        <Sheet open={menuOpen} onOpenChange={setMenuOpen}>
          <SheetTrigger asChild>
            <div className="pl-5 cursor-pointer hover:text-orange-500 transition-colors h-full flex items-center">
              <i className="ri-more-2-fill text-[28px] text-gray-600 leading-none"></i>
            </div>
          </SheetTrigger>
          <SheetContent side="right" className="w-[300px] sm:w-[350px] p-0 z-[300]">
            <SheetHeader className="p-5 border-b border-gray-100 bg-gradient-to-r from-orange-50 to-amber-50">
              <SheetTitle className="text-left text-xl font-bold text-gray-800">
                Menu
              </SheetTitle>
              <p className="text-sm text-gray-500 text-left">Navigate to different pages</p>
            </SheetHeader>
            
            <div className="py-2 overflow-y-auto max-h-[calc(100vh-120px)]">
              {navItems.map((item, index) => (
                <div key={item.id}>
                  {item.divider && <div className="h-2 bg-gray-50 my-2" />}
                  <button
                    onClick={() => handleNavClick(item.id)}
                    className={`w-full flex items-center gap-4 px-5 py-3.5 text-left hover:bg-orange-50 transition-colors group ${
                      view === item.id ? 'bg-orange-50 text-orange-600' : 'text-gray-700'
                    }`}
                  >
                    <span className={`${view === item.id ? 'text-orange-500' : 'text-gray-400 group-hover:text-orange-500'} transition-colors`}>
                      {item.icon}
                    </span>
                    <span className="flex-1 font-medium">{item.label}</span>
                    <ChevronRight className="w-4 h-4 text-gray-300 group-hover:text-orange-400 transition-colors" />
                  </button>
                </div>
              ))}
            </div>
            
            {/* Contact Section */}
            <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-gray-100 bg-gray-50">
              <div className="flex items-center gap-3 text-sm text-gray-600">
                <Phone className="w-4 h-4 text-orange-500" />
                <span>Need help? Contact us</span>
              </div>
            </div>
          </SheetContent>
        </Sheet>
      </div>

      {/* Mobile Navigation */}
      <div className="md:hidden flex items-center justify-end h-10 shrink-0 gap-2">
        <div className="cursor-pointer hover:text-orange-500 transition-colors" onClick={() => setView('offers')}>
          <i className="ri-gift-line text-[24px] text-gray-600 leading-none"></i>
        </div>
        <div className="cursor-pointer hover:text-orange-500 relative transition-colors" onClick={() => setView('cart')}>
          <i className="ri-shopping-bag-line text-[24px] text-gray-600 leading-none"></i>
          {cartCount > 0 && <span className="absolute -top-1 -right-1 h-3.5 w-3.5 bg-red-500 rounded-full text-[9px] text-white flex items-center justify-center font-bold border-2 border-white">{cartCount}</span>}
        </div>
        
        {/* Mobile 3-Dot Menu Button */}
        <Sheet open={menuOpen} onOpenChange={setMenuOpen}>
          <SheetTrigger asChild>
            <div className="cursor-pointer hover:text-orange-500 transition-colors ml-1">
              <i className="ri-more-2-fill text-[24px] text-gray-600 leading-none"></i>
            </div>
          </SheetTrigger>
          <SheetContent side="right" className="w-[280px] p-0 z-[300]">
            <SheetHeader className="p-4 border-b border-gray-100 bg-gradient-to-r from-orange-50 to-amber-50">
              <SheetTitle className="text-left text-lg font-bold text-gray-800">
                Menu
              </SheetTitle>
              <p className="text-xs text-gray-500 text-left">Navigate to different pages</p>
            </SheetHeader>
            
            <div className="py-2 overflow-y-auto max-h-[calc(100vh-100px)]">
              {navItems.map((item, index) => (
                <div key={item.id}>
                  {item.divider && <div className="h-2 bg-gray-50 my-2" />}
                  <button
                    onClick={() => handleNavClick(item.id)}
                    className={`w-full flex items-center gap-3 px-4 py-3 text-left hover:bg-orange-50 transition-colors group ${
                      view === item.id ? 'bg-orange-50 text-orange-600' : 'text-gray-700'
                    }`}
                  >
                    <span className={`${view === item.id ? 'text-orange-500' : 'text-gray-400 group-hover:text-orange-500'} transition-colors`}>
                      {item.icon}
                    </span>
                    <span className="flex-1 font-medium text-sm">{item.label}</span>
                    <ChevronRight className="w-4 h-4 text-gray-300 group-hover:text-orange-400 transition-colors" />
                  </button>
                </div>
              ))}
            </div>
            
            {/* Contact Section */}
            <div className="absolute bottom-0 left-0 right-0 p-3 border-t border-gray-100 bg-gray-50">
              <div className="flex items-center gap-2 text-xs text-gray-600">
                <Phone className="w-3.5 h-3.5 text-orange-500" />
                <span>Need help? Contact us</span>
              </div>
            </div>
          </SheetContent>
        </Sheet>
      </div>
    </header>
  )
}
