'use client'

import { useEffect } from 'react'
import { useRouter } from 'next/navigation'
import AdminDashboard from '@/components/admin/AdminDashboard'
import AuthWrapper from '@/components/auth/AuthWrapper'

export default function AdminPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <AuthWrapper onBack={() => window.location.href = '/'}>
        <AdminDashboard setView={() => {}} />
      </AuthWrapper>
    </div>
  )
}
