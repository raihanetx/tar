import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/db'
import { adminUsers } from '@/db/schema'
import { eq } from 'drizzle-orm'
import bcrypt from 'bcryptjs'
import { encrypt, decrypt } from '@/lib/encryption'

// GET - Check if admin user exists
export async function GET() {
  try {
    // Check authentication
    const session = await getServerSession(authOptions)
    if (!session || !session.user) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 })
    }

    const users = await db.select().from(adminUsers).limit(1)
    
    return NextResponse.json({
      success: true,
      hasAdmin: users.length > 0
    })
  } catch (error) {
    console.error('Error checking admin:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to check admin user' },
      { status: 500 }
    )
  }
}

// POST - Create initial admin user (only if no admin exists)
export async function POST(request: NextRequest) {
  try {
    // Check if admin already exists
    const existingUsers = await db.select().from(adminUsers).limit(1)
    
    if (existingUsers.length > 0) {
      return NextResponse.json(
        { success: false, error: 'Admin user already exists' },
        { status: 400 }
      )
    }
    
    const body = await request.json()
    const { username, password, name } = body
    
    if (!username || !password) {
      return NextResponse.json(
        { success: false, error: 'Username and password are required' },
        { status: 400 }
      )
    }
    
    // Hash password for authentication
    const hashedPassword = await bcrypt.hash(password, 10)
    // Encrypt password for display
    const encryptedPassword = encrypt(password)
    
    // Create admin user
    await db.insert(adminUsers).values({
      username,
      password: hashedPassword,
      passwordDisplay: encryptedPassword,
      name: name || username,
    })
    
    console.log('✅ Created admin user:', username)
    
    return NextResponse.json({
      success: true,
      message: 'Admin user created successfully'
    }, { status: 201 })
  } catch (error) {
    console.error('Error creating admin:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to create admin user' },
      { status: 500 }
    )
  }
}

// PATCH - Change username and/or password
export async function PATCH(request: NextRequest) {
  try {
    // Check authentication
    const session = await getServerSession(authOptions)
    if (!session || !session.user) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const { currentUsername, newUsername, currentPassword, newPassword } = body
    
    // Find user by current username
    const users = await db.select().from(adminUsers).where(eq(adminUsers.username, currentUsername)).limit(1)
    
    if (users.length === 0) {
      return NextResponse.json(
        { success: false, error: 'User not found' },
        { status: 404 }
      )
    }
    
    const user = users[0]
    
    // Build update data
    const updateData: { username?: string; password?: string; passwordDisplay?: string } = {}
    
    // Check if changing username
    if (newUsername && newUsername !== currentUsername) {
      // Check if new username already exists
      const existingUser = await db.select().from(adminUsers).where(eq(adminUsers.username, newUsername)).limit(1)
      
      if (existingUser.length > 0) {
        return NextResponse.json(
          { success: false, error: 'Username already exists' },
          { status: 400 }
        )
      }
      
      updateData.username = newUsername
    }
    
    // Check if changing password
    if (newPassword) {
      if (!currentPassword) {
        return NextResponse.json(
          { success: false, error: 'Current password is required to change password' },
          { status: 400 }
        )
      }
      
      // Verify current password
      const isValid = await bcrypt.compare(currentPassword, user.password)
      
      if (!isValid) {
        return NextResponse.json(
          { success: false, error: 'Current password is incorrect' },
          { status: 400 }
        )
      }
      
      // Hash new password for authentication
      updateData.password = await bcrypt.hash(newPassword, 10)
      // Encrypt new password for display
      updateData.passwordDisplay = encrypt(newPassword)
    }
    
    // If changing username only, require password verification
    if (updateData.username && !updateData.password && !currentPassword) {
      return NextResponse.json(
        { success: false, error: 'Current password is required to change username' },
        { status: 400 }
      )
    }
    
    // Verify password for username-only change
    if (updateData.username && !updateData.password && currentPassword) {
      const isValid = await bcrypt.compare(currentPassword, user.password)
      if (!isValid) {
        return NextResponse.json(
          { success: false, error: 'Current password is incorrect' },
          { status: 400 }
        )
      }
    }
    
    // If no changes
    if (Object.keys(updateData).length === 0) {
      return NextResponse.json(
        { success: false, error: 'No changes to update' },
        { status: 400 }
      )
    }
    
    // Update user
    await db.update(adminUsers)
      .set(updateData)
      .where(eq(adminUsers.id, user.id))
    
    console.log('✅ Updated admin user:', { username: updateData.username || currentUsername, changed: Object.keys(updateData) })
    
    return NextResponse.json({
      success: true,
      message: 'Credentials updated successfully'
    })
  } catch (error) {
    console.error('Error updating credentials:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to update credentials' },
      { status: 500 }
    )
  }
}
