import { NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/db'
import { adminUsers } from '@/db/schema'
import { eq } from 'drizzle-orm'
import { decrypt } from '@/lib/encryption'

// GET - Get current admin username and password
export async function GET() {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session || !session.user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const username = session.user.username || 'admin'
    
    const users = await db.select().from(adminUsers).where(eq(adminUsers.username, username)).limit(1)
    
    if (users.length === 0) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 })
    }
    
    const user = users[0]
    
    // Decrypt password for display
    let decryptedPassword = '(password not available)'
    if (user.passwordDisplay) {
      try {
        decryptedPassword = decrypt(user.passwordDisplay)
      } catch {
        decryptedPassword = '(could not decrypt)'
      }
    }
    
    return NextResponse.json({
      success: true,
      data: {
        username: user.username,
        password: decryptedPassword
      }
    })
  } catch (error) {
    console.error('Error fetching current credentials:', error)
    return NextResponse.json({ error: 'Failed to fetch credentials' }, { status: 500 })
  }
}
