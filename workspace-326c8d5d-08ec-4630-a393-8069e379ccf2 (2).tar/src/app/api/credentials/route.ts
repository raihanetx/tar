import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/db'
import { apiCredentials } from '@/db/schema'
import { eq } from 'drizzle-orm'
import { encrypt, decrypt, maskSensitive } from '@/lib/encryption'

// GET - Retrieve API credentials
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session || !session.user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const reveal = searchParams.get('reveal') === 'true'

    const creds = await db.select().from(apiCredentials).where(eq(apiCredentials.id, 1)).limit(1)
    
    if (creds.length === 0) {
      return NextResponse.json({
        steadfastApiKey: '',
        steadfastSecretKey: '',
        webhookUrl: ''
      })
    }

    const cred = creds[0]
    
    // If reveal=true, return actual value, otherwise return masked
    let secretKey = ''
    if (cred.steadfastSecretKey) {
      const decrypted = decrypt(cred.steadfastSecretKey)
      secretKey = reveal ? decrypted : maskSensitive(decrypted)
    }
    
    return NextResponse.json({
      steadfastApiKey: cred.steadfastApiKey || '',
      steadfastSecretKey: secretKey,
      webhookUrl: cred.webhookUrl || ''
    })
  } catch (error) {
    console.error('Error fetching credentials:', error)
    return NextResponse.json({
      steadfastApiKey: '',
      steadfastSecretKey: '',
      webhookUrl: ''
    })
  }
}

// POST - Save API credentials
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session || !session.user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const { steadfastApiKey, steadfastSecretKey, webhookUrl } = body

    // Check if credentials exist
    const existing = await db.select().from(apiCredentials).where(eq(apiCredentials.id, 1)).limit(1)
    
    // Determine if secret key is new or being updated
    // If the value contains '****', it means the user didn't change it
    let steadfastKeyToSave = existing[0]?.steadfastSecretKey || ''
    
    if (steadfastSecretKey && !steadfastSecretKey.includes('****')) {
      steadfastKeyToSave = encrypt(steadfastSecretKey)
    }

    const now = Math.floor(Date.now() / 1000)
    
    if (existing.length > 0) {
      await db.update(apiCredentials)
        .set({
          steadfastApiKey: steadfastApiKey || null,
          steadfastSecretKey: steadfastKeyToSave || null,
          webhookUrl: webhookUrl || null,
          updatedAt: now
        })
        .where(eq(apiCredentials.id, 1))
    } else {
      await db.insert(apiCredentials).values({
        id: 1,
        steadfastApiKey: steadfastApiKey || null,
        steadfastSecretKey: steadfastKeyToSave || null,
        webhookUrl: webhookUrl || null
      })
    }

    return NextResponse.json({ success: true, message: 'Credentials saved successfully' })
  } catch (error) {
    console.error('Error saving credentials:', error)
    return NextResponse.json({ error: 'Failed to save credentials' }, { status: 500 })
  }
}
