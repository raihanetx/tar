import crypto from 'crypto'

// Encryption key MUST be set in environment variables
// This is required for security - no fallback is provided
const getEncryptionKey = (): string => {
  const key = process.env.ENCRYPTION_KEY
  if (!key) {
    throw new Error(
      'ENCRYPTION_KEY environment variable is not set. ' +
      'Please add a 32-character ENCRYPTION_KEY to your .env file. ' +
      'Example: ENCRYPTION_KEY=your-32-character-secret-key-here'
    )
  }
  return key
}

// Lazy-load the key only when needed (allows app to start for initial setup)
let _encryptionKey: string | null = null
const ENCRYPTION_KEY = (): string => {
  if (!_encryptionKey) {
    _encryptionKey = getEncryptionKey()
  }
  return _encryptionKey
}

const ALGORITHM = 'aes-256-cbc'
const IV_LENGTH = 16

// Ensure key is exactly 32 bytes for AES-256
const getKey = (): Buffer => {
  const key = ENCRYPTION_KEY().padEnd(32, '0').slice(0, 32)
  return Buffer.from(key, 'utf8')
}

/**
 * Encrypt a text string
 */
export function encrypt(text: string): string {
  if (!text) return ''
  
  try {
    const iv = crypto.randomBytes(IV_LENGTH)
    const cipher = crypto.createCipheriv(ALGORITHM, getKey(), iv)
    let encrypted = cipher.update(text, 'utf8', 'hex')
    encrypted += cipher.final('hex')
    return iv.toString('hex') + ':' + encrypted
  } catch (error) {
    console.error('Encryption error:', error)
    return ''
  }
}

/**
 * Decrypt an encrypted string
 */
export function decrypt(encryptedText: string): string {
  if (!encryptedText) return ''
  
  try {
    const parts = encryptedText.split(':')
    if (parts.length !== 2) {
      // Not encrypted, return as-is (for backward compatibility)
      return encryptedText
    }
    
    const iv = Buffer.from(parts[0], 'hex')
    const encrypted = parts[1]
    const decipher = crypto.createDecipheriv(ALGORITHM, getKey(), iv)
    let decrypted = decipher.update(encrypted, 'hex', 'utf8')
    decrypted += decipher.final('utf8')
    return decrypted
  } catch (error) {
    console.error('Decryption error:', error)
    // Return original if decryption fails (backward compatibility)
    return encryptedText
  }
}

/**
 * Mask a sensitive value for display (show only last 4 characters)
 */
export function maskSensitive(value: string): string {
  if (!value || value.length <= 4) return '****'
  return '****' + value.slice(-4)
}

/**
 * Check if a value is encrypted
 */
export function isEncrypted(value: string): boolean {
  if (!value) return false
  const parts = value.split(':')
  return parts.length === 2 && parts[0].length === IV_LENGTH * 2
}
