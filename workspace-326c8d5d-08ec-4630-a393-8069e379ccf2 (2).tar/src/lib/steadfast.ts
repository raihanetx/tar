/**
 * Steadfast Courier API Integration Service
 * Documentation: https://portal.packzy.com/api/v1
 */

interface CreateOrderParams {
  invoice: string
  recipient_name: string
  recipient_phone: string
  recipient_address: string
  cod_amount: number
  alternative_phone?: string
  recipient_email?: string
  note?: string
  item_description?: string
  total_lot?: number
  delivery_type?: 0 | 1 // 0 = home delivery, 1 = point delivery
}

interface BulkOrderItem {
  invoice: string
  recipient_name: string
  recipient_phone: string
  recipient_address: string
  cod_amount: number
  note?: string
}

interface ConsignmentResponse {
  status: number
  message: string
  consignment?: {
    consignment_id: number
    invoice: string
    tracking_code: string
    recipient_name: string
    recipient_phone: string
    recipient_address: string
    cod_amount: number
    status: string
    note: string | null
    created_at: string
    updated_at: string
  }
}

interface BulkOrderResponse {
  invoice: string
  recipient_name: string
  recipient_address: string
  recipient_phone: string
  cod_amount: string
  note: string | null
  consignment_id: number | null
  tracking_code: string | null
  status: 'success' | 'error'
}

class SteadfastService {
  private apiKey: string
  private secretKey: string
  private baseUrl: string

  constructor() {
    // Trim whitespace from credentials to avoid authentication issues
    this.apiKey = (process.env.STEADFAST_API_KEY || '').trim()
    this.secretKey = (process.env.STEADFAST_SECRET_KEY || '').trim()
    this.baseUrl = (process.env.STEADFAST_BASE_URL || 'https://portal.packzy.com/api/v1').trim()
  }

  private getHeaders(): HeadersInit {
    return {
      'Api-Key': this.apiKey,
      'Secret-Key': this.secretKey,
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    }
  }

  /**
   * Check if API credentials are configured
   */
  isConfigured(): boolean {
    return !!(this.apiKey && this.secretKey)
  }

  /**
   * Safely parse API response - handles both JSON and plain text responses
   */
  private async parseResponse(response: Response): Promise<{ data: any; error: string | null }> {
    try {
      const text = await response.text()
      
      // Try to parse as JSON
      try {
        const data = JSON.parse(text)
        return { data, error: null }
      } catch {
        // Not JSON - return the text as error message
        return { data: null, error: text }
      }
    } catch (err) {
      return { data: null, error: 'Failed to read response' }
    }
  }

  /**
   * Verify API credentials by checking balance
   */
  async verifyCredentials(): Promise<{ valid: boolean; message: string; balance?: number }> {
    try {
      console.log('[Steadfast] Verifying credentials...')
      console.log('[Steadfast] API Key:', this.apiKey)
      console.log('[Steadfast] Secret Key:', this.secretKey)
      console.log('[Steadfast] API Key length:', this.apiKey?.length || 0)
      console.log('[Steadfast] Secret Key length:', this.secretKey?.length || 0)
      console.log('[Steadfast] Base URL:', this.baseUrl)
      
      // Try the main base URL first
      const response = await fetch(`${this.baseUrl}/get_balance`, {
        method: 'GET',
        headers: this.getHeaders()
      })

      console.log('[Steadfast] Response status:', response.status)
      console.log('[Steadfast] Response headers:', Object.fromEntries(response.headers.entries()))
      
      const { data, error } = await this.parseResponse(response)
      
      console.log('[Steadfast] Response data:', data)
      console.log('[Steadfast] Response error:', error)
      
      if (error) {
        console.error('[Steadfast] Verify error:', error, 'Status:', response.status)
        return {
          valid: false,
          message: error.includes('inactive') || error.includes('not active')
            ? 'Your Steadfast account is NOT ACTIVE. Please: 1) Login to Steadfast dashboard, 2) Go to API Settings, 3) Enable/Activate API access, 4) Verify your phone/email if required, 5) Ensure you have sufficient balance. Contact Steadfast support if needed.'
            : error.includes('Invalid') || error.includes('unauthorized')
            ? 'Invalid API credentials. Please double-check your API Key and Secret Key from Steadfast dashboard > API Settings.'
            : `Steadfast API Error: ${error}`
        }
      }
      
      if (data && data.status === 200) {
        return {
          valid: true,
          message: 'Credentials verified successfully',
          balance: data.current_balance
        }
      }
      
      return {
        valid: false,
        message: data?.message || 'Unknown error from Steadfast API'
      }
    } catch (error) {
      console.error('[Steadfast] Verify credentials error:', error)
      return {
        valid: false,
        message: 'Failed to connect to Steadfast. Please check your internet connection.'
      }
    }
  }

  /**
   * Create a single order/consignment
   */
  async createOrder(params: CreateOrderParams): Promise<ConsignmentResponse> {
    try {
      console.log('[Steadfast] ===== CREATE ORDER =====')
      console.log('[Steadfast] Creating order:', params.invoice)
      console.log('[Steadfast] API Key:', this.apiKey)
      console.log('[Steadfast] Secret Key:', this.secretKey)
      console.log('[Steadfast] Base URL:', this.baseUrl)
      console.log('[Steadfast] Request params:', JSON.stringify(params, null, 2))
      
      const headers = this.getHeaders()
      console.log('[Steadfast] Headers:', JSON.stringify(headers))
      
      const url = `${this.baseUrl}/create_order`
      console.log('[Steadfast] Full URL:', url)
      
      const response = await fetch(url, {
        method: 'POST',
        headers: headers,
        body: JSON.stringify(params)
      })

      console.log('[Steadfast] Response status:', response.status)
      
      // Get raw response text
      const rawText = await response.text()
      console.log('[Steadfast] Raw response:', rawText)
      
      // Try to parse as JSON
      try {
        const parsed = JSON.parse(rawText)
        console.log('[Steadfast] Parsed response:', JSON.stringify(parsed, null, 2))
        
        if (parsed.status === 200 && parsed.consignment) {
          return parsed
        }
        
        // Handle error response
        const errorMsg = parsed.message || rawText
        return {
          status: parsed.status || response.status,
          message: errorMsg.includes('inactive') || errorMsg.includes('not active')
            ? `Steadfast Error: ${errorMsg}. Your API works for balance check but not for creating orders. Please check if your Steadfast account has API order creation enabled.`
            : errorMsg.includes('Invalid') || errorMsg.includes('unauthorized')
            ? 'Invalid API credentials. Please double-check your API Key and Secret Key.'
            : errorMsg
        }
      } catch (parseError) {
        console.error('[Steadfast] Parse error - raw text:', rawText)
        
        return {
          status: response.status,
          message: rawText.includes('inactive') || rawText.includes('not active')
            ? `Steadfast says: "${rawText}". Your account works for balance check but order creation may need additional permissions.`
            : rawText
        }
      }
    } catch (error) {
      console.error('[Steadfast] Create order error:', error)
      return {
        status: 500,
        message: 'Failed to connect to Steadfast. Please check your internet connection.'
      }
    }
  }

  /**
   * Create bulk orders (max 500 items)
   */
  async createBulkOrders(orders: BulkOrderItem[]): Promise<BulkOrderResponse[]> {
    try {
      const response = await fetch(`${this.baseUrl}/create_order/bulk-order`, {
        method: 'POST',
        headers: this.getHeaders(),
        body: JSON.stringify({ data: JSON.stringify(orders) })
      })

      const { data } = await this.parseResponse(response)
      return data || []
    } catch (error) {
      console.error('[Steadfast] Bulk order error:', error)
      return []
    }
  }

  /**
   * Check delivery status by consignment ID
   */
  async getStatusByConsignmentId(consignmentId: number): Promise<any> {
    try {
      const response = await fetch(`${this.baseUrl}/status_by_cid/${consignmentId}`, {
        method: 'GET',
        headers: this.getHeaders()
      })

      const { data, error } = await this.parseResponse(response)
      if (error) {
        console.error('[Steadfast] Get status error:', error)
        return null
      }
      return data
    } catch (error) {
      console.error('[Steadfast] Get status error:', error)
      return null
    }
  }

  /**
   * Check delivery status by invoice ID
   */
  async getStatusByInvoice(invoice: string): Promise<any> {
    try {
      const response = await fetch(`${this.baseUrl}/status_by_invoice/${invoice}`, {
        method: 'GET',
        headers: this.getHeaders()
      })

      const { data } = await this.parseResponse(response)
      return data
    } catch (error) {
      console.error('[Steadfast] Get status by invoice error:', error)
      return null
    }
  }

  /**
   * Check delivery status by tracking code
   */
  async getStatusByTrackingCode(trackingCode: string): Promise<any> {
    try {
      const response = await fetch(`${this.baseUrl}/status_by_trackingcode/${trackingCode}`, {
        method: 'GET',
        headers: this.getHeaders()
      })

      const { data } = await this.parseResponse(response)
      return data
    } catch (error) {
      console.error('[Steadfast] Get status by tracking code error:', error)
      return null
    }
  }

  /**
   * Get current balance
   */
  async getBalance(): Promise<{ status: number; current_balance: number } | null> {
    try {
      const response = await fetch(`${this.baseUrl}/get_balance`, {
        method: 'GET',
        headers: this.getHeaders()
      })

      const { data } = await this.parseResponse(response)
      return data
    } catch (error) {
      console.error('[Steadfast] Get balance error:', error)
      return null
    }
  }

  /**
   * Create a return request
   */
  async createReturnRequest(params: {
    consignment_id?: number
    invoice?: string
    tracking_code?: string
    reason?: string
  }): Promise<any> {
    try {
      const response = await fetch(`${this.baseUrl}/create_return_request`, {
        method: 'POST',
        headers: this.getHeaders(),
        body: JSON.stringify(params)
      })

      const { data } = await this.parseResponse(response)
      return data
    } catch (error) {
      console.error('[Steadfast] Create return request error:', error)
      return null
    }
  }

  /**
   * Get all return requests
   */
  async getReturnRequests(): Promise<any[] | null> {
    try {
      const response = await fetch(`${this.baseUrl}/get_return_requests`, {
        method: 'GET',
        headers: this.getHeaders()
      })

      const { data } = await this.parseResponse(response)
      return data
    } catch (error) {
      console.error('[Steadfast] Get return requests error:', error)
      return null
    }
  }

  /**
   * Get single return request by ID
   */
  async getReturnRequest(id: number): Promise<any | null> {
    try {
      const response = await fetch(`${this.baseUrl}/get_return_request/${id}`, {
        method: 'GET',
        headers: this.getHeaders()
      })

      const { data } = await this.parseResponse(response)
      return data
    } catch (error) {
      console.error('[Steadfast] Get return request error:', error)
      return null
    }
  }

  /**
   * Get payments list
   */
  async getPayments(): Promise<any[] | null> {
    try {
      const response = await fetch(`${this.baseUrl}/payments`, {
        method: 'GET',
        headers: this.getHeaders()
      })

      const { data } = await this.parseResponse(response)
      return data
    } catch (error) {
      console.error('[Steadfast] Get payments error:', error)
      return null
    }
  }

  /**
   * Get single payment with consignments
   */
  async getPaymentById(paymentId: number): Promise<any | null> {
    try {
      const response = await fetch(`${this.baseUrl}/payments/${paymentId}`, {
        method: 'GET',
        headers: this.getHeaders()
      })

      const { data } = await this.parseResponse(response)
      return data
    } catch (error) {
      console.error('[Steadfast] Get payment error:', error)
      return null
    }
  }

  /**
   * Get police stations
   */
  async getPoliceStations(): Promise<any[] | null> {
    try {
      const response = await fetch(`${this.baseUrl}/police_stations`, {
        method: 'GET',
        headers: this.getHeaders()
      })

      const { data } = await this.parseResponse(response)
      return data
    } catch (error) {
      console.error('[Steadfast] Get police stations error:', error)
      return null
    }
  }
}

// Export singleton instance
export const steadfastService = new SteadfastService()

// Export class for testing
export { SteadfastService }
