import { defineConfig } from 'drizzle-kit'

export default defineConfig({
  schema: './src/db/schema.ts',
  out: './drizzle',
  dialect: 'postgresql',
  dbCredentials: {
    url: 'postgresql://neondb_owner:npg_fpYOD6th3nBT@ep-misty-mouse-a17jt54s.ap-southeast-1.aws.neon.tech/neondb?sslmode=require',
  },
})
