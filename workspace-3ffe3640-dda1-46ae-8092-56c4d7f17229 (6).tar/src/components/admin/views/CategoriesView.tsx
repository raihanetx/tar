'use client'

import React, { useRef, useState } from 'react'
import { useAdmin } from '@/components/admin/context/AdminContext'
import type { Category } from '@/types'

export function CategoriesView() {
  const {
    categories,
    editingCategory,
    setEditingCategory,
    showToastMsg,
    refetchCategories
  } = useAdmin()

  const fileInputRef = useRef<HTMLInputElement>(null)
  const [isSaving, setIsSaving] = useState(false)
  const [isUploading, setIsUploading] = useState(false)

  const openCategoryEdit = (cat: Category | null = null) => {
    if (cat) {
      setEditingCategory({ ...cat, type: cat.type || 'icon' })
    } else {
      setEditingCategory({
        id: 'CAT-' + Date.now().toString().slice(-6),
        name: '',
        type: 'icon',
        icon: '',
        image: '',
        items: 0,
        created: 'Just now',
        status: 'Active'
      })
    }
  }

  const handleSaveCategory = async () => {
    if (!editingCategory?.name) {
      showToastMsg('Please enter a category name')
      return
    }

    setIsSaving(true)
    
    try {
      const exists = categories.find(c => c.id === editingCategory.id)
      
      if (exists) {
        const response = await fetch('/api/categories', {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            id: editingCategory.id,
            name: editingCategory.name,
            type: editingCategory.type,
            icon: editingCategory.icon,
            image: editingCategory.image,
            items: editingCategory.items,
            status: editingCategory.status
          })
        })
        
        if (response.ok) {
          showToastMsg('Category updated successfully!')
          refetchCategories()
          setEditingCategory(null)
        } else {
          showToastMsg('Failed to update category')
        }
      } else {
        const response = await fetch('/api/categories', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            id: editingCategory.id,
            name: editingCategory.name,
            type: editingCategory.type,
            icon: editingCategory.icon,
            image: editingCategory.image,
            items: editingCategory.items,
            status: editingCategory.status
          })
        })
        
        if (response.ok) {
          showToastMsg('Category created successfully!')
          refetchCategories()
          setEditingCategory(null)
        } else {
          showToastMsg('Failed to create category')
        }
      }
    } catch (error) {
      console.error('Error saving category:', error)
      showToastMsg('Error saving category')
    } finally {
      setIsSaving(false)
    }
  }

  const handleDeleteCategory = async (id: string) => {
    if (!confirm('Delete this category?')) return
    
    try {
      const response = await fetch(`/api/categories?id=${id}`, {
        method: 'DELETE'
      })
      
      if (response.ok) {
        showToastMsg('Category deleted successfully!')
        refetchCategories()
      } else {
        showToastMsg('Failed to delete category')
      }
    } catch (error) {
      console.error('Error deleting category:', error)
      showToastMsg('Error deleting category')
    }
  }

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      setIsUploading(true)
      try {
        const formData = new FormData()
        formData.append('file', file)
        formData.append('type', 'category')
        
        const response = await fetch('/api/upload', {
          method: 'POST',
          body: formData
        })
        
        const result = await response.json()
        
        if (result.success && result.url) {
          setEditingCategory({ ...editingCategory!, image: result.url })
          showToastMsg('Image uploaded successfully!')
        } else {
          showToastMsg(result.error || 'Failed to upload image')
        }
      } catch (error) {
        console.error('Error uploading image:', error)
        showToastMsg('Failed to upload image')
      } finally {
        setIsUploading(false)
      }
    }
  }

  return (
    <div className="p-4 md:p-8 bg-white min-h-[calc(100vh-80px)]" style={{ fontFamily: "'Inter', sans-serif" }}>
      {/* Header */}
      <div className="mb-6 flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-bold text-[#1c2333]">Category Management</h1>
          <p className="text-[#8a96a8] text-sm mt-1">Organize your product categories</p>
        </div>
        <div className="flex items-center gap-3">
          <span className="px-4 py-1.5 bg-[#16a34a]/10 text-[#16a34a] text-[13px] font-bold rounded-[5px]">
            {categories.length} Categories
          </span>
          <button
            onClick={() => openCategoryEdit()}
            className="inline-flex items-center gap-1.5 px-4 py-2 bg-[#16a34a] text-white rounded-[5px] text-[13px] font-semibold hover:bg-[#15803d] transition-colors"
          >
            <i className="ri-add-line text-base"></i>
            Add Category
          </button>
        </div>
      </div>

      {/* Table */}
      <div className="flex flex-col gap-2">
        {/* Header Row - Dark background */}
        <div className="grid grid-cols-6 bg-[#374151] rounded-[5px]">
          <div className="px-4 py-3 border-r border-[#4b5563] flex items-center text-[11px] font-bold uppercase tracking-wider text-white">Category</div>
          <div className="px-4 py-3 border-r border-[#4b5563] flex items-center justify-center text-[11px] font-bold uppercase tracking-wider text-white">Source</div>
          <div className="px-4 py-3 border-r border-[#4b5563] flex items-center justify-center text-[11px] font-bold uppercase tracking-wider text-white">Products</div>
          <div className="px-4 py-3 border-r border-[#4b5563] flex items-center justify-center text-[11px] font-bold uppercase tracking-wider text-white">Created</div>
          <div className="px-4 py-3 border-r border-[#4b5563] flex items-center justify-center text-[11px] font-bold uppercase tracking-wider text-white">Status</div>
          <div className="px-4 py-3 flex items-center justify-center text-[11px] font-bold uppercase tracking-wider text-white">Action</div>
        </div>

        {/* Data Rows */}
        {categories.map((cat) => (
          <div key={cat.id} className="grid grid-cols-6 bg-white rounded-[5px] border border-[#d1d5db] overflow-hidden hover:border-[#9ca3af] transition-colors">
            {/* Category */}
            <div className="px-4 py-3.5 border-r border-[#d1d5db] flex items-center gap-3">
              <div className="w-9 h-9 rounded-lg bg-[#f0fdf4] border border-[#bbf7d0] flex items-center justify-center overflow-hidden flex-shrink-0">
                {cat.type === 'icon' ? (
                  <i className={`${cat.icon} text-[#16a34a]`}></i>
                ) : (
                  <img src={cat.image} className="w-full h-full object-cover" alt={cat.name} />
                )}
              </div>
              <span className="text-[13px] font-bold text-[#1c2333] truncate">{cat.name}</span>
            </div>
            
            {/* Source */}
            <div className="px-4 py-3.5 border-r border-[#d1d5db] flex items-center justify-center">
              <span className="text-[13px] text-[#6b7280]">{cat.type === 'icon' ? 'Icon Library' : 'Image Upload'}</span>
            </div>
            
            {/* Products */}
            <div className="px-4 py-3.5 border-r border-[#d1d5db] flex items-center justify-center">
              <span className="text-[13px] font-medium text-[#1c2333]">{cat.items} Items</span>
            </div>
            
            {/* Created */}
            <div className="px-4 py-3.5 border-r border-[#d1d5db] flex items-center justify-center">
              <span className="text-[13px] text-[#6b7280]">{cat.created}</span>
            </div>
            
            {/* Status */}
            <div className="px-4 py-3.5 border-r border-[#d1d5db] flex items-center justify-center">
              <span className={`text-[13px] font-medium ${cat.status === 'Active' ? 'text-[#16a34a]' : 'text-[#9ca3af]'}`}>
                [{cat.status}]
              </span>
            </div>
            
            {/* Action */}
            <div className="px-4 py-3.5 flex items-center justify-center gap-2">
              <button
                onClick={() => openCategoryEdit(cat)}
                className="p-1.5 text-[#8a96a8] hover:text-[#f59e0b] hover:bg-[#f59e0b]/10 rounded transition-colors"
              >
                <i className="ri-pencil-line text-[16px]"></i>
              </button>
              <button
                onClick={() => handleDeleteCategory(cat.id)}
                className="p-1.5 text-[#8a96a8] hover:text-[#ef4444] hover:bg-[#ef4444]/10 rounded transition-colors"
              >
                <i className="ri-delete-bin-line text-[16px]"></i>
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Edit Category Modal */}
      {editingCategory && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-6 bg-[#1c2333]/40 backdrop-blur-sm" onClick={() => setEditingCategory(null)}>
          <div className="w-full max-w-[500px] bg-white border border-[#e4e7ee] rounded-xl shadow-lg" onClick={e => e.stopPropagation()}>
            {/* Modal Header */}
            <div className="flex items-center justify-between px-5 py-4 border-b border-[#e4e7ee]">
              <h2 className="text-lg font-bold text-[#1c2333]">
                {categories.find(c => c.id === editingCategory.id) ? 'Edit Category' : 'Add New Category'}
              </h2>
              <button onClick={() => setEditingCategory(null)} className="text-[#8a96a8] hover:text-[#1c2333]">
                <i className="ri-close-line text-xl"></i>
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-5">
              {/* Category Type */}
              <div className="mb-4">
                <label className="block text-[13px] font-medium text-[#6b7280] mb-2">Category Type</label>
                <div className="flex gap-4">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input 
                      type="radio" 
                      name="catType" 
                      checked={editingCategory.type === 'icon'}
                      onChange={() => setEditingCategory({ ...editingCategory, type: 'icon' })}
                      className="w-4 h-4 accent-[#16a34a]"
                    />
                    <span className="text-[13px] text-[#374151]">Icon</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input 
                      type="radio" 
                      name="catType" 
                      checked={editingCategory.type === 'image'}
                      onChange={() => setEditingCategory({ ...editingCategory, type: 'image' })}
                      className="w-4 h-4 accent-[#16a34a]"
                    />
                    <span className="text-[13px] text-[#374151]">Image</span>
                  </label>
                </div>
              </div>

              {/* Category Name */}
              <div className="mb-4">
                <label className="block text-[13px] font-medium text-[#6b7280] mb-1">Category Name</label>
                <input 
                  type="text" 
                  className="w-full px-3 py-2.5 bg-white border border-[#e4e7ee] rounded-lg text-[13px] text-[#1c2333] outline-none focus:border-[#16a34a] transition-colors" 
                  placeholder="category name"
                  value={editingCategory.name}
                  onChange={(e) => setEditingCategory({ ...editingCategory, name: e.target.value })}
                />
              </div>

              {/* Icon Input */}
              {editingCategory.type === 'icon' && (
                <div className="mb-4">
                  <label className="block text-[13px] font-medium text-[#6b7280] mb-1">Icon Code (Remix Icon)</label>
                  <div className="flex gap-2">
                    <input 
                      type="text" 
                      className="flex-1 px-3 py-2.5 bg-white border border-[#e4e7ee] rounded-lg text-[13px] text-[#1c2333] outline-none focus:border-[#16a34a] transition-colors" 
                      placeholder="ri-leaf-line"
                      value={editingCategory.icon || ''}
                      onChange={(e) => setEditingCategory({ ...editingCategory, icon: e.target.value })}
                    />
                    <div className={`w-11 h-11 rounded-lg flex items-center justify-center flex-shrink-0 border-2 transition-colors ${
                      editingCategory.icon ? 'border-[#16a34a] bg-[#f0fdf4]' : 'border-[#e4e7ee] bg-[#f9fafb]'
                    }`}>
                      {editingCategory.icon ? (
                        <i className={`${editingCategory.icon} text-xl text-[#16a34a]`}></i>
                      ) : (
                        <i className="ri-image-line text-lg text-[#9ca3af]"></i>
                      )}
                    </div>
                  </div>
                  <p className="text-[12px] text-[#6b7280] mt-1">Use Remix Icon codes. Example: ri-leaf-line, ri-shopping-basket-line</p>
                </div>
              )}

              {/* Image Upload */}
              {editingCategory.type === 'image' && (
                <div className="mb-4">
                  <label className="block text-[13px] font-medium text-[#6b7280] mb-1">Category Image</label>
                  <input
                    type="file"
                    ref={fileInputRef}
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="hidden"
                  />
                  <div 
                    onClick={() => !isUploading && fileInputRef.current?.click()}
                    className={`border-2 border-dashed rounded-lg p-4 text-center cursor-pointer transition-colors ${
                      isUploading 
                        ? 'border-[#e4e7ee] bg-[#f9fafb] cursor-wait' 
                        : editingCategory.image
                          ? 'border-[#16a34a] bg-[#f0fdf4]'
                          : 'border-[#e4e7ee] hover:border-[#16a34a] hover:bg-[#f0fdf4]'
                    }`}
                  >
                    {isUploading ? (
                      <div className="flex flex-col items-center gap-2">
                        <i className="ri-loader-4-line text-2xl text-[#16a34a] animate-spin"></i>
                        <span className="text-[13px] text-[#16a34a] font-medium">Uploading...</span>
                      </div>
                    ) : editingCategory.image ? (
                      <div className="flex flex-col items-center gap-2">
                        <img 
                          src={editingCategory.image} 
                          alt="Preview" 
                          className="w-16 h-16 rounded-lg object-cover border-2 border-[#16a34a]" 
                        />
                        <span className="text-[13px] text-[#16a34a] font-medium">Click to change image</span>
                      </div>
                    ) : (
                      <div className="flex flex-col items-center gap-2">
                        <i className="ri-upload-cloud-2-line text-2xl text-[#16a34a]"></i>
                        <span className="text-[13px] text-[#6b7280]">Click to upload image</span>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Buttons */}
              <div className="flex gap-3 mt-6">
                <button 
                  onClick={() => setEditingCategory(null)}
                  className="flex-1 py-2.5 bg-white text-[#6b7280] border border-[#e4e7ee] rounded-lg text-[13px] font-semibold hover:bg-[#f5f6f9] transition-colors"
                >
                  Cancel
                </button>
                <button 
                  onClick={handleSaveCategory}
                  disabled={isSaving}
                  className="flex-1 py-2.5 bg-[#16a34a] text-white rounded-lg text-[13px] font-semibold hover:bg-[#15803d] transition-colors disabled:opacity-50"
                >
                  {isSaving ? 'Saving...' : 'Save Category'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default CategoriesView
