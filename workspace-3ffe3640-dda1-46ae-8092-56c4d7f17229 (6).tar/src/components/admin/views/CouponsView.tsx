'use client'

import React from 'react'
import type { Coupon } from '@/types'
import { useAdmin } from '@/components/admin/context/AdminContext'

export function CouponsView() {
  const {
    coupons,
    setCoupons,
    editingCoupon,
    setEditingCoupon,
    couponForm,
    setCouponForm,
    pickedProducts,
    setPickedProducts,
    pickedCategories,
    setPickedCategories,
    couponProducts,
    couponCategories,
    showToastMsg,
    refetchCoupons,
  } = useAdmin()

  const openCouponEdit = (coupon: Coupon | null = null) => {
    if (coupon && coupon.id) {
      setCouponForm({
        code: coupon.code,
        type: coupon.type,
        value: coupon.value.toString(),
        expiry: coupon.expiry,
        scope: coupon.scope,
      })
      setPickedProducts(coupon.selectedProducts || [])
      setPickedCategories(coupon.selectedCategories || [])
      setEditingCoupon(coupon)
    } else {
      setCouponForm({ code: '', type: 'pct', value: '', expiry: '', scope: 'all' })
      setPickedProducts([])
      setPickedCategories([])
      setEditingCoupon({ id: '', code: '', type: 'pct', value: 0, scope: 'all', expiry: '' })
    }
  }

  const handleSaveCoupon = async () => {
    if (!couponForm.code.trim()) { showToastMsg('Please enter a coupon code.'); return }
    if (!couponForm.value.trim()) { showToastMsg('Please enter a discount value.'); return }

    const couponData = {
      code: couponForm.code.toUpperCase(),
      type: couponForm.type,
      value: parseFloat(couponForm.value),
      scope: couponForm.scope,
      expiry: couponForm.expiry || null,
      selectedProducts: couponForm.scope === 'products' ? pickedProducts : undefined,
      selectedCategories: couponForm.scope === 'categories' ? pickedCategories : undefined,
    }

    try {
      if (editingCoupon?.id) {
        const response = await fetch('/api/coupons', {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ id: editingCoupon.id, ...couponData }),
        })
        const result = await response.json()
        if (result.success) {
          showToastMsg('Coupon updated!')
          await refetchCoupons()
        } else {
          showToastMsg(result.error || 'Failed to update coupon')
        }
      } else {
        const response = await fetch('/api/coupons', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(couponData),
        })
        const result = await response.json()
        if (result.success) {
          showToastMsg('Coupon added!')
          await refetchCoupons()
        } else {
          showToastMsg(result.error || 'Failed to create coupon')
        }
      }
    } catch (error) {
      showToastMsg('Error saving coupon')
    }
    
    setEditingCoupon(null)
  }

  const deleteCoupon = async (id: string) => {
    try {
      const response = await fetch(`/api/coupons?id=${id}`, {
        method: 'DELETE',
      })
      const result = await response.json()
      if (result.success) {
        setCoupons(coupons.filter(c => c.id !== id))
        showToastMsg('Coupon deleted!')
      } else {
        showToastMsg('Failed to delete coupon')
      }
    } catch (error) {
      showToastMsg('Error deleting coupon')
    }
  }

  const toggleProductPick = (id: number) => {
    if (pickedProducts.includes(id)) {
      setPickedProducts(pickedProducts.filter(p => p !== id))
    } else {
      setPickedProducts([...pickedProducts, id])
    }
  }

  const toggleCategoryPick = (name: string) => {
    if (pickedCategories.includes(name)) {
      setPickedCategories(pickedCategories.filter(c => c !== name))
    } else {
      setPickedCategories([...pickedCategories, name])
    }
  }

  const formatExpiry = (expiry: string) => {
    if (!expiry) return '[Not Applied]'
    const d = new Date(expiry + 'T00:00:00')
    return `[${d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}]`
  }

  return (
    <div className="p-4 md:p-8 bg-white min-h-[calc(100vh-80px)]" style={{ fontFamily: "'Inter', sans-serif" }}>
      {/* Header */}
      <div className="mb-6 flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-bold text-[#1c2333]">Coupon Management</h1>
          <p className="text-[#8a96a8] text-sm mt-1">Create and manage discount coupons</p>
        </div>
        <div className="flex items-center gap-3">
          <span className="px-4 py-1.5 bg-[#16a34a]/10 text-[#16a34a] text-[13px] font-bold rounded-[5px]">
            {coupons.length} Coupons
          </span>
          <button
            onClick={() => openCouponEdit()}
            className="inline-flex items-center gap-1.5 px-4 py-2 bg-[#16a34a] text-white rounded-[5px] text-[13px] font-semibold hover:bg-[#15803d] transition-colors"
          >
            <i className="ri-add-line text-base"></i>
            Add Coupon
          </button>
        </div>
      </div>

      {/* Table */}
      <div className="flex flex-col gap-2">
        {/* Header Row - Dark background */}
        <div className="grid grid-cols-6 bg-[#374151] rounded-[5px]">
          <div className="px-4 py-3 border-r border-[#4b5563] flex items-center text-[11px] font-bold uppercase tracking-wider text-white">Code</div>
          <div className="px-4 py-3 border-r border-[#4b5563] flex items-center justify-center text-[11px] font-bold uppercase tracking-wider text-white">Type</div>
          <div className="px-4 py-3 border-r border-[#4b5563] flex items-center justify-center text-[11px] font-bold uppercase tracking-wider text-white">Discount</div>
          <div className="px-4 py-3 border-r border-[#4b5563] flex items-center justify-center text-[11px] font-bold uppercase tracking-wider text-white">Applies To</div>
          <div className="px-4 py-3 border-r border-[#4b5563] flex items-center justify-center text-[11px] font-bold uppercase tracking-wider text-white">Expiry</div>
          <div className="px-4 py-3 flex items-center justify-center text-[11px] font-bold uppercase tracking-wider text-white">Action</div>
        </div>

        {/* Data Rows */}
        {coupons.map((coupon) => (
          <div key={coupon.id} className="grid grid-cols-6 bg-white rounded-[5px] border border-[#d1d5db] overflow-hidden hover:border-[#9ca3af] transition-colors">
            {/* Code */}
            <div className="px-4 py-3.5 border-r border-[#d1d5db] flex items-center">
              <span className="text-[13px] font-bold text-[#1c2333] tracking-wider">{coupon.code}</span>
            </div>
            
            {/* Type */}
            <div className="px-4 py-3.5 border-r border-[#d1d5db] flex items-center justify-center">
              <span className={`text-[13px] font-medium ${coupon.type === 'pct' ? 'text-[#f59e0b]' : 'text-[#16a34a]'}`}>
                [{coupon.type === 'pct' ? '% Percentage' : '$ Fixed'}]
              </span>
            </div>
            
            {/* Discount */}
            <div className="px-4 py-3.5 border-r border-[#d1d5db] flex items-center justify-center">
              <span className={`text-[13px] font-medium ${coupon.type === 'pct' ? 'text-[#f59e0b]' : 'text-[#16a34a]'}`}>
                [{coupon.type === 'pct' ? `${coupon.value}% Off` : `$${coupon.value} Off`}]
              </span>
            </div>
            
            {/* Applies To */}
            <div className="px-4 py-3.5 border-r border-[#d1d5db] flex items-center justify-center">
              <span className={`text-[13px] font-medium ${coupon.scope === 'all' ? 'text-[#16a34a]' : 'text-[#f59e0b]'}`}>
                [{coupon.scope === 'all' ? 'All Products' : coupon.scope === 'products' ? 'Specific Products' : 'Specific Categories'}]
              </span>
            </div>
            
            {/* Expiry */}
            <div className="px-4 py-3.5 border-r border-[#d1d5db] flex items-center justify-center">
              <span className="text-[13px] font-medium text-[#8a96a8]">{formatExpiry(coupon.expiry)}</span>
            </div>
            
            {/* Action */}
            <div className="px-4 py-3.5 flex items-center justify-center gap-2">
              <button
                onClick={() => openCouponEdit(coupon)}
                className="p-1.5 text-[#8a96a8] hover:text-[#f59e0b] hover:bg-[#f59e0b]/10 rounded transition-colors"
              >
                <i className="ri-pencil-line text-[16px]"></i>
              </button>
              <button
                onClick={() => deleteCoupon(coupon.id)}
                className="p-1.5 text-[#8a96a8] hover:text-[#ef4444] hover:bg-[#ef4444]/10 rounded transition-colors"
              >
                <i className="ri-delete-bin-line text-[16px]"></i>
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Edit Coupon Modal */}
      {editingCoupon && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-6 bg-[#1c2333]/40 backdrop-blur-sm" onClick={() => setEditingCoupon(null)}>
          <div className="w-full max-w-[560px] max-h-[90vh] overflow-y-auto bg-white border border-[#e4e7ee] rounded-xl shadow-lg" onClick={e => e.stopPropagation()}>
            {/* Modal Header */}
            <div className="flex items-center justify-between px-5 py-4 border-b border-[#e4e7ee]">
              <h2 className="text-lg font-bold text-[#1c2333]">
                {editingCoupon.id ? 'Edit Coupon' : 'Add New Coupon'}
              </h2>
              <button onClick={() => setEditingCoupon(null)} className="text-[#8a96a8] hover:text-[#1c2333]">
                <i className="ri-close-line text-xl"></i>
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-5">
              <form onSubmit={(e) => { e.preventDefault(); handleSaveCoupon(); }}>
                {/* Coupon Details */}
                <div className="mb-5">
                  <h3 className="text-[11px] font-bold uppercase tracking-wider text-[#6b7280] mb-3">Coupon Details</h3>

                  <div className="mb-3">
                    <label className="block text-[13px] font-medium text-[#6b7280] mb-1">Coupon Code</label>
                    <input 
                      type="text" 
                      className="w-full px-3 py-2.5 bg-white border border-[#e4e7ee] rounded-lg text-[13px] text-[#1c2333] outline-none focus:border-[#16a34a] transition-colors uppercase tracking-wider" 
                      placeholder="SUMMER20"
                      value={couponForm.code}
                      onChange={(e) => setCouponForm({...couponForm, code: e.target.value.toUpperCase()})} 
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3 mb-3">
                    <div>
                      <label className="block text-[13px] font-medium text-[#6b7280] mb-1">Coupon Type</label>
                      <select 
                        className="w-full px-3 py-2.5 bg-white border border-[#e4e7ee] rounded-lg text-[13px] text-[#1c2333] outline-none appearance-none cursor-pointer focus:border-[#16a34a] transition-colors"
                        value={couponForm.type}
                        onChange={(e) => setCouponForm({...couponForm, type: e.target.value as 'pct' | 'fixed'})}
                      >
                        <option value="pct">% Percentage Off</option>
                        <option value="fixed">$ Fixed Amount Off</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-[13px] font-medium text-[#6b7280] mb-1">
                        {couponForm.type === 'pct' ? 'Discount %' : 'Discount $'}
                      </label>
                      <div className="relative">
                        <span className={`absolute left-3 top-1/2 -translate-y-1/2 font-bold text-sm ${couponForm.type === 'pct' ? 'text-[#f59e0b]' : 'text-[#16a34a]'}`}>
                          {couponForm.type === 'pct' ? '%' : '$'}
                        </span>
                        <input 
                          type="number" 
                          className="w-full px-3 py-2.5 pl-7 bg-white border border-[#e4e7ee] rounded-lg text-[13px] text-[#1c2333] outline-none focus:border-[#16a34a] transition-colors" 
                          placeholder={couponForm.type === 'pct' ? '20' : '15'}
                          value={couponForm.value}
                          onChange={(e) => setCouponForm({...couponForm, value: e.target.value})}
                          min="1" 
                        />
                      </div>
                    </div>
                  </div>

                  <div>
                    <label className="block text-[13px] font-medium text-[#6b7280] mb-1">
                      Expiry Date <span className="text-[11px] font-normal text-[#9ca3af]">(optional)</span>
                    </label>
                    <input 
                      type="date" 
                      className="w-full px-3 py-2.5 bg-white border border-[#e4e7ee] rounded-lg text-[13px] text-[#1c2333] outline-none focus:border-[#16a34a] transition-colors" 
                      value={couponForm.expiry}
                      onChange={(e) => setCouponForm({...couponForm, expiry: e.target.value})} 
                    />
                  </div>
                </div>

                {/* Applies To */}
                <div className="mb-5">
                  <h3 className="text-[11px] font-bold uppercase tracking-wider text-[#6b7280] mb-3">Applies To</h3>

                  <div className="mb-3">
                    <label className="block text-[13px] font-medium text-[#6b7280] mb-1">Scope</label>
                    <select 
                      className="w-full px-3 py-2.5 bg-white border border-[#e4e7ee] rounded-lg text-[13px] text-[#1c2333] outline-none appearance-none cursor-pointer focus:border-[#16a34a] transition-colors"
                      value={couponForm.scope}
                      onChange={(e) => setCouponForm({...couponForm, scope: e.target.value as 'all' | 'products' | 'categories'})}
                    >
                      <option value="all">All Products</option>
                      <option value="products">Specific Products</option>
                      <option value="categories">Specific Categories</option>
                    </select>
                  </div>

                  {/* Product Picker */}
                  {couponForm.scope === 'products' && (
                    <div className="pt-3 border-t border-[#e4e7ee]">
                      <div className="text-[11px] font-bold uppercase tracking-wider text-[#9ca3af] mb-2">Select Products</div>
                      <div className="grid grid-cols-2 gap-2 max-h-48 overflow-y-auto">
                        {couponProducts.map(p => (
                          <div 
                            key={p.id} 
                            onClick={() => toggleProductPick(p.id)}
                            className={`flex items-center gap-2 p-2 rounded-lg cursor-pointer transition-all border ${
                              pickedProducts.includes(p.id) 
                                ? 'border-[#16a34a] bg-[#f0fdf4]' 
                                : 'border-[#e4e7ee] hover:border-[#9ca3af]'
                            }`}
                          >
                            <img src={p.img} alt={p.name} className="w-9 h-9 rounded-md object-cover flex-shrink-0" />
                            <div className="flex-1 min-w-0">
                              <div className="text-[12px] font-semibold text-[#1c2333] truncate">{p.name}</div>
                              <div className="text-[11px] text-[#16a34a] font-semibold">{p.price}</div>
                            </div>
                            <div className={`w-4 h-4 rounded flex items-center justify-center flex-shrink-0 ${
                              pickedProducts.includes(p.id) 
                                ? 'bg-[#16a34a] text-white' 
                                : 'border-2 border-[#d1d5db]'
                            }`}>
                              {pickedProducts.includes(p.id) && <span className="text-[10px]">✓</span>}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Category Picker */}
                  {couponForm.scope === 'categories' && (
                    <div className="pt-3 border-t border-[#e4e7ee]">
                      <div className="text-[11px] font-bold uppercase tracking-wider text-[#9ca3af] mb-2">Select Categories</div>
                      <div className="flex flex-wrap gap-2">
                        {couponCategories.map(cat => (
                          <div 
                            key={cat.name}
                            onClick={() => toggleCategoryPick(cat.name)}
                            className={`inline-flex items-center gap-1.5 px-4 py-2 rounded-lg cursor-pointer text-[12px] font-medium transition-all border ${
                              pickedCategories.includes(cat.name) 
                                ? 'border-[#16a34a] bg-[#f0fdf4] text-[#16a34a]' 
                                : 'border-[#e4e7ee] hover:border-[#9ca3af]'
                            }`}
                          >
                            <span className="w-2 h-2 rounded-full flex-shrink-0" style={{background: cat.color}}></span>
                            {cat.name}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {/* Buttons */}
                <div className="flex gap-3 pt-4 border-t border-[#e4e7ee]">
                  <button 
                    type="button" 
                    onClick={() => setEditingCoupon(null)} 
                    className="flex-1 py-2.5 bg-white text-[#6b7280] border border-[#e4e7ee] rounded-lg text-[13px] font-semibold hover:bg-[#f5f6f9] transition-colors"
                  >
                    Cancel
                  </button>
                  <button 
                    type="submit" 
                    className="flex-1 py-2.5 bg-[#16a34a] text-white rounded-lg text-[13px] font-semibold hover:bg-[#15803d] transition-colors"
                  >
                    Save Coupon
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default CouponsView
