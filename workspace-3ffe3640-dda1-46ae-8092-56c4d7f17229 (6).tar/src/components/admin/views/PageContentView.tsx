'use client'

import React, { useState, useRef, useEffect } from 'react'
import { useAdmin } from '@/components/admin/context/AdminContext'

const PageContentView: React.FC = () => {
  const { settings, setSettings, showToastMsg, refetchSettings } = useAdmin()
  
  const [aboutUs, setAboutUs] = useState('')
  const [termsConditions, setTermsConditions] = useState('')
  const [refundPolicy, setRefundPolicy] = useState('')
  const [privacyPolicy, setPrivacyPolicy] = useState('')
  const [saving, setSaving] = useState(false)
  
  const syncedRef = useRef(false)

  useEffect(() => {
    if (!syncedRef.current) {
      setAboutUs(settings.aboutUs ?? '')
      setTermsConditions(settings.termsConditions ?? '')
      setRefundPolicy(settings.refundPolicy ?? '')
      setPrivacyPolicy(settings.privacyPolicy ?? '')
      syncedRef.current = true
    }
  }, [settings])

  const handleSaveContent = async () => {
    setSaving(true)
    try {
      const response = await fetch('/api/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...settings,
          aboutUs,
          termsConditions,
          refundPolicy,
          privacyPolicy,
        }),
      })
      
      const result = await response.json()
      
      if (result.success) {
        await refetchSettings()
        showToastMsg('Page content saved successfully!')
      } else {
        showToastMsg('Failed to save content')
      }
    } catch (error) {
      console.error('Error saving content:', error)
      showToastMsg('Error saving content')
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="p-4 md:p-8 bg-white min-h-[calc(100vh-80px)]" style={{ fontFamily: "'Inter', sans-serif" }}>
      {/* Header */}
      <div className="mb-6 flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-bold text-[#1c2333]">Page Content</h1>
          <p className="text-[#8a96a8] text-sm mt-1">Manage your store's page content and policies</p>
        </div>
        <button
          onClick={handleSaveContent}
          disabled={saving}
          className="inline-flex items-center gap-1.5 px-4 py-2 bg-[#16a34a] text-white rounded-[5px] text-[13px] font-semibold hover:bg-[#15803d] transition-colors disabled:opacity-50"
        >
          <i className="ri-save-line text-base"></i>
          {saving ? 'Saving...' : 'Save All Content'}
        </button>
      </div>

      {/* Content Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* About Us Card */}
        <div className="bg-white border border-[#e4e7ee] rounded-xl overflow-hidden">
          <div className="px-5 py-4 border-b border-[#e4e7ee] flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-[#16a34a]/10 flex items-center justify-center">
              <i className="ri-building-line text-lg text-[#16a34a]"></i>
            </div>
            <div>
              <h3 className="text-sm font-bold text-[#1c2333]">About Us</h3>
              <p className="text-[11px] text-[#8a96a8]">Tell customers about your business</p>
            </div>
          </div>
          <div className="p-5">
            <textarea
              placeholder="Write about your company, mission, and values..."
              value={aboutUs}
              onChange={(e) => setAboutUs(e.target.value)}
              className="w-full px-3 py-2.5 bg-white border border-[#e4e7ee] rounded-lg text-[13px] text-[#1c2333] outline-none focus:border-[#16a34a] transition-colors min-h-[150px] resize-y"
            />
          </div>
        </div>

        {/* Terms & Conditions Card */}
        <div className="bg-white border border-[#e4e7ee] rounded-xl overflow-hidden">
          <div className="px-5 py-4 border-b border-[#e4e7ee] flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-[#f59e0b]/10 flex items-center justify-center">
              <i className="ri-file-list-3-line text-lg text-[#f59e0b]"></i>
            </div>
            <div>
              <h3 className="text-sm font-bold text-[#1c2333]">Terms & Conditions</h3>
              <p className="text-[11px] text-[#8a96a8]">Rules and guidelines for using your service</p>
            </div>
          </div>
          <div className="p-5">
            <textarea
              placeholder="Define your terms of service, usage rules, and policies..."
              value={termsConditions}
              onChange={(e) => setTermsConditions(e.target.value)}
              className="w-full px-3 py-2.5 bg-white border border-[#e4e7ee] rounded-lg text-[13px] text-[#1c2333] outline-none focus:border-[#16a34a] transition-colors min-h-[150px] resize-y"
            />
          </div>
        </div>

        {/* Refund Policy Card */}
        <div className="bg-white border border-[#e4e7ee] rounded-xl overflow-hidden">
          <div className="px-5 py-4 border-b border-[#e4e7ee] flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-[#ef4444]/10 flex items-center justify-center">
              <i className="ri-exchange-line text-lg text-[#ef4444]"></i>
            </div>
            <div>
              <h3 className="text-sm font-bold text-[#1c2333]">Refund Policy</h3>
              <p className="text-[11px] text-[#8a96a8]">Return and refund guidelines for customers</p>
            </div>
          </div>
          <div className="p-5">
            <textarea
              placeholder="Explain your refund and return policies..."
              value={refundPolicy}
              onChange={(e) => setRefundPolicy(e.target.value)}
              className="w-full px-3 py-2.5 bg-white border border-[#e4e7ee] rounded-lg text-[13px] text-[#1c2333] outline-none focus:border-[#16a34a] transition-colors min-h-[150px] resize-y"
            />
          </div>
        </div>

        {/* Privacy Policy Card */}
        <div className="bg-white border border-[#e4e7ee] rounded-xl overflow-hidden">
          <div className="px-5 py-4 border-b border-[#e4e7ee] flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-[#8b5cf6]/10 flex items-center justify-center">
              <i className="ri-shield-user-line text-lg text-[#8b5cf6]"></i>
            </div>
            <div>
              <h3 className="text-sm font-bold text-[#1c2333]">Privacy Policy</h3>
              <p className="text-[11px] text-[#8a96a8]">How you handle and protect customer data</p>
            </div>
          </div>
          <div className="p-5">
            <textarea
              placeholder="Describe how you collect, use, and protect customer information..."
              value={privacyPolicy}
              onChange={(e) => setPrivacyPolicy(e.target.value)}
              className="w-full px-3 py-2.5 bg-white border border-[#e4e7ee] rounded-lg text-[13px] text-[#1c2333] outline-none focus:border-[#16a34a] transition-colors min-h-[150px] resize-y"
            />
          </div>
        </div>
      </div>
    </div>
  )
}

export default PageContentView
