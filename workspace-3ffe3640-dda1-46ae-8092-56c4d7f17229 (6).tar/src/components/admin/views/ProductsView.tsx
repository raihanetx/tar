'use client'

import React, { useEffect, useState } from 'react'
import type { Product } from '@/types'
import { useAdmin } from '@/components/admin/context/AdminContext'

export default function ProductsView() {
  const {
    products,
    setProducts,
    editingProduct,
    setEditingProduct,
    prodVarieties,
    setProdVarieties,
    prodFaqs,
    setProdFaqs,
    prodImages,
    setProdImages,
    prodRelated,
    setProdRelated,
    allRelatedOptions,
    showToastMsg,
    refetchProducts,
  } = useAdmin()
  
  const [uploadingImages, setUploadingImages] = useState(false)
  const [productFilter, setProductFilter] = useState<'all' | 'active' | 'inactive'>('all')

  // Filter products based on status
  const filteredProducts = productFilter === 'all' 
    ? products 
    : products.filter(p => p.status === productFilter)

  // Load variants when editingProduct changes
  useEffect(() => {
    const loadVariants = async () => {
      if (editingProduct && typeof editingProduct.id === 'number') {
        try {
          const response = await fetch(`/api/variants?productId=${editingProduct.id}`)
          const result = await response.json()
          if (result.success && result.data) {
            setProdVarieties(result.data.map((v: any) => {
              let discountStr = ''
              if (v.discountValue && parseFloat(v.discountValue) > 0) {
                discountStr = v.discountType === 'pct' ? `${v.discountValue}%` : v.discountValue.toString()
              }
              return {
                id: v.id,
                name: v.name || '',
                price: v.price?.toString() || '',
                stock: v.stock?.toString() || '',
                discount: discountStr,
                discountType: (v.discountType || 'pct') as 'pct' | 'fixed',
                discountValue: (v.discountValue || 0).toString()
              }
            }))
          }
        } catch (error) {
          console.error('Error loading variants:', error)
        }
      }
    }
    loadVariants()
  }, [editingProduct?.id, setProdVarieties])

  // Load images when editingProduct changes
  useEffect(() => {
    const loadImages = async () => {
      if (editingProduct && typeof editingProduct.id === 'number') {
        try {
          const response = await fetch(`/api/product-images?productId=${editingProduct.id}`)
          const result = await response.json()
          if (result.success && result.data && result.data.length > 0) {
            setProdImages(result.data.map((img: any) => img.url))
          }
        } catch (error) {
          console.error('Error loading images:', error)
        }
      }
    }
    loadImages()
  }, [editingProduct?.id, setProdImages])

  // Load FAQs when editingProduct changes
  useEffect(() => {
    const loadFaqs = async () => {
      if (editingProduct && typeof editingProduct.id === 'number') {
        try {
          const response = await fetch(`/api/product-faqs?productId=${editingProduct.id}`)
          const result = await response.json()
          if (result.success && result.data) {
            setProdFaqs(result.data.map((faq: any) => ({
              id: faq.id,
              question: faq.question || '',
              answer: faq.answer || ''
            })))
          }
        } catch (error) {
          console.error('Error loading FAQs:', error)
        }
      }
    }
    loadFaqs()
  }, [editingProduct?.id, setProdFaqs])

  // Load related products when editingProduct changes
  useEffect(() => {
    const loadRelated = async () => {
      if (editingProduct && typeof editingProduct.id === 'number') {
        try {
          const response = await fetch(`/api/related-products?productId=${editingProduct.id}`)
          const result = await response.json()
          if (result.success && result.data) {
            setProdRelated(result.data.map((r: any) => r.relatedProductId))
          }
        } catch (error) {
          console.error('Error loading related products:', error)
        }
      }
    }
    loadRelated()
  }, [editingProduct?.id, setProdRelated])

  // Get categories from context
  const { categories } = useAdmin()

  // Product Functions
  const openProductEdit = async (prod: Product | null = null) => {
    if (prod) {
      setEditingProduct({ ...prod, shortDesc: prod.shortDesc || '', longDesc: prod.longDesc || '', offerSwitch: prod.offer })
    } else {
      setEditingProduct({
        id: Date.now(), name: '', category: '', image: 'https://via.placeholder.com/80', variants: '0 variants', price: '$0.00', discount: '0%', offer: false, status: 'active', shortDesc: '', longDesc: '', offerSwitch: false
      })
    }
    setProdVarieties([])
    setProdFaqs([])
    setProdImages([])
    setProdRelated([])
  }

  const handleSaveProduct = async () => {
    if (!editingProduct?.name) { showToastMsg('Please enter product name'); return }
    
    try {
      const existingInDb = products.find(p => p.id === editingProduct.id)
      const isNewProduct = !existingInDb || typeof existingInDb.id === 'string'
      
      const price = prodVarieties.length > 0 ? parseFloat(prodVarieties[0].price) || 0 : 0
      const discount = prodVarieties.length > 0 ? prodVarieties[0].discount || '0%' : '0%'
      
      const productData = {
        name: editingProduct.name,
        category: editingProduct.category,
        image: prodImages.length > 0 ? prodImages[0] : editingProduct.image,
        price: price,
        discount: discount,
        offer: editingProduct.offerSwitch || false,
        status: editingProduct.status || 'active',
        shortDesc: editingProduct.shortDesc || '',
        longDesc: editingProduct.longDesc || '',
      }
      
      let savedProductId = editingProduct.id
      
      if (isNewProduct) {
        const response = await fetch('/api/products', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(productData),
        })
        const result = await response.json()
        if (result.success) {
          savedProductId = result.data.id
          showToastMsg('Product Created Successfully!')
          await refetchProducts()
        } else {
          showToastMsg('Failed to create product')
          return
        }
      } else {
        const response = await fetch('/api/products', {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ id: editingProduct.id, ...productData }),
        })
        const result = await response.json()
        if (result.success) {
          showToastMsg('Product Updated Successfully!')
          await refetchProducts()
        } else {
          showToastMsg('Failed to update product')
          return
        }
      }
      
      if (prodVarieties.length > 0 && savedProductId) {
        await fetch(`/api/variants?productId=${savedProductId}`, { method: 'DELETE' })
        await fetch('/api/variants', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(prodVarieties.map(v => ({
            name: v.name,
            stock: parseInt(v.stock) || 0,
            initialStock: parseInt(v.stock) || 0,
            price: parseFloat(v.price) || 0,
            discount: v.discountValue ? `${v.discountValue}${v.discountType === 'pct' ? '%' : ''}` : '0%',
            discountType: v.discountType || 'pct',
            discountValue: parseFloat(v.discountValue) || 0,
            productId: savedProductId
          })))
        })
      }
      
      if (savedProductId) {
        await fetch(`/api/product-images?productId=${savedProductId}`, { method: 'DELETE' })
        if (prodImages.length > 0) {
          await fetch('/api/product-images', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(prodImages.map((url, index) => ({
              url: url,
              sortOrder: index,
              productId: savedProductId
            })))
          })
        }
      }
      
      if (savedProductId) {
        await fetch(`/api/product-faqs?productId=${savedProductId}`, { method: 'DELETE' })
        if (prodFaqs.length > 0) {
          await fetch('/api/product-faqs', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(prodFaqs.filter(f => f.question && f.answer).map((faq, index) => ({
              question: faq.question,
              answer: faq.answer,
              sortOrder: index,
              productId: savedProductId
            })))
          })
        }
      }
      
      if (savedProductId) {
        await fetch(`/api/related-products?productId=${savedProductId}`, { method: 'DELETE' })
        if (prodRelated.length > 0) {
          await fetch('/api/related-products', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(prodRelated.map((relatedProductId, index) => ({
              relatedProductId: relatedProductId,
              sortOrder: index,
              productId: savedProductId
            })))
          })
        }
      }
    } catch (error) {
      showToastMsg('Error saving product')
    }
    
    setEditingProduct(null)
  }

  const toggleProdStatus = async (id: number) => {
    const product = products.find(p => p.id === id)
    if (!product) return
    
    const newStatus = product.status === 'active' ? 'inactive' : 'active'
    setProducts(products.map(p => p.id === id ? { ...p, status: newStatus } : p))
    
    try {
      const response = await fetch('/api/products', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, status: newStatus }),
      })
      const result = await response.json()
      if (!result.success) {
        setProducts(products.map(p => p.id === id ? { ...p, status: product.status } : p))
        showToastMsg('Failed to update status')
      }
    } catch (error) {
      setProducts(products.map(p => p.id === id ? { ...p, status: product.status } : p))
      showToastMsg('Error updating status')
    }
  }

  const deleteProduct = async (id: number) => {
    try {
      const response = await fetch(`/api/products?id=${id}`, {
        method: 'DELETE',
      })
      const result = await response.json()
      if (result.success) {
        setProducts(products.filter(p => p.id !== id))
        showToastMsg('Product deleted successfully')
      } else {
        showToastMsg('Failed to delete product')
      }
    } catch (error) {
      showToastMsg('Error deleting product')
    }
  }

  const addVariety = () => setProdVarieties(prev => [...prev, { id: Date.now(), name: '', price: '', stock: '', discount: '', discountType: 'pct', discountValue: '' }])
  const addFaq = () => setProdFaqs(prev => [...prev, { id: Date.now(), question: '', answer: '' }])
  const removeVariety = (id: number) => setProdVarieties(prev => prev.filter(v => v.id !== id))
  const removeFaq = (id: number) => setProdFaqs(prev => prev.filter(f => f.id !== id))
  const updateVariety = (id: number, field: 'name' | 'price' | 'stock' | 'discount' | 'discountType' | 'discountValue', value: string) => {
    setProdVarieties(prev => prev.map(v => {
      if (v.id !== id) return v
      if (field === 'discount') {
        const hasPercent = value.includes('%')
        const numValue = value.replace('%', '').trim()
        return {
          ...v,
          discount: value,
          discountType: hasPercent ? 'pct' : 'fixed',
          discountValue: numValue
        }
      }
      return {...v, [field]: value}
    }))
  }
  const updateFaq = (id: number, field: 'question' | 'answer', value: string) => {
    setProdFaqs(prev => prev.map(f => f.id === id ? {...f, [field]: value} : f))
  }
  const toggleRelated = (id: number) => {
    if (prodRelated.includes(id)) setProdRelated(prodRelated.filter(i => i !== id))
    else if (prodRelated.length < 4) setProdRelated([...prodRelated, id])
  }

  return (
    <div className="p-4 md:p-8 bg-white min-h-[calc(100vh-80px)]" style={{ fontFamily: "'Inter', sans-serif" }}>
      {/* Header */}
      <div className="mb-6 flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-bold text-[#1c2333]">Product Management</h1>
          <p className="text-[#8a96a8] text-sm mt-1">Manage your product catalog</p>
        </div>
        <div className="flex items-center gap-3">
          <span className="px-4 py-1.5 bg-[#16a34a]/10 text-[#16a34a] text-[13px] font-bold rounded-[5px]">
            {products.length} Products
          </span>
          <button
            onClick={() => openProductEdit()}
            className="inline-flex items-center gap-1.5 px-4 py-2 bg-[#16a34a] text-white rounded-[5px] text-[13px] font-semibold hover:bg-[#15803d] transition-colors"
          >
            <i className="ri-add-line text-base"></i>
            Add Product
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="mb-4 flex gap-2 flex-wrap">
        {[
          { id: 'all', label: 'All', color: '#1c2333' },
          { id: 'active', label: 'Active', color: '#16a34a' },
          { id: 'inactive', label: 'Inactive', color: '#ef4444' },
        ].map(f => (
          <button key={f.id} onClick={() => setProductFilter(f.id as typeof productFilter)}
            className={`px-4 py-2 text-[13px] font-semibold rounded-[5px] border transition-colors ${
              productFilter === f.id
                ? `text-white`
                : 'bg-white text-[#8a96a8] border-[#e4e7ee] hover:bg-[#f5f6f9]'
            }`}
            style={productFilter === f.id ? { backgroundColor: f.color, borderColor: f.color } : {}}
          >
            {f.label}
          </button>
        ))}
      </div>

      {/* Table */}
      <div className="flex flex-col gap-2">
        {/* Header Row - Dark background */}
        <div className="grid grid-cols-7 bg-[#374151] rounded-[5px]">
          <div className="px-4 py-3 border-r border-[#4b5563] flex items-center text-[11px] font-bold uppercase tracking-wider text-white">Product Details</div>
          <div className="px-4 py-3 border-r border-[#4b5563] flex items-center justify-center text-[11px] font-bold uppercase tracking-wider text-white">Variants</div>
          <div className="px-4 py-3 border-r border-[#4b5563] flex items-center justify-center text-[11px] font-bold uppercase tracking-wider text-white">Price</div>
          <div className="px-4 py-3 border-r border-[#4b5563] flex items-center justify-center text-[11px] font-bold uppercase tracking-wider text-white">Discount</div>
          <div className="px-4 py-3 border-r border-[#4b5563] flex items-center justify-center text-[11px] font-bold uppercase tracking-wider text-white">Offer</div>
          <div className="px-4 py-3 border-r border-[#4b5563] flex items-center justify-center text-[11px] font-bold uppercase tracking-wider text-white">Status</div>
          <div className="px-4 py-3 flex items-center justify-center text-[11px] font-bold uppercase tracking-wider text-white">Action</div>
        </div>

        {/* Data Rows */}
        {filteredProducts.map((prod) => (
          <div key={prod.id} className="grid grid-cols-7 bg-white rounded-[5px] border border-[#d1d5db] overflow-hidden hover:border-[#9ca3af] transition-colors">
            {/* Product Details */}
            <div className="px-4 py-3.5 border-r border-[#d1d5db] flex items-center gap-3">
              <img src={prod.image} alt={prod.name} className="w-10 h-10 rounded-lg object-cover flex-shrink-0" />
              <div className="min-w-0">
                <span className="text-[13px] font-bold text-[#1c2333] block truncate">{prod.name}</span>
                <span className="text-[11px] text-[#8a96a8] block truncate">{prod.category}</span>
              </div>
            </div>
            
            {/* Variants */}
            <div className="px-4 py-3.5 border-r border-[#d1d5db] flex items-center justify-center">
              <span className="text-[13px] text-[#6b7280]">{prod.variants}</span>
            </div>
            
            {/* Price */}
            <div className="px-4 py-3.5 border-r border-[#d1d5db] flex items-center justify-center">
              <span className="text-[13px] font-bold text-[#16a34a]">{prod.price}</span>
            </div>
            
            {/* Discount */}
            <div className="px-4 py-3.5 border-r border-[#d1d5db] flex items-center justify-center">
              <span className="text-[13px] font-medium text-[#ef4444]">[{prod.discount}]</span>
            </div>
            
            {/* Offer */}
            <div className="px-4 py-3.5 border-r border-[#d1d5db] flex items-center justify-center">
              <span className={`text-[13px] font-medium ${prod.offer ? 'text-[#3b82f6]' : 'text-[#9ca3af]'}`}>
                [{prod.offer ? 'Yes' : 'No'}]
              </span>
            </div>
            
            {/* Status */}
            <div className="px-4 py-3.5 border-r border-[#d1d5db] flex items-center justify-center">
              <button
                onClick={() => toggleProdStatus(prod.id)}
                className={`relative w-11 h-6 rounded-full transition-colors ${prod.status === 'active' ? 'bg-[#16a34a]' : 'bg-[#d1d5db]'}`}
              >
                <span className={`absolute top-1 w-4 h-4 bg-white rounded-full shadow transition-transform ${prod.status === 'active' ? 'left-6' : 'left-1'}`} />
              </button>
            </div>
            
            {/* Action */}
            <div className="px-4 py-3.5 flex items-center justify-center gap-2">
              <button
                onClick={() => openProductEdit(prod)}
                className="p-1.5 text-[#8a96a8] hover:text-[#f59e0b] hover:bg-[#f59e0b]/10 rounded transition-colors"
              >
                <i className="ri-pencil-line text-[16px]"></i>
              </button>
              <button
                onClick={() => deleteProduct(prod.id)}
                className="p-1.5 text-[#8a96a8] hover:text-[#ef4444] hover:bg-[#ef4444]/10 rounded transition-colors"
              >
                <i className="ri-delete-bin-line text-[16px]"></i>
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Edit Product Modal */}
      {editingProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-6 bg-[#1c2333]/40 backdrop-blur-sm" onClick={() => setEditingProduct(null)}>
          <div className="w-full max-w-[720px] max-h-[90vh] overflow-y-auto bg-white border border-[#e4e7ee] rounded-xl shadow-lg p-5" onClick={e => e.stopPropagation()}>
            {/* Modal Header */}
            <div className="flex items-center justify-between mb-4 pb-4 border-b border-[#e4e7ee]">
              <h2 className="text-lg font-bold text-[#1c2333]">
                {products.find(p => p.id === editingProduct.id) ? 'Edit Product' : 'Add New Product'}
              </h2>
              <button onClick={() => setEditingProduct(null)} className="text-[#8a96a8] hover:text-[#1c2333]">
                <i className="ri-close-line text-xl"></i>
              </button>
            </div>

            <form onSubmit={(e) => { e.preventDefault(); handleSaveProduct(); }}>
              {/* Basic Information */}
              <div className="mb-5">
                <h3 className="text-sm font-semibold text-[#1c2333] mb-3">Basic Information</h3>
                <div className="space-y-3">
                  <div>
                    <label className="block text-[13px] font-medium text-[#6b7280] mb-1">Product Name</label>
                    <input 
                      type="text" 
                      className="w-full px-3 py-2.5 bg-white border border-[#e4e7ee] rounded-lg text-[13px] text-[#1c2333] outline-none focus:border-[#16a34a] transition-colors" 
                      placeholder="Organic Red Apples" 
                      value={editingProduct.name} 
                      onChange={(e) => setEditingProduct({...editingProduct, name: e.target.value})} 
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[13px] font-medium text-[#6b7280] mb-1">Category</label>
                      <select 
                        className="w-full px-3 py-2.5 bg-white border border-[#e4e7ee] rounded-lg text-[13px] text-[#1c2333] outline-none focus:border-[#16a34a] transition-colors" 
                        value={editingProduct.category} 
                        onChange={(e) => setEditingProduct({...editingProduct, category: e.target.value})}
                      >
                        <option value="">Select Category</option>
                        {categories.filter(c => c.status === 'Active').map((cat) => (
                          <option key={cat.id} value={cat.name}>{cat.name}</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="block text-[13px] font-medium text-[#6b7280] mb-1">Offer Product</label>
                      <button
                        type="button"
                        onClick={() => setEditingProduct({...editingProduct, offerSwitch: !editingProduct.offerSwitch})}
                        className={`w-full px-3 py-2.5 rounded-lg text-[13px] font-medium text-left flex items-center justify-between border transition-colors ${
                          editingProduct.offerSwitch 
                            ? 'border-[#16a34a] bg-[#f0fdf4] text-[#16a34a]' 
                            : 'border-[#e4e7ee] text-[#6b7280]'
                        }`}
                      >
                        {editingProduct.offerSwitch ? 'Yes, this is an offer' : 'No, regular price'}
                        <span className={`w-5 h-5 rounded-full flex items-center justify-center ${editingProduct.offerSwitch ? 'bg-[#16a34a] text-white' : 'bg-[#e4e7ee]'}`}>
                          {editingProduct.offerSwitch && <i className="ri-check-line text-xs"></i>}
                        </span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Descriptions */}
              <div className="mb-5">
                <h3 className="text-sm font-semibold text-[#1c2333] mb-3">Descriptions</h3>
                <div className="space-y-3">
                  <div>
                    <label className="block text-[13px] font-medium text-[#6b7280] mb-1">Short Description</label>
                    <textarea 
                      className="w-full px-3 py-2.5 bg-white border border-[#e4e7ee] rounded-lg text-[13px] text-[#1c2333] outline-none focus:border-[#16a34a] transition-colors resize-vertical" 
                      rows={2} 
                      placeholder="Fresh and organic" 
                      value={editingProduct.shortDesc || ''} 
                      onChange={(e) => setEditingProduct({...editingProduct, shortDesc: e.target.value})}
                    ></textarea>
                  </div>
                  <div>
                    <label className="block text-[13px] font-medium text-[#6b7280] mb-1">Long Description</label>
                    <textarea 
                      className="w-full px-3 py-2.5 bg-white border border-[#e4e7ee] rounded-lg text-[13px] text-[#1c2333] outline-none focus:border-[#16a34a] transition-colors resize-vertical" 
                      rows={4} 
                      placeholder="Describe the product..." 
                      value={editingProduct.longDesc || ''} 
                      onChange={(e) => setEditingProduct({...editingProduct, longDesc: e.target.value})}
                    ></textarea>
                  </div>
                </div>
              </div>

              {/* Product Images */}
              <div className="mb-5">
                <h3 className="text-sm font-semibold text-[#1c2333] mb-3">Product Images</h3>
                
                <input 
                  type="file" 
                  id="prodImgUp" 
                  style={{display: 'none'}} 
                  accept="image/*"
                  multiple
                  onChange={async (e) => {
                    const files = e.target.files
                    if (!files || files.length === 0) return
                    
                    const remainingSlots = 5 - prodImages.length
                    if (remainingSlots <= 0) {
                      showToastMsg('Maximum 5 images allowed!')
                      return
                    }
                    
                    setUploadingImages(true)
                    const filesToProcess = Math.min(files.length, remainingSlots)
                    const uploadedUrls: string[] = []
                    
                    for (let i = 0; i < filesToProcess; i++) {
                      const file = files[i]
                      try {
                        const formData = new FormData()
                        formData.append('file', file)
                        formData.append('type', 'product')
                        
                        const response = await fetch('/api/upload', {
                          method: 'POST',
                          body: formData
                        })
                        const result = await response.json()
                        
                        if (result.success && result.url) {
                          uploadedUrls.push(result.url)
                        } else {
                          showToastMsg(`Failed to upload ${file.name}`)
                        }
                      } catch (error) {
                        console.error('Upload error:', error)
                        showToastMsg(`Error uploading ${file.name}`)
                      }
                    }
                    
                    if (uploadedUrls.length > 0) {
                      setProdImages(prev => [...prev, ...uploadedUrls].slice(0, 5))
                    }
                    
                    setUploadingImages(false)
                    e.target.value = ''
                  }}
                  disabled={uploadingImages || prodImages.length >= 5}
                />
                
                <div 
                  onClick={() => !uploadingImages && prodImages.length < 5 && document.getElementById('prodImgUp')?.click()}
                  className={`border-2 border-dashed rounded-lg p-4 text-center cursor-pointer transition-colors ${
                    uploadingImages || prodImages.length >= 5 
                      ? 'border-[#e4e7ee] bg-[#f9fafb] cursor-not-allowed' 
                      : 'border-[#e4e7ee] hover:border-[#16a34a] hover:bg-[#f0fdf4]'
                  }`}
                >
                  {uploadingImages ? (
                    <div className="flex flex-col items-center gap-2">
                      <i className="ri-loader-4-line text-2xl text-[#16a34a] animate-spin"></i>
                      <span className="text-[13px] text-[#6b7280]">Uploading...</span>
                    </div>
                  ) : (
                    <div className="flex flex-col items-center gap-2">
                      <i className="ri-upload-cloud-2-line text-2xl text-[#9ca3af]"></i>
                      <span className="text-[13px] text-[#6b7280]">
                        {prodImages.length >= 5 ? 'Maximum images reached' : 'Click to upload images'}
                      </span>
                    </div>
                  )}
                </div>
                
                {/* Image Grid */}
                <div className="grid grid-cols-5 gap-2 mt-3">
                  {[1, 2, 3, 4, 5].map((slot) => {
                    const img = prodImages[slot - 1]
                    return (
                      <div key={slot} className={`relative aspect-square rounded-lg overflow-hidden border-2 ${
                        img ? (slot === 1 ? 'border-[#16a34a]' : 'border-[#e4e7ee]') : 'border-dashed border-[#d1d5db]'
                      }`}>
                        {img ? (
                          <>
                            <img src={img} className="w-full h-full object-cover" alt="" />
                            {slot === 1 && (
                              <span className="absolute top-1 left-1 px-1.5 py-0.5 bg-white/95 rounded text-[9px] text-[#16a34a] font-semibold shadow">Primary</span>
                            )}
                            <button
                              type="button"
                              onClick={() => setProdImages(prodImages.filter((_, idx) => idx !== slot - 1))}
                              className="absolute top-1 right-1 w-5 h-5 bg-white/95 rounded flex items-center justify-center text-[#ef4444] hover:bg-[#ef4444] hover:text-white transition-colors"
                            >
                              <i className="ri-close-line text-xs"></i>
                            </button>
                          </>
                        ) : (
                          <div 
                            onClick={() => !uploadingImages && document.getElementById('prodImgUp')?.click()}
                            className="w-full h-full flex flex-col items-center justify-center cursor-pointer"
                          >
                            <i className="ri-add-line text-lg text-[#9ca3af]"></i>
                          </div>
                        )}
                      </div>
                    )
                  })}
                </div>
              </div>

              {/* Varieties & Pricing */}
              <div className="mb-5">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-sm font-semibold text-[#1c2333]">Varieties & Pricing</h3>
                  <button type="button" onClick={addVariety} className="text-[13px] font-medium text-[#16a34a] hover:underline">+ Add Variety</button>
                </div>
                
                {prodVarieties.length === 0 && (
                  <div className="text-center py-6 text-[#9ca3af] border border-dashed border-[#e4e7ee] rounded-lg bg-[#f9fafb]">
                    No varieties added yet
                  </div>
                )}
                
                {prodVarieties.map((v) => (
                  <div key={v.id} className="flex gap-2 items-center mb-2 p-3 bg-[#f9fafb] rounded-lg border border-[#f0f0f0]">
                    <input 
                      type="text" 
                      className="flex-2 px-3 py-2 bg-white border border-[#e4e7ee] rounded-lg text-[13px] font-medium outline-none focus:border-[#16a34a]" 
                      placeholder="Variety (e.g. 1kg)" 
                      value={v.name}
                      onChange={(e) => updateVariety(v.id, 'name', e.target.value)}
                    />
                    <input 
                      type="number" 
                      className="flex-1 px-3 py-2 bg-white border border-[#e4e7ee] rounded-lg text-[13px] outline-none focus:border-[#16a34a]" 
                      placeholder="Price" 
                      value={v.price}
                      onChange={(e) => updateVariety(v.id, 'price', e.target.value)}
                    />
                    <input 
                      type="number" 
                      className="flex-1 px-3 py-2 bg-white border border-[#e4e7ee] rounded-lg text-[13px] outline-none focus:border-[#16a34a]" 
                      placeholder="Stock" 
                      value={v.stock}
                      onChange={(e) => updateVariety(v.id, 'stock', e.target.value)}
                    />
                    <input 
                      type="text" 
                      className="flex-1 px-3 py-2 bg-white border border-[#e4e7ee] rounded-lg text-[13px] outline-none focus:border-[#16a34a]" 
                      placeholder="Discount" 
                      value={v.discount}
                      onChange={(e) => updateVariety(v.id, 'discount', e.target.value)}
                    />
                    <button
                      type="button"
                      onClick={() => removeVariety(v.id)}
                      className="p-2 text-[#ef4444] hover:bg-[#ef4444]/10 rounded-lg transition-colors"
                    >
                      <i className="ri-delete-bin-line text-[16px]"></i>
                    </button>
                  </div>
                ))}
              </div>

              {/* FAQs */}
              <div className="mb-5">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-sm font-semibold text-[#1c2333]">FAQs</h3>
                  <button type="button" onClick={addFaq} className="text-[13px] font-medium text-[#16a34a] hover:underline">+ Add FAQ</button>
                </div>
                
                {prodFaqs.length === 0 && (
                  <div className="text-center py-6 text-[#9ca3af] border border-dashed border-[#e4e7ee] rounded-lg bg-[#f9fafb]">
                    No FAQs added yet
                  </div>
                )}
                
                {prodFaqs.map((f, i) => (
                  <div key={f.id} className="flex gap-2 items-start mb-2 p-3 bg-[#f9fafb] rounded-lg border border-[#f0f0f0]">
                    <span className="w-6 h-6 rounded bg-[#16a34a] text-white flex items-center justify-center text-xs font-semibold flex-shrink-0">{i + 1}</span>
                    <div className="flex-1 space-y-2">
                      <input 
                        type="text" 
                        className="w-full px-3 py-2 bg-white border border-[#e4e7ee] rounded-lg text-[13px] outline-none focus:border-[#16a34a]" 
                        placeholder="Question" 
                        value={f.question}
                        onChange={(e) => updateFaq(f.id, 'question', e.target.value)}
                      />
                      <input 
                        type="text" 
                        className="w-full px-3 py-2 bg-white border border-[#e4e7ee] rounded-lg text-[13px] outline-none focus:border-[#16a34a]" 
                        placeholder="Answer" 
                        value={f.answer}
                        onChange={(e) => updateFaq(f.id, 'answer', e.target.value)}
                      />
                    </div>
                    <button
                      type="button"
                      onClick={() => removeFaq(f.id)}
                      className="p-2 text-[#9ca3af] hover:text-[#ef4444] hover:bg-[#ef4444]/10 rounded-lg transition-colors"
                    >
                      <i className="ri-delete-bin-line text-[16px]"></i>
                    </button>
                  </div>
                ))}
              </div>

              {/* Related Products */}
              <div className="mb-5">
                <h3 className="text-sm font-semibold text-[#1c2333] mb-1">Related Products</h3>
                <p className="text-[12px] text-[#6b7280] mb-3">Select up to 4 related products to display</p>
                
                <div className="grid grid-cols-3 gap-2 max-h-48 overflow-y-auto">
                  {allRelatedOptions.filter(p => p.id !== editingProduct?.id).map(p => (
                    <div 
                      key={p.id} 
                      onClick={() => toggleRelated(p.id)}
                      className={`p-2 rounded-lg cursor-pointer transition-all flex gap-2 items-center ${
                        prodRelated.includes(p.id) 
                          ? 'border-2 border-[#16a34a] bg-[#f0fdf4]' 
                          : 'border border-[#e4e7ee] hover:border-[#9ca3af]'
                      }`}
                    >
                      <img src={p.image} alt={p.name} className="w-10 h-10 rounded-lg object-cover flex-shrink-0" />
                      <div className="min-w-0 flex-1">
                        <p className="text-[12px] font-medium text-[#1c2333] truncate">{p.name}</p>
                        <span className="text-[11px] text-[#16a34a] font-semibold">TK {p.price}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Buttons */}
              <div className="flex gap-3 pt-4 border-t border-[#e4e7ee]">
                <button 
                  type="button" 
                  onClick={() => setEditingProduct(null)} 
                  className="flex-1 py-2.5 bg-white text-[#6b7280] border border-[#e4e7ee] rounded-lg text-[13px] font-semibold hover:bg-[#f5f6f9] transition-colors"
                >
                  Cancel
                </button>
                <button 
                  type="submit" 
                  className="flex-1 py-2.5 bg-[#16a34a] text-white rounded-lg text-[13px] font-semibold hover:bg-[#15803d] transition-colors"
                >
                  Save Product
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}
