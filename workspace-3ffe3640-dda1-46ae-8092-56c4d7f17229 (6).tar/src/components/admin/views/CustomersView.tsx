'use client'

import React from 'react'
import { useAdmin } from '@/components/admin/context/AdminContext'
import type { AbandonedProduct } from '@/types'

const CustomersView: React.FC = () => {
  const { customerProfiles, expandedCustomer, setExpandedCustomer, showToastMsg } = useAdmin()

  const getInitials = (name: string) => name.split(' ').map(w => w[0]).join('').toUpperCase()

  const buildEntries = (products: AbandonedProduct[]) => {
    const entries: { name: string; variant: string | null; qty: number }[] = []
    products.forEach(p => p.variants.forEach(v => entries.push({ name: p.name, variant: v.label, qty: v.qty })))
    return entries
  }

  const getOrdinal = (n: number) => {
    const s = ["th", "st", "nd", "rd"]
    const v = n % 100
    return s[(v - 20) % 10] || s[v] || s[0]
  }

  const copyToClipboardLocal = (text: string) => {
    navigator.clipboard.writeText(text)
    showToastMsg('Number copied!')
  }

  const toggleCustomerExpand = (id: number) => {
    setExpandedCustomer(expandedCustomer === id ? null : id)
  }

  return (
    <div className="p-4 md:p-8 bg-white min-h-[calc(100vh-80px)]" style={{ fontFamily: "'Inter', sans-serif" }}>
      {/* Header */}
      <div className="mb-6 flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-bold text-[#1c2333]">Customer Management</h1>
          <p className="text-[#8a96a8] text-sm mt-1">Overview of customer orders and spending</p>
        </div>
        <div className="flex items-center gap-3">
          <span className="px-4 py-1.5 bg-[#16a34a]/10 text-[#16a34a] text-[13px] font-bold rounded-[5px] flex items-center gap-1.5">
            <i className="ri-user-follow-line"></i>
            {customerProfiles.length} Active
          </span>
        </div>
      </div>

      {/* Table */}
      <div className="flex flex-col gap-2">
        {/* Header Row - Dark background */}
        <div className="grid grid-cols-4 bg-[#374151] rounded-[5px]">
          <div className="px-4 py-3 border-r border-[#4b5563] flex items-center text-[11px] font-bold uppercase tracking-wider text-white">Customer</div>
          <div className="px-4 py-3 border-r border-[#4b5563] flex items-center justify-center text-[11px] font-bold uppercase tracking-wider text-white">Address</div>
          <div className="px-4 py-3 border-r border-[#4b5563] flex items-center justify-center text-[11px] font-bold uppercase tracking-wider text-white">Overview</div>
          <div className="px-4 py-3 flex items-center justify-center text-[11px] font-bold uppercase tracking-wider text-white">Actions</div>
        </div>

        {/* Data Rows */}
        {customerProfiles.map((cust) => (
          <React.Fragment key={cust.id}>
            {/* Main Row */}
            <div 
              className="grid grid-cols-4 bg-white rounded-[5px] border border-[#d1d5db] overflow-hidden hover:border-[#9ca3af] transition-colors cursor-pointer"
              onClick={() => toggleCustomerExpand(cust.id)}
            >
              {/* Customer */}
              <div className="px-4 py-3.5 border-r border-[#d1d5db] flex items-center gap-3">
                <div className="w-9 h-9 rounded-full bg-[#d1fae5] border-2 border-[#16a34a] flex items-center justify-center flex-shrink-0">
                  <span className="text-[13px] font-bold text-[#16a34a]">{getInitials(cust.name)}</span>
                </div>
                <div className="min-w-0">
                  <span className="text-[13px] font-bold text-[#1c2333] block truncate">{cust.name}</span>
                  <span className="text-[11px] text-[#8a96a8] block truncate">{cust.phone}</span>
                </div>
              </div>
              
              {/* Address */}
              <div className="px-4 py-3.5 border-r border-[#d1d5db] flex items-center">
                <span className="text-[13px] text-[#6b7280] truncate">{cust.address}</span>
              </div>
              
              {/* Overview */}
              <div className="px-4 py-3.5 border-r border-[#d1d5db] flex items-center">
                <div>
                  <span className="text-[13px] font-medium text-[#1c2333] block">Total {cust.totalOrders} Orders</span>
                  <span className="text-[11px] text-[#8a96a8] block">Spent ${cust.totalSpent.toFixed(2)}</span>
                </div>
              </div>
              
              {/* Actions */}
              <div className="px-4 py-3.5 flex items-center justify-between">
                <div className="flex items-center gap-1" onClick={e => e.stopPropagation()}>
                  <button 
                    onClick={() => window.location.href = `tel:${cust.phone}`}
                    className="p-1.5 text-[#8a96a8] hover:text-[#16a34a] hover:bg-[#16a34a]/10 rounded transition-colors"
                  >
                    <i className="ri-phone-line text-[16px]"></i>
                  </button>
                  <button 
                    onClick={() => copyToClipboardLocal(cust.phone)}
                    className="p-1.5 text-[#8a96a8] hover:text-[#1c2333] hover:bg-[#f5f6f9] rounded transition-colors"
                  >
                    <i className="ri-file-copy-line text-[16px]"></i>
                  </button>
                  <button 
                    onClick={() => window.open(`https://wa.me/${cust.phone.replace('+', '')}`, '_blank')}
                    className="p-1.5 text-[#8a96a8] hover:text-[#16a34a] hover:bg-[#16a34a]/10 rounded transition-colors"
                  >
                    <i className="ri-whatsapp-line text-[16px]"></i>
                  </button>
                </div>
                <i 
                  className={`ri-arrow-down-s-line text-[20px] text-[#6b7280] transition-transform ${expandedCustomer === cust.id ? 'rotate-180' : ''}`}
                ></i>
              </div>
            </div>

            {/* Expanded Row */}
            {expandedCustomer === cust.id && (
              <div className="bg-white rounded-[5px] border border-[#d1d5db] border-t-0 rounded-t-none overflow-hidden">
                <div className="p-4">
                  <div className="flex flex-col gap-2">
                    {cust.orders.map((o, idx) => {
                      const entries = buildEntries(o.products)
                      const totalItems = entries.reduce((acc, e) => acc + e.qty, 0)
                      
                      return (
                        <div 
                          key={idx} 
                          className="flex items-start gap-4 p-3 bg-[#f9fafb] rounded-lg hover:bg-[#f5f6f9] transition-colors"
                        >
                          {/* Date */}
                          <div className="w-32 flex-shrink-0">
                            <span className="text-[13px] font-medium text-[#1c2333] block">{o.date}</span>
                            <span className="text-[11px] text-[#8a96a8]">
                              <span className="text-[#16a34a] font-semibold">{o.visitCount}{getOrdinal(o.visitCount)}</span> visit
                            </span>
                          </div>
                          
                          {/* Products */}
                          <div className="flex-1 flex flex-wrap items-baseline gap-x-1 gap-y-0.5">
                            {entries.map((e, i) => {
                              const isLast = i === entries.length - 1
                              return (
                                <span key={i} className="text-[13px] text-[#6b7280]">
                                  <span className="text-[#1c2333] font-medium">{e.name}</span>
                                  {e.variant && <span className="text-[11px]"> ({e.variant})</span>}
                                  <span className="text-[#16a34a] font-bold text-[12px]"> ×{e.qty}</span>
                                  {!isLast && <span className="text-[#d1d5db] mx-1.5">|</span>}
                                </span>
                              )
                            })}
                          </div>
                          
                          {/* Total */}
                          <div className="w-24 text-right flex-shrink-0">
                            <span className="text-[14px] font-bold text-[#16a34a]">${o.total.toFixed(2)}</span>
                            <span className="text-[11px] text-[#8a96a8] block">(Total {totalItems} items)</span>
                          </div>
                        </div>
                      )
                    })}
                  </div>
                </div>
              </div>
            )}
          </React.Fragment>
        ))}
      </div>
    </div>
  )
}

export default CustomersView
