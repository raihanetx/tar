'use client'

import React, { useState, useRef, useEffect } from 'react'
import { useAdmin } from '@/components/admin/context/AdminContext'

const SettingsView: React.FC = () => {
  const { settings, setSettings, showToastMsg, refetchSettings } = useAdmin()
  
  const [universalDelivery, setUniversalDelivery] = useState(false)
  const [universalDeliveryCharge, setUniversalDeliveryCharge] = useState(60)
  const [offerTitle, setOfferTitle] = useState('')
  const [offerSlogan, setOfferSlogan] = useState('')
  const [uploading, setUploading] = useState<string | null>(null)
  const [heroImages, setHeroImages] = useState<string[]>([])
  const [saving, setSaving] = useState(false)
  
  const syncedRef = useRef(false)
  const logoInputRef = useRef<HTMLInputElement>(null)
  const faviconInputRef = useRef<HTMLInputElement>(null)
  const heroInputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    if (!syncedRef.current) {
      setUniversalDelivery(settings.universalDelivery ?? false)
      setUniversalDeliveryCharge(settings.universalDeliveryCharge ?? 60)
      setOfferTitle(settings.offerTitle ?? 'Offers')
      setOfferSlogan(settings.offerSlogan ?? 'Exclusive deals just for you')
      
      if (settings.heroImages) {
        try {
          const parsed = typeof settings.heroImages === 'string' 
            ? JSON.parse(settings.heroImages) 
            : settings.heroImages
          setHeroImages(Array.isArray(parsed) ? parsed : [])
        } catch {
          setHeroImages([])
        }
      }
      syncedRef.current = true
    }
  }, [settings])

  const uploadImage = async (file: File, type: string): Promise<string | null> => {
    setUploading(type)
    try {
      const formData = new FormData()
      formData.append('file', file)
      formData.append('type', type)

      const response = await fetch('/api/upload', {
        method: 'POST',
        body: formData
      })

      const result = await response.json()
      
      if (result.success) {
        return result.url
      } else {
        showToastMsg(result.error || 'Upload failed')
        return null
      }
    } catch (error) {
      console.error('Upload error:', error)
      showToastMsg('Failed to upload image')
      return null
    } finally {
      setUploading(null)
    }
  }

  const saveField = async (field: string, value: string) => {
    try {
      const response = await fetch('/api/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...settings,
          [field]: value,
          heroImages: JSON.stringify(heroImages),
        }),
      })
      const result = await response.json()
      if (result.success) {
        await refetchSettings()
        return true
      }
      return false
    } catch (error) {
      console.error('Error saving:', error)
      return false
    }
  }

  const handleLogoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    
    const url = await uploadImage(file, 'logo')
    if (url) {
      const newSettings = { ...settings, logoUrl: url }
      setSettings(newSettings)
      const saved = await saveField('logoUrl', url)
      showToastMsg(saved ? 'Logo saved!' : 'Failed to save logo')
    }
  }

  const handleFaviconUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    
    const url = await uploadImage(file, 'favicon')
    if (url) {
      const newSettings = { ...settings, faviconUrl: url }
      setSettings(newSettings)
      const saved = await saveField('faviconUrl', url)
      showToastMsg(saved ? 'Favicon saved!' : 'Failed to save favicon')
    }
  }

  const handleHeroUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (!files || files.length === 0) return
    
    setUploading('hero')
    const newUrls: string[] = []
    
    for (let i = 0; i < files.length; i++) {
      const url = await uploadImage(files[i], `hero-${i}`)
      if (url) newUrls.push(url)
    }
    
    if (newUrls.length > 0) {
      const updated = [...heroImages, ...newUrls]
      setHeroImages(updated)
      try {
        await fetch('/api/settings', {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            ...settings,
            heroImages: JSON.stringify(updated),
          }),
        })
        await refetchSettings()
        showToastMsg(`${newUrls.length} hero image(s) saved!`)
      } catch {
        showToastMsg('Failed to save hero images')
      }
    }
    setUploading(null)
  }

  const removeHeroImage = async (index: number) => {
    const updated = heroImages.filter((_, i) => i !== index)
    setHeroImages(updated)
    try {
      await fetch('/api/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...settings,
          heroImages: JSON.stringify(updated),
        }),
      })
      await refetchSettings()
      showToastMsg('Image removed')
    } catch {
      showToastMsg('Failed to remove image')
    }
  }

  const handleSaveSettings = async () => {
    setSaving(true)
    try {
      const response = await fetch('/api/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          websiteName: settings.websiteName,
          slogan: settings.slogan,
          logoUrl: settings.logoUrl,
          faviconUrl: settings.faviconUrl,
          heroImages: JSON.stringify(heroImages),
          insideDhakaDelivery: settings.insideDhakaDelivery,
          outsideDhakaDelivery: settings.outsideDhakaDelivery,
          freeDeliveryMin: settings.freeDeliveryMin,
          universalDelivery: universalDelivery,
          universalDeliveryCharge: universalDeliveryCharge,
          whatsappNumber: settings.whatsappNumber,
          phoneNumber: settings.phoneNumber,
          facebookUrl: settings.facebookUrl,
          messengerUsername: settings.messengerUsername,
          offerTitle: offerTitle,
          offerSlogan: offerSlogan,
          aboutUs: settings.aboutUs,
          termsConditions: settings.termsConditions,
          refundPolicy: settings.refundPolicy,
          privacyPolicy: settings.privacyPolicy,
        }),
      })
      
      const result = await response.json()
      
      if (result.success) {
        await refetchSettings()
        showToastMsg('Settings saved! Refreshing...')
        setTimeout(() => {
          window.location.reload()
        }, 2000)
      } else {
        showToastMsg('Failed to save settings')
      }
    } catch (error) {
      console.error('Error saving settings:', error)
      showToastMsg('Error saving settings')
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="p-4 md:p-8 bg-white min-h-[calc(100vh-80px)]" style={{ fontFamily: "'Inter', sans-serif" }}>
      {/* Header */}
      <div className="mb-6 flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-bold text-[#1c2333]">Settings</h1>
          <p className="text-[#8a96a8] text-sm mt-1">Configure your store settings</p>
        </div>
        <button
          onClick={handleSaveSettings}
          disabled={saving}
          className="inline-flex items-center gap-1.5 px-4 py-2 bg-[#16a34a] text-white rounded-[5px] text-[13px] font-semibold hover:bg-[#15803d] transition-colors disabled:opacity-50"
        >
          <i className="ri-save-line text-base"></i>
          {saving ? 'Saving...' : 'Save All Changes'}
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left Column */}
        <div className="space-y-6">
          {/* Store Branding Card */}
          <div className="bg-white border border-[#e4e7ee] rounded-xl overflow-hidden">
            <div className="px-5 py-4 border-b border-[#e4e7ee] flex items-center gap-3">
              <div className="w-9 h-9 rounded-lg bg-[#16a34a]/10 flex items-center justify-center">
                <i className="ri-medal-line text-lg text-[#16a34a]"></i>
              </div>
              <h3 className="text-sm font-bold text-[#1c2333]">Store Branding</h3>
            </div>
            <div className="p-5 space-y-4">
              <div>
                <label className="block text-[13px] font-medium text-[#6b7280] mb-1">Website Name</label>
                <input 
                  type="text" 
                  className="w-full px-3 py-2.5 bg-white border border-[#e4e7ee] rounded-lg text-[13px] text-[#1c2333] outline-none focus:border-[#16a34a] transition-colors" 
                  placeholder="EcoMart"
                  value={settings.websiteName || ''}
                  onChange={(e) => setSettings({...settings, websiteName: e.target.value})}
                />
              </div>
              <div>
                <label className="block text-[13px] font-medium text-[#6b7280] mb-1">Slogan</label>
                <input 
                  type="text" 
                  className="w-full px-3 py-2.5 bg-white border border-[#e4e7ee] rounded-lg text-[13px] text-[#1c2333] outline-none focus:border-[#16a34a] transition-colors" 
                  placeholder="Freshness at your door"
                  value={settings.slogan || ''}
                  onChange={(e) => setSettings({...settings, slogan: e.target.value})}
                />
              </div>
              
              {/* Logo Upload */}
              <div>
                <label className="block text-[13px] font-medium text-[#6b7280] mb-1">Logo</label>
                <div className="flex items-center gap-3">
                  {settings.logoUrl && (
                    <img src={settings.logoUrl} alt="Logo" className="w-14 h-14 object-contain border border-[#e4e7ee] rounded-lg p-1" />
                  )}
                  <input ref={logoInputRef} type="file" accept="image/*" onChange={handleLogoUpload} className="hidden" />
                  <button 
                    onClick={() => logoInputRef.current?.click()} 
                    disabled={uploading === 'logo'}
                    className="px-4 py-2 bg-[#16a34a] text-white rounded-lg text-[13px] font-semibold hover:bg-[#15803d] transition-colors disabled:opacity-50"
                  >
                    {uploading === 'logo' ? 'Uploading...' : 'Upload Logo'}
                  </button>
                </div>
              </div>
              
              {/* Favicon Upload */}
              <div>
                <label className="block text-[13px] font-medium text-[#6b7280] mb-1">Favicon</label>
                <div className="flex items-center gap-3">
                  {settings.faviconUrl && (
                    <img src={settings.faviconUrl} alt="Favicon" className="w-8 h-8 object-contain border border-[#e4e7ee] rounded" />
                  )}
                  <input ref={faviconInputRef} type="file" accept="image/*,.ico" onChange={handleFaviconUpload} className="hidden" />
                  <button 
                    onClick={() => faviconInputRef.current?.click()} 
                    disabled={uploading === 'favicon'}
                    className="px-4 py-2 bg-[#16a34a] text-white rounded-lg text-[13px] font-semibold hover:bg-[#15803d] transition-colors disabled:opacity-50"
                  >
                    {uploading === 'favicon' ? 'Uploading...' : 'Upload Favicon'}
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Hero Images Card */}
          <div className="bg-white border border-[#e4e7ee] rounded-xl overflow-hidden">
            <div className="px-5 py-4 border-b border-[#e4e7ee] flex items-center gap-3">
              <div className="w-9 h-9 rounded-lg bg-[#16a34a]/10 flex items-center justify-center">
                <i className="ri-image-line text-lg text-[#16a34a]"></i>
              </div>
              <h3 className="text-sm font-bold text-[#1c2333]">Hero Section Images</h3>
            </div>
            <div className="p-5">
              <input ref={heroInputRef} type="file" accept="image/*" multiple onChange={handleHeroUpload} className="hidden" />
              
              {/* Hero Images Grid */}
              <div className="grid grid-cols-3 gap-3 mb-3">
                {heroImages.map((url, index) => (
                  <div key={index} className="relative group">
                    <img src={url} alt={`Hero ${index + 1}`} className="w-full h-20 object-cover rounded-lg" />
                    <button 
                      onClick={() => removeHeroImage(index)}
                      className="absolute top-1 right-1 w-6 h-6 bg-[#ef4444] text-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <i className="ri-close-line text-sm"></i>
                    </button>
                  </div>
                ))}
              </div>
              
              <button 
                onClick={() => heroInputRef.current?.click()} 
                disabled={uploading === 'hero'}
                className="w-full py-2.5 bg-white border-2 border-dashed border-[#e4e7ee] rounded-lg text-[13px] text-[#6b7280] hover:border-[#16a34a] hover:text-[#16a34a] transition-colors disabled:opacity-50"
              >
                {uploading === 'hero' ? 'Uploading...' : '+ Add Hero Images'}
              </button>
            </div>
          </div>

          {/* Delivery Settings Card */}
          <div className="bg-white border border-[#e4e7ee] rounded-xl overflow-hidden">
            <div className="px-5 py-4 border-b border-[#e4e7ee] flex items-center gap-3">
              <div className="w-9 h-9 rounded-lg bg-[#16a34a]/10 flex items-center justify-center">
                <i className="ri-truck-line text-lg text-[#16a34a]"></i>
              </div>
              <h3 className="text-sm font-bold text-[#1c2333]">Delivery Settings</h3>
            </div>
            <div className="p-5 space-y-4">
              {/* Universal Delivery Toggle */}
              <div className="flex items-center justify-between p-3 bg-[#f9fafb] rounded-lg border border-[#e4e7ee]">
                <div>
                  <span className="text-[13px] font-medium text-[#1c2333]">Universal Delivery</span>
                  <p className="text-[11px] text-[#8a96a8]">Same charge for all locations</p>
                </div>
                <button
                  onClick={() => setUniversalDelivery(!universalDelivery)}
                  className={`relative w-11 h-6 rounded-full transition-colors ${universalDelivery ? 'bg-[#16a34a]' : 'bg-[#d1d5db]'}`}
                >
                  <span className={`absolute top-1 w-4 h-4 bg-white rounded-full shadow transition-transform ${universalDelivery ? 'left-6' : 'left-1'}`} />
                </button>
              </div>
              
              {universalDelivery ? (
                <div>
                  <label className="block text-[13px] font-medium text-[#6b7280] mb-1">Delivery Charge (TK) - All Locations</label>
                  <input 
                    type="number" 
                    className="w-full px-3 py-2.5 bg-[#f0fdf4] border-2 border-[#16a34a] rounded-lg text-[13px] text-[#1c2333] outline-none" 
                    value={universalDeliveryCharge} 
                    onChange={(e) => setUniversalDeliveryCharge(parseInt(e.target.value) || 0)}
                  />
                </div>
              ) : (
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[13px] font-medium text-[#6b7280] mb-1">Inside Dhaka (TK)</label>
                    <input 
                      type="number" 
                      className="w-full px-3 py-2.5 bg-white border border-[#e4e7ee] rounded-lg text-[13px] text-[#1c2333] outline-none focus:border-[#16a34a] transition-colors" 
                      value={settings.insideDhakaDelivery || 60} 
                      onChange={(e) => setSettings({...settings, insideDhakaDelivery: parseInt(e.target.value) || 0})}
                    />
                  </div>
                  <div>
                    <label className="block text-[13px] font-medium text-[#6b7280] mb-1">Outside Dhaka (TK)</label>
                    <input 
                      type="number" 
                      className="w-full px-3 py-2.5 bg-white border border-[#e4e7ee] rounded-lg text-[13px] text-[#1c2333] outline-none focus:border-[#16a34a] transition-colors" 
                      value={settings.outsideDhakaDelivery || 120} 
                      onChange={(e) => setSettings({...settings, outsideDhakaDelivery: parseInt(e.target.value) || 0})}
                    />
                  </div>
                </div>
              )}
              
              <div>
                <label className="block text-[13px] font-medium text-[#6b7280] mb-1">Free Delivery Minimum (TK)</label>
                <input 
                  type="number" 
                  className="w-full px-3 py-2.5 bg-white border border-[#e4e7ee] rounded-lg text-[13px] text-[#1c2333] outline-none focus:border-[#16a34a] transition-colors" 
                  value={settings.freeDeliveryMin || 500} 
                  onChange={(e) => setSettings({...settings, freeDeliveryMin: parseInt(e.target.value) || 0})}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Right Column */}
        <div className="space-y-6">
          {/* Social & Contact Card */}
          <div className="bg-white border border-[#e4e7ee] rounded-xl overflow-hidden">
            <div className="px-5 py-4 border-b border-[#e4e7ee] flex items-center gap-3">
              <div className="w-9 h-9 rounded-lg bg-[#16a34a]/10 flex items-center justify-center">
                <i className="ri-links-line text-lg text-[#16a34a]"></i>
              </div>
              <h3 className="text-sm font-bold text-[#1c2333]">Social & Contact</h3>
            </div>
            <div className="p-5 space-y-4">
              <div>
                <label className="block text-[13px] font-medium text-[#6b7280] mb-1">WhatsApp Number</label>
                <input 
                  type="text" 
                  className="w-full px-3 py-2.5 bg-white border border-[#e4e7ee] rounded-lg text-[13px] text-[#1c2333] outline-none focus:border-[#16a34a] transition-colors" 
                  placeholder="+8801xxxxxxxxx"
                  value={settings.whatsappNumber || ''} 
                  onChange={(e) => setSettings({...settings, whatsappNumber: e.target.value})}
                />
              </div>
              <div>
                <label className="block text-[13px] font-medium text-[#6b7280] mb-1">Phone Number</label>
                <input 
                  type="text" 
                  className="w-full px-3 py-2.5 bg-white border border-[#e4e7ee] rounded-lg text-[13px] text-[#1c2333] outline-none focus:border-[#16a34a] transition-colors" 
                  placeholder="+8801xxxxxxxxx"
                  value={settings.phoneNumber || ''} 
                  onChange={(e) => setSettings({...settings, phoneNumber: e.target.value})}
                />
              </div>
              <div>
                <label className="block text-[13px] font-medium text-[#6b7280] mb-1">Facebook Page URL</label>
                <input 
                  type="text" 
                  className="w-full px-3 py-2.5 bg-white border border-[#e4e7ee] rounded-lg text-[13px] text-[#1c2333] outline-none focus:border-[#16a34a] transition-colors" 
                  placeholder="https://facebook.com/yourpage"
                  value={settings.facebookUrl || ''} 
                  onChange={(e) => setSettings({...settings, facebookUrl: e.target.value})}
                />
              </div>
              <div>
                <label className="block text-[13px] font-medium text-[#6b7280] mb-1">Messenger Username</label>
                <input 
                  type="text" 
                  className="w-full px-3 py-2.5 bg-white border border-[#e4e7ee] rounded-lg text-[13px] text-[#1c2333] outline-none focus:border-[#16a34a] transition-colors" 
                  placeholder="groceryhub.bd"
                  value={settings.messengerUsername || ''} 
                  onChange={(e) => setSettings({...settings, messengerUsername: e.target.value})}
                />
              </div>
            </div>
          </div>

          {/* Offer Section Card */}
          <div className="bg-white border border-[#e4e7ee] rounded-xl overflow-hidden">
            <div className="px-5 py-4 border-b border-[#e4e7ee] flex items-center gap-3">
              <div className="w-9 h-9 rounded-lg bg-[#16a34a]/10 flex items-center justify-center">
                <i className="ri-gift-2-line text-lg text-[#16a34a]"></i>
              </div>
              <h3 className="text-sm font-bold text-[#1c2333]">Offer Section</h3>
            </div>
            <div className="p-5 space-y-4">
              <div>
                <label className="block text-[13px] font-medium text-[#6b7280] mb-1">Offer Title</label>
                <input 
                  type="text" 
                  className="w-full px-3 py-2.5 bg-white border border-[#e4e7ee] rounded-lg text-[13px] text-[#1c2333] outline-none focus:border-[#16a34a] transition-colors" 
                  placeholder="Offers"
                  value={offerTitle} 
                  onChange={(e) => setOfferTitle(e.target.value)}
                />
              </div>
              <div>
                <label className="block text-[13px] font-medium text-[#6b7280] mb-1">Offer Slogan</label>
                <input 
                  type="text" 
                  className="w-full px-3 py-2.5 bg-white border border-[#e4e7ee] rounded-lg text-[13px] text-[#1c2333] outline-none focus:border-[#16a34a] transition-colors" 
                  placeholder="Exclusive deals just for you"
                  value={offerSlogan} 
                  onChange={(e) => setOfferSlogan(e.target.value)}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default SettingsView
