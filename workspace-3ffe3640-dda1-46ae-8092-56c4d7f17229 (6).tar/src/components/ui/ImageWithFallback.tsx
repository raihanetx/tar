'use client'

import React, { useState } from 'react'

interface ImageWithFallbackProps {
  src: string | null | undefined
  alt: string
  className?: string
  style?: React.CSSProperties
  onClick?: () => void
}

export function ImageWithFallback({
  src,
  alt,
  className,
  style,
  onClick,
}: ImageWithFallbackProps) {
  const [error, setError] = useState(false)

  // Check if src is valid
  const isValidSrc = src && src.trim() !== '' && (
    src.startsWith('http') ||
    src.startsWith('/') ||
    src.startsWith('data:image')
  )

  // Show rotated smiley if no valid src or image failed to load
  if (!isValidSrc || error) {
    return (
      <div
        className={`flex items-center justify-center ${className || ''}`}
        style={style}
        onClick={onClick}
      >
        <span className="text-2xl text-gray-400" style={{ transform: 'rotate(90deg)' }}>:)</span>
      </div>
    )
  }

  return (
    <img
      src={src}
      alt={alt}
      className={className}
      style={style}
      onClick={onClick}
      onError={() => setError(true)}
      loading="lazy"
    />
  )
}

// Simple hook for fallback image URL
export function useImageFallback(src: string | null | undefined): string | null {
  if (!src || src.trim() === '') return null

  // Valid sources
  if (src.startsWith('http://') || src.startsWith('https://')) return src
  if (src.startsWith('/')) return src
  if (src.startsWith('data:image')) return src

  // Invalid source
  return null
}
