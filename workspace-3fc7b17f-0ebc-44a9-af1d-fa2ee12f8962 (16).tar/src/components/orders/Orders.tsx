'use client'

import { useState } from 'react'
import { ViewType, Order } from '@/types'

interface OrdersProps {
  orders: Order[]
  setView: (v: ViewType) => void
}

export default function Orders({ orders, setView }: OrdersProps) {
  const [expandedOrderId, setExpandedOrderId] = useState<string | null>(orders[0]?.id || null)

  if (orders.length === 0) {
    return (
      <main className="flex flex-col items-center justify-center h-[calc(100vh-120px)] px-6 space-y-20 bg-white font-inter">
        <div className="flex flex-col items-center gap-1.5">
          <i className="ri-todo-line text-[56px] text-zinc-100"></i>
          <div className="text-center">
            <h1 className="text-xl font-medium tracking-tight text-zinc-900">No orders yet</h1>
            <p className="text-sm text-zinc-400 font-light max-w-[220px] mx-auto leading-relaxed">Your past orders will appear here. Start shopping to place your first order.</p>
            <button onClick={() => setView('shop')} className="mt-4 px-6 py-2 bg-[#16a34a] text-white rounded-lg text-sm font-medium">Shop Now</button>
          </div>
        </div>
      </main>
    )
  }

  // Map order status to UI display
  const getStatusInfo = (status: string) => {
    const statusMap: Record<string, { label: string; color: string; progress: number }> = {
      pending: { label: 'Processing', color: '#F97316', progress: 33 },
      packaging: { label: 'Packing', color: '#F97316', progress: 50 },
      shipping: { label: 'Shipping', color: '#F97316', progress: 75 },
      delivered: { label: 'Delivered', color: '#16a34a', progress: 100 },
      cancelled: { label: 'Cancelled', color: '#ef4444', progress: 0 },
      approved: { label: 'Processing', color: '#F97316', progress: 50 },
    }
    return statusMap[status] || statusMap.pending
  }

  // Get product image (use first item's image or fallback)
  const getProductImage = (itemName: string) => {
    const imageMap: Record<string, string> = {
      'carrot': 'https://i.postimg.cc/B6sD1hKt/1000020579-removebg-preview.png',
      'potato': 'https://i.postimg.cc/d1vdTWyL/1000020583-removebg-preview.png',
      'tomato': 'https://i.postimg.cc/mr7CkxtQ/1000020584-removebg-preview.png',
      'broccoli': 'https://i.postimg.cc/qR0nCm36/1000020611-removebg-preview.png',
    }
    const key = itemName.toLowerCase()
    for (const [k, v] of Object.entries(imageMap)) {
      if (key.includes(k)) return v
    }
    return 'https://i.postimg.cc/B6sD1hKt/1000020579-removebg-preview.png'
  }

  // Render a single order card
  const renderOrderCard = (order: Order, isExpanded: boolean) => {
    const statusInfo = getStatusInfo(order.status)
    const progressWidth = statusInfo.progress

    return (
      <div 
        key={order.id} 
        className="w-full max-w-[340px] bg-white rounded-[5px] border border-[#111827]/20 flex flex-col overflow-hidden shadow-sm cursor-pointer"
        onClick={() => setExpandedOrderId(isExpanded ? null : order.id)}
      >
        {/* Compact Header - Always Visible */}
        <div className="px-5 py-4 flex items-center justify-between border-b border-gray-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gray-100 p-1 rounded">
              <img src={`https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=Order:${order.id}&color=111827`} className="w-full h-full object-contain" alt="Order QR" />
            </div>
            <div className="flex flex-col">
              <h2 className="text-sm font-bold tracking-tight uppercase">ID: #{order.id}</h2>
              <span className="text-[10px] text-[#111827]/40">{order.date} • {order.time}</span>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold" style={{ color: statusInfo.color }}>{statusInfo.label}</span>
            <i className={`ri-arrow-${isExpanded ? 'up' : 'down'}-s-line text-gray-400`}></i>
          </div>
        </div>

        {/* Expanded Content */}
        {isExpanded && (
          <>
            {/* Progress Bar */}
            <div className="px-6 py-4 border-b border-gray-100">
              <div className="relative flex items-center justify-between z-0">
                <div className="absolute top-1/2 left-0 w-full h-[2px] bg-[#111827]/10 -z-10 rounded-full"></div>
                <div className="absolute top-1/2 left-0 h-[2px] bg-[#F97316] -z-10 rounded-full" style={{ width: `${progressWidth}%` }}></div>
                <div className="bg-white pr-1"><div className={`w-2.5 h-2.5 rounded-full ${progressWidth >= 25 ? 'bg-[#F97316]' : 'bg-[#111827]/10'}`}></div></div>
                <div className="bg-white px-1"><div className={`w-2.5 h-2.5 rounded-full ${progressWidth >= 50 ? 'bg-[#F97316]' : 'border-2 border-[#F97316] bg-white ring-2 ring-[#F97316]/20'}`}></div></div>
                <div className="bg-white px-1"><div className={`w-2.5 h-2.5 rounded-full ${progressWidth >= 75 ? 'bg-[#F97316]' : 'bg-[#111827]/10'}`}></div></div>
                <div className="bg-white pl-1"><div className={`w-2.5 h-2.5 rounded-full ${progressWidth >= 100 ? 'bg-[#16a34a]' : 'bg-[#111827]/10'}`}></div></div>
              </div>
              <div className="flex justify-between text-[9px] font-bold mt-2 uppercase text-[#111827]/40">
                <span className={progressWidth >= 25 ? 'text-[#111827]/80' : ''}>Taken</span>
                <span className={progressWidth >= 50 ? 'text-[#111827]/80' : ''}>Packed</span>
                <span className={progressWidth >= 75 ? 'text-[#F97316]' : ''}>Process</span>
                <span className={progressWidth >= 100 ? 'text-[#16a34a]' : ''}>Done</span>
              </div>
            </div>

            {/* Shipping Details */}
            <div className="px-6 py-4 border-b border-gray-100">
              <div className="flex flex-col gap-3">
                <div className="flex items-start gap-3">
                  <i className="ri-map-pin-fill text-sm text-[#111827]/30 mt-0.5"></i>
                  <div className="flex flex-col">
                    <span className="text-[10px] font-bold text-[#111827]/40 uppercase tracking-widest mb-1">Shipping Details</span>
                    <span className="text-xs font-bold text-[#111827] uppercase">{order.customer}</span>
                    <span className="text-xs font-bold text-[#111827]/60 mt-0.5 leading-snug uppercase">{order.address}</span>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <i className="ri-timer-fill text-sm text-[#F97316]"></i>
                  <span className="text-xs font-bold text-[#F97316] uppercase tracking-tight">Est: 1 - 7 Days</span>
                </div>
              </div>
            </div>

            {/* Items */}
            <div className="px-6 py-4 space-y-3 border-b border-gray-100 bg-gray-50/50">
              {order.items.slice(0, 3).map((item, idx) => {
                const originalTotal = item.basePrice * item.qty
                const offerDiscount = item.offerDiscount || 0
                const couponDiscount = item.couponDiscount || 0
                const finalTotal = originalTotal - offerDiscount - couponDiscount
                
                return (
                  <div key={idx} className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-[3px] bg-white flex-shrink-0 overflow-hidden border border-[#111827]/10 p-[2px]">
                      <img src={getProductImage(item.name)} className="w-full h-full object-contain rounded-[2px]" alt={item.name} />
                    </div>
                    <div className="flex-1">
                      <p className="text-xs font-bold tracking-tight uppercase text-[#111827]">{item.name}{item.variant ? ` (${item.variant})` : ''}</p>
                      <p className="text-[9px] text-[#111827]/40 mt-0.5 uppercase">Qty: {item.qty}</p>
                    </div>
                    <div className="text-right">
                      {finalTotal !== originalTotal ? (
                        <>
                          <p className="text-[9px] text-[#111827]/40 line-through">{originalTotal}TK</p>
                          <span className="text-xs font-bold text-[#111827]">{finalTotal}TK</span>
                        </>
                      ) : (
                        <span className="text-xs font-bold text-[#111827]">{originalTotal}TK</span>
                      )}
                    </div>
                  </div>
                )
              })}
              {order.items.length > 3 && (
                <p className="text-[10px] text-[#111827]/40 text-center">+{order.items.length - 3} more items</p>
              )}
            </div>

            {/* Payment Summary */}
            <div className="px-6 py-4">
              <div className="space-y-2 mb-4">
                <div className="flex justify-between text-[11px] font-bold"><span className="text-[#111827]/40 uppercase">Sub-Total</span><span className="text-[#111827]">{order.subtotal}TK</span></div>
                {order.discount > 0 && (
                  <div className="flex justify-between text-[11px] font-bold"><span className="text-[#16a34a] uppercase">Offer Discount</span><span className="text-[#16a34a]">-{order.discount}TK</span></div>
                )}
                {order.couponAmount > 0 && (
                  <div className="flex justify-between text-[11px] font-bold"><span className="text-[#111827]/40 uppercase tracking-tighter">Coupon</span><span className="text-[#111827]">-{order.couponAmount}TK</span></div>
                )}
                <div className="flex justify-between text-[11px] font-bold"><span className="text-[#111827]/40 uppercase">Delivery</span><span className="text-[#111827]">{order.delivery === 0 ? 'Free' : `${order.delivery}TK`}</span></div>
              </div>
              <div className="w-full h-[1px] bg-[#111827]/10 mb-4"></div>
              <div className="flex justify-between items-center">
                <div className="flex flex-col">
                  <span className="text-xs font-bold uppercase tracking-widest text-[#111827]/80">Payable Amount</span>
                  <span className="text-[10px] font-bold text-[#111827]/40 uppercase mt-1">({order.paymentMethod})</span>
                </div>
                <div className="text-right"><span className="text-2xl font-bold tracking-tighter text-[#111827]">{order.total}TK</span></div>
              </div>
            </div>
          </>
        )}
      </div>
    )
  }

  return (
    <main className="min-h-[calc(100vh-120px)] bg-gray-100 p-4 md:p-6 font-inter antialiased text-[#111827]">
      <div className="max-w-md mx-auto">
        <h1 className="text-lg font-bold text-center mb-4 text-gray-900">My Orders ({orders.length})</h1>
        <div className="flex flex-col gap-3 max-h-[calc(100vh-200px)] overflow-y-auto pr-1">
          {orders.map((order) => renderOrderCard(order, expandedOrderId === order.id))}
        </div>
      </div>
    </main>
  )
}
