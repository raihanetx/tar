'use client'

import { useState, useMemo, useEffect, useRef } from 'react'
import { ViewType, CartItem } from '@/types'

interface DeliverySettings {
  insideDhaka: number
  outsideDhaka: number
  freeDeliveryMin: number
  universal: boolean
  universalCharge: number
}

interface CheckoutProps {
  setView: (v: ViewType) => void
  onConfirm: (customerInfo: { name: string; phone: string; address: string }, couponCode?: string) => void
  cartItems?: CartItem[]
  deliveryCharge?: number
  deliverySettings?: DeliverySettings
  onCheckoutSession?: (sessionId: string) => void
}

interface ValidatedCoupon {
  code: string
  type: 'pct' | 'fixed'
  value: number
  scope: string
}

// Dhaka area keywords for auto-detection
const dhakaKeywords = ['dhaka', 'dhanmondi', 'gulshan', 'uttara', 'mirpur', 'mohammadpur', 'banani', 'badda', 'tejgaon', 'motijheel', 'ramna', 'sabujbagh', 'khilgaon', 'kadamtali', 'demra', 'hazaribagh', 'lalbagh', 'kotwali', 'sutrapur', 'wari', 'chawkbazar', 'bangsal', 'shahbagh', 'paltan', 'jatrabari', 'shyampur', 'cantonment', 'turag', 'darussalam', 'kafrul', 'adabor', 'pallabi', 'sher-e-bangla nagar']

// Persistent session storage key - ONE key for the entire customer journey
const SESSION_KEY = 'ecomart_customer_session'

export default function Checkout({ setView, onConfirm, cartItems = [], deliveryCharge = 60, deliverySettings, onCheckoutSession }: CheckoutProps) {
  const [name, setName] = useState('')
  const [phone, setPhone] = useState('')
  const [address, setAddress] = useState('')
  const [couponCode, setCouponCode] = useState('')
  const [focusedField, setFocusedField] = useState<string | null>(null)
  const [validatedCoupon, setValidatedCoupon] = useState<ValidatedCoupon | null>(null)
  const [couponError, setCouponError] = useState<string | null>(null)
  const [isValidatingCoupon, setIsValidatingCoupon] = useState(false)
  const [sessionId, setSessionId] = useState<string>('')
  const [termsAccepted, setTermsAccepted] = useState(false)
  const [termsError, setTermsError] = useState<string | null>(null)
  
  // Track if we already recorded the visit
  const visitRecordedRef = useRef(false)

  // Calculate totals from cart items
  const subtotal = cartItems.reduce((sum, item) => sum + item.price * (item.quantity || 1), 0)
  
  // Calculate dynamic delivery charge based on address and settings
  const calculatedDelivery = useMemo(() => {
    if (!deliverySettings) return deliveryCharge
    
    if (subtotal >= deliverySettings.freeDeliveryMin) {
      return 0
    }
    
    if (deliverySettings.universal) {
      return deliverySettings.universalCharge
    }
    
    const addressLower = address.toLowerCase()
    const isInsideDhaka = dhakaKeywords.some(keyword => addressLower.includes(keyword))
    
    return isInsideDhaka ? deliverySettings.insideDhaka : deliverySettings.outsideDhaka
  }, [address, subtotal, deliverySettings, deliveryCharge])
  
  const discount = validatedCoupon 
    ? (validatedCoupon.type === 'pct' 
        ? Math.round(subtotal * (validatedCoupon.value / 100))
        : Math.min(validatedCoupon.value, subtotal))
    : 0
  
  const total = subtotal - discount + calculatedDelivery

  // Get or create PERSISTENT session ID
  // This ID stays the SAME across all visits from this browser
  useEffect(() => {
    if (typeof window === 'undefined') return
    
    // Try to get existing session
    let existingSession = localStorage.getItem(SESSION_KEY)
    
    if (!existingSession) {
      // Create new session ID for first-time visitor
      existingSession = `customer_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`
      localStorage.setItem(SESSION_KEY, existingSession)
      console.log('🆕 Created NEW session:', existingSession)
    } else {
      console.log('♻️ Using EXISTING session:', existingSession)
    }
    
    setSessionId(existingSession)
    if (onCheckoutSession) {
      onCheckoutSession(existingSession)
    }
    
    // Reset visit recorded flag for this component mount
    visitRecordedRef.current = false
  }, [onCheckoutSession])

  // Track NEW checkout visit
  useEffect(() => {
    if (!sessionId || cartItems.length === 0) return
    if (visitRecordedRef.current) return

    const trackVisit = async () => {
      try {
        const items = cartItems.map(item => ({
          name: item.name,
          variants: [{
            label: item.weight,
            qty: item.quantity || 1
          }]
        }))

        console.log('📤 Sending NEW visit for session:', sessionId)

        const response = await fetch('/api/abandoned', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            sessionId,
            items,
            subtotal,
            delivery: calculatedDelivery,
            total: subtotal + calculatedDelivery,
            isNewVisit: true
          })
        })

        const result = await response.json()
        console.log('📥 Visit result:', result)
        
        if (result.success) {
          visitRecordedRef.current = true
        }
      } catch (error) {
        console.error('Error tracking visit:', error)
      }
    }

    trackVisit()
  }, [sessionId, cartItems.length])

  // Update customer info IMMEDIATELY
  useEffect(() => {
    if (!sessionId || cartItems.length === 0 || !visitRecordedRef.current) return
    if (!name && !phone && !address) return

    const updateInfo = async () => {
      try {
        const items = cartItems.map(item => ({
          name: item.name,
          variants: [{ label: item.weight, qty: item.quantity || 1 }]
        }))

        console.log('📝 Updating customer info:', { name, phone, address })

        await fetch('/api/abandoned', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            sessionId,
            name,
            phone,
            address,
            items,
            subtotal,
            delivery: calculatedDelivery,
            total: subtotal + calculatedDelivery,
            isNewVisit: false
          })
        })
      } catch (error) {
        console.error('Error updating info:', error)
      }
    }

    updateInfo()
  }, [sessionId, name, phone, address, cartItems.length])

  const handleApplyCoupon = async () => {
    if (!couponCode.trim()) {
      setCouponError('Please enter a coupon code')
      return
    }
    
    setIsValidatingCoupon(true)
    setCouponError(null)
    setValidatedCoupon(null)
    
    try {
      const response = await fetch(`/api/coupons?code=${encodeURIComponent(couponCode.trim().toUpperCase())}`)
      const result = await response.json()
      
      if (result.success && result.data) {
        setValidatedCoupon({
          code: result.data.code,
          type: result.data.type,
          value: result.data.value,
          scope: result.data.scope,
        })
      } else {
        setCouponError(result.error || 'Invalid coupon code')
      }
    } catch (error) {
      console.error('Error validating coupon:', error)
      setCouponError('Failed to validate coupon')
    } finally {
      setIsValidatingCoupon(false)
    }
  }

  const handleConfirm = () => {
    if (!name || !phone || !address) {
      alert('Please fill in all fields')
      return
    }
    
    if (!termsAccepted) {
      setTermsError('Please accept the Terms & Conditions to continue')
      return
    }
    
    setTermsError(null)
    onConfirm({ name, phone, address }, validatedCoupon?.code || undefined)
  }

  return (
    <div className="chk-bg">
      <div className="chk-container">
        <div className="chk-section-header"><i className="ri-shopping-bag-3-line"></i> Order Summary</div>
        
        {cartItems.length > 0 ? (
          cartItems.map((item, index) => (
            <div key={index} className="chk-product-row">
              <img src={item.img} alt={item.name} className="chk-prod-img" />
              <div className="chk-prod-info"><h4>{item.name}</h4><span>Qty: {item.quantity || 1} {item.weight}</span></div>
              <div className="chk-prod-price">TK{item.price * (item.quantity || 1)}</div>
            </div>
          ))
        ) : (
          <div className="chk-product-row" style={{justifyContent: 'center', padding: '20px', color: '#9ca3af'}}>
            <div className="chk-prod-info" style={{textAlign: 'center'}}>
              <i className="ri-shopping-cart-line" style={{fontSize: '24px', display: 'block', marginBottom: '8px'}}></i>
              <h4 style={{color: '#64748b'}}>No items in cart</h4>
              <span style={{fontSize: '12px'}}>Add products from the shop</span>
            </div>
          </div>
        )}
        
        <div className="chk-cost-row"><span>Subtotal</span><span>TK{subtotal.toFixed(2)}</span></div>
        {discount > 0 && (
          <div className="chk-cost-row" style={{color: '#16a34a'}}><span>Coupon Discount ({validatedCoupon?.type === 'pct' ? `${validatedCoupon.value}%` : 'Fixed'})</span><span>-TK{discount.toFixed(2)}</span></div>
        )}
        <div className="chk-cost-row"><span>Delivery Charge</span><span>TK{calculatedDelivery.toFixed(2)}</span></div>
        <div className="chk-total-row"><span>Total Payable</span><span>TK{total.toFixed(2)}</span></div>

        <div className="chk-coupon-wrapper">
          <div className="chk-input-wrapper">
            <i className="ri-ticket-2-line chk-input-icon"></i>
            <input type="text" id="coupon" className="chk-clean-input"
              value={couponCode}
              onChange={(e) => { setCouponCode(e.target.value); setValidatedCoupon(null); setCouponError(null); }}
              onFocus={() => setFocusedField('coupon')}
              onBlur={() => setFocusedField(null)} />
            <label htmlFor="coupon" className={`chk-input-label ${focusedField === 'coupon' || couponCode ? 'active-label' : ''}`}>Coupon Code</label>
          </div>
          <button className="chk-btn-apply" onClick={handleApplyCoupon} disabled={isValidatingCoupon}>{isValidatingCoupon ? '...' : 'APPLY'}</button>
        </div>
        {couponError && <div style={{color: '#ef4444', fontSize: '12px', marginTop: '-8px', marginBottom: '8px'}}>{couponError}</div>}
        {validatedCoupon && <div style={{color: '#16a34a', fontSize: '12px', marginTop: '-8px', marginBottom: '8px'}}>Coupon applied successfully!</div>}

        <hr className="chk-divider" />

        <div className="chk-section-header"><i className="ri-user-line"></i> Customer Information</div>
        <div className="chk-input-wrapper">
          <i className="ri-user-3-line chk-input-icon"></i>
          <input type="text" id="fullname" className="chk-clean-input"
            value={name}
            onChange={(e) => setName(e.target.value)}
            onFocus={() => setFocusedField('fullname')}
            onBlur={() => setFocusedField(null)} />
          <label htmlFor="fullname" className={`chk-input-label ${focusedField === 'fullname' || name ? 'active-label' : ''}`}>Full Name</label>
        </div>
        <div className="chk-input-wrapper">
          <i className="ri-smartphone-line chk-input-icon"></i>
          <input type="tel" id="phone" className="chk-clean-input"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            onFocus={() => setFocusedField('phone')}
            onBlur={() => setFocusedField(null)} />
          <label htmlFor="phone" className={`chk-input-label ${focusedField === 'phone' || phone ? 'active-label' : ''}`}>Phone Number</label>
        </div>
        <div className="chk-input-wrapper">
          <i className="ri-map-pin-2-line chk-input-icon"></i>
          <input type="text" id="address" className="chk-clean-input"
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            onFocus={() => setFocusedField('address')}
            onBlur={() => setFocusedField(null)} />
          <label htmlFor="address" className={`chk-input-label ${focusedField === 'address' || address ? 'active-label' : ''}`}>Full Address</label>
        </div>

        <hr className="chk-divider" />

        <div className="chk-section-header"><i className="ri-secure-payment-line"></i> Payment Method</div>
        <div className="mt-4">
          <p style={{ fontSize: '13px', color: '#475569', lineHeight: 1.6 }}>
            This is a cash on delivery order. Please keep <b style={{ color: '#0f172a' }}>TK{total.toFixed(2)}</b> ready to pay the rider when your order arrives.
          </p>
        </div>

        <hr className="chk-divider" />

        <div className="chk-legal-check"><input type="checkbox" id="save" /><label htmlFor="save">Save info for next time</label></div>
        <div className="chk-legal-check">
          <input 
            type="checkbox" 
            id="terms" 
            checked={termsAccepted}
            onChange={(e) => { setTermsAccepted(e.target.checked); setTermsError(null); }}
          />
          <label htmlFor="terms">I agree to the <a href="#" className="chk-link" onClick={(e) => { e.preventDefault(); setView('terms'); }}>Terms & Conditions</a></label>
        </div>
        {termsError && <div style={{color: '#ef4444', fontSize: '12px', marginTop: '4px'}}>{termsError}</div>}

        <div className="chk-btn-group">
          <button className="chk-btn-main chk-btn-cancel" onClick={() => setView('cart')}>Cancel</button>
          <button className="chk-btn-main chk-btn-confirm" onClick={handleConfirm}>Confirm Order</button>
        </div>
      </div>
    </div>
  )
}
